define("frmQFSLogin", function() {
    return function(controller) {
        function addWidgetsfrmQFSLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainLogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70%",
                "id": "flxMainLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "flxMainLoginSkn",
                "top": "38dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMainLogin.setDefaultUnit(kony.flex.DP);
            var lblLoginHeader = new kony.ui.Label({
                "id": "lblLoginHeader",
                "isVisible": true,
                "left": "39dp",
                "skin": "lblLoginHeaderSkn",
                "text": "Welcome,",
                "top": "10%",
                "width": "35%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginHeader2 = new kony.ui.Label({
                "id": "lblLoginHeader2",
                "isVisible": true,
                "left": "39dp",
                "skin": "lblLoginHeaderSkn",
                "text": "Sign in to continue",
                "top": "10dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10%",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmail.setDefaultUnit(kony.flex.DP);
            var tbxEmailId = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "100%",
                "id": "tbxEmailId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Email ID",
                "secureTextEntry": false,
                "skin": "tbxSkin",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "tbxPlaceHolderSkin"
            });
            flxEmail.add(tbxEmailId);
            var flxShadow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxShadow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "flxShadow",
                "top": "3%",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxShadow.setDefaultUnit(kony.flex.DP);
            flxShadow.add();
            var flxPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPassword.setDefaultUnit(kony.flex.DP);
            var flxtbxPasswordParent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxtbxPasswordParent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%"
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxtbxPasswordParent.setDefaultUnit(kony.flex.DP);
            var tbxPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "100%",
                "id": "tbxPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "onDone": controller.AS_TextField_f8860e91e04e4f1195a113ad5fe1cba5,
                "placeholder": "Password",
                "secureTextEntry": true,
                "skin": "tbxSkin",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "tbxPlaceHolderSkin"
            });
            var flxEyeImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxEyeImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "onTouchEnd": controller.AS_FlexContainer_i29298aa4b7b44d98c1ad18d91cbf1d7,
                "onTouchStart": controller.AS_FlexContainer_e6d61ba367de4a99b5724ffb8fdbf763,
                "skin": "slFbox",
                "top": "4dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEyeImg.setDefaultUnit(kony.flex.DP);
            var imgEye = new kony.ui.Image2({
                "height": "100%",
                "id": "imgEye",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "eyegrey.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEyeImg.add(imgEye);
            flxtbxPasswordParent.add(tbxPassword, flxEyeImg);
            flxPassword.add(flxtbxPasswordParent);
            var flxShadow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxShadow2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "flxShadow",
                "top": "3%",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxShadow2.setDefaultUnit(kony.flex.DP);
            flxShadow2.add();
            var lblForgotPassword = new kony.ui.Label({
                "id": "lblForgotPassword",
                "isVisible": true,
                "right": "0%",
                "skin": "lblForgotPasswordSkn",
                "text": "Forgot Password?",
                "top": "5%",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSignin = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnSignin",
                "isVisible": true,
                "left": "39dp",
                "onClick": controller.AS_Button_ecdca045adab4cd49d237377dd82cd1d,
                "skin": "ButtonSkinActive",
                "text": "Sign in",
                "top": "66dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMainLogin.add(lblLoginHeader, lblLoginHeader2, flxEmail, flxShadow, flxPassword, flxShadow2, lblForgotPassword, btnSignin);
            this.add(flxMainLogin);
        };
        return [{
            "addWidgets": addWidgetsfrmQFSLogin,
            "enabledForIdleTimeout": false,
            "id": "frmQFSLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});