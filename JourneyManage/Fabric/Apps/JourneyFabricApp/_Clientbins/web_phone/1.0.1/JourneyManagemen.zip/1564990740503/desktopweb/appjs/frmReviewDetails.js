define("frmReviewDetails", function() {
    return function(controller) {
        function addWidgetsfrmReviewDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var ParentFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1400px",
                "id": "ParentFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0db64eeca77e74b",
                "top": "0px",
                "width": "1024px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            ParentFlex.setDefaultUnit(kony.flex.DP);
            var LeftFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1400px",
                "id": "LeftFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0bcd49123877f4a",
                "top": "0px",
                "width": "330px",
                "zIndex": 1
            }, {}, {});
            LeftFlex.setDefaultUnit(kony.flex.DP);
            var flxCreationList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "240px",
                "id": "flxCreationList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "32px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99px",
                "width": "197px",
                "zIndex": 1
            }, {}, {});
            flxCreationList.setDefaultUnit(kony.flex.DP);
            flxCreationList.add();
            var FlxTravelerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTravelerDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTravelerDetails.setDefaultUnit(kony.flex.DP);
            var btnTravelerDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTravelerDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "1",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravelerDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblTravelerDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Traveller Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTravelerDetails.add(btnTravelerDetails, lblTravelerDetails);
            var FlxRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "149dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblRouteDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblRouteDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Route Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRouteDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30px",
                "id": "btnRouteDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "2",
                "top": "0px",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRouteDetails.add(lblRouteDetails, btnRouteDetails);
            var FlxTrackingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTrackingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "199dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTrackingDetails.setDefaultUnit(kony.flex.DP);
            var btnTrackingDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTrackingDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "3",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingDetails = new kony.ui.Label({
                "height": "25px",
                "id": "lblTrackingDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Tracking Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrackingDetails.add(btnTrackingDetails, lblTrackingDetails);
            var FlxVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxVehicleDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "249dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxVehicleDetails.setDefaultUnit(kony.flex.DP);
            var btnVehicleDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnVehicleDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "4",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblVehicleDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Vehicle Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicleDetails.add(btnVehicleDetails, lblVehicleDetails);
            var FlxReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxReview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "299dp",
                "width": "220px",
                "zIndex": 2
            }, {}, {});
            FlxReview.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal1",
                "text": "5",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Review & Verification",
                "top": "6px",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxReview.add(btnReview, lblReview);
            var lblVerticalLine = new kony.ui.Label({
                "height": "189px",
                "id": "lblVerticalLine",
                "isVisible": true,
                "left": "42px",
                "skin": "CopyCopydefLabel0jcee779a5e3f48",
                "top": "125px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "33px",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d807ad9a1ae04a1f98cf70a3522b307f,
                "skin": "slFbox",
                "top": "33px",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "height": "21px",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "32px",
                "minWidth": "156px",
                "skin": "CopyCopydefLabel0f52d96ab22d343",
                "text": "Back to Dashboard",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "21px",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "murali_1.png",
                "top": "0px",
                "width": "20px",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            LeftFlex.add(flxCreationList, FlxTravelerDetails, FlxRouteDetails, FlxTrackingDetails, FlxVehicleDetails, FlxReview, lblVerticalLine, flxDashboard);
            var RightFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1400px",
                "id": "RightFlex",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "350px",
                "isModalContainer": false,
                "skin": "CopyslFbox0c726ba7b377649",
                "top": "0px",
                "width": "748px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            RightFlex.setDefaultUnit(kony.flex.DP);
            var lblReviewDashboard = new kony.ui.Label({
                "height": "31px",
                "id": "lblReviewDashboard",
                "isVisible": true,
                "left": "126px",
                "skin": "CopydefLabel0g27bca0da2af44",
                "text": "Review & Verification Details",
                "top": "100px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxReviewDashboardData = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "1400px",
                "horizontalScrollIndicator": true,
                "id": "flxReviewDashboardData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "126px",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopyflxRouteDetails0fc226af58c1c4c",
                "top": "10px",
                "verticalScrollIndicator": true,
                "width": "496px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxReviewDashboardData.setDefaultUnit(kony.flex.DP);
            var FlxTraveller = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "420px",
                "id": "FlxTraveller",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "0px",
                "width": "496px",
                "zIndex": 1
            }, {}, {});
            FlxTraveller.setDefaultUnit(kony.flex.DP);
            var lblTravellerHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Traveller Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgTravellerDetailsEdit = new kony.ui.Image2({
                "height": "24px",
                "id": "imgTravellerDetailsEdit",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_e9987e5ec28d4c589cf83389b4d14967,
                "right": "30px",
                "skin": "slImage",
                "src": "edit.png",
                "top": "30px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerName = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerName",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Driver Name",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerNameValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTravellerNameValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Karl Granleese",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerNumber = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerNumber",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Mobile Phone Number",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerNumberValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTravellerNumberValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "094-228-0095",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerSatellitePhone = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerSatellitePhone",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Satelite Phone",
                "top": "173px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerSatellitePhoneValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTravellerSatellitePhoneValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "011 859435 439534",
                "top": "193px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerRadio = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerRadio",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Radio",
                "top": "224px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravellerRadioValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTravellerRadioValue",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "106.4",
                "top": "244px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserIdReview = new kony.ui.Label({
                "height": "21px",
                "id": "lblUserIdReview",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "User ID",
                "top": "272dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserIdReviewValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblUserIdReviewValue",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "KH007",
                "top": "293dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPassengerOne = new kony.ui.Label({
                "height": "21px",
                "id": "lblPassengerOne",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Passenger One",
                "top": "321dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPassengerOneValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblPassengerOneValue",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Ramesh",
                "top": "342dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPassengerTwo = new kony.ui.Label({
                "height": "21px",
                "id": "lblPassengerTwo",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Passenger Two",
                "top": "370dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPassengerTwoValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblPassengerTwoValue",
                "isVisible": true,
                "left": "34px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Suresh",
                "top": "391dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTraveller.add(lblTravellerHeader, imgTravellerDetailsEdit, lblTravellerName, lblTravellerNameValue, lblTravellerNumber, lblTravellerNumberValue, lblTravellerSatellitePhone, lblTravellerSatellitePhoneValue, lblTravellerRadio, lblTravellerRadioValue, lblUserIdReview, lblUserIdReviewValue, lblPassengerOne, lblPassengerOneValue, lblPassengerTwo, lblPassengerTwoValue);
            var flxTravellerEditDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "700dp",
                "id": "flxTravellerEditDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "400dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "0dp",
                "width": "390px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTravellerEditDetails.setDefaultUnit(kony.flex.DP);
            var lblTravellerDetailsDashboard = new kony.ui.Label({
                "height": "21px",
                "id": "lblTravellerDetailsDashboard",
                "isVisible": true,
                "left": "30px",
                "skin": "konyqfsSknLblTravellerEditDetails",
                "text": "Traveler Details",
                "top": "30px",
                "width": "127px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblName = new kony.ui.Label({
                "height": "18px",
                "id": "lblName",
                "isVisible": true,
                "left": "30px",
                "skin": "konyqfsSknLblDriverNameEdit",
                "text": "Driver Name",
                "top": "71px",
                "width": "77px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "Kari",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "92px",
                "width": "330px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobile = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobile",
                "isVisible": true,
                "left": "30px",
                "skin": "CopylblName0fa520c545cbd45",
                "text": "Mobile Phone Number",
                "top": "160px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldMobile = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldMobile",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "094-228-0095",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "181px",
                "width": "330px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRoomNo = new kony.ui.Label({
                "height": "16px",
                "id": "lblRoomNo",
                "isVisible": true,
                "left": "30px",
                "skin": "CopylblName",
                "text": "Satelite Phone",
                "top": "249px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldRoomNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldRoomNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "32",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "270px",
                "width": "330px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblSiterepName = new kony.ui.Label({
                "height": "16px",
                "id": "lblSiterepName",
                "isVisible": true,
                "left": "30px",
                "skin": "CopylblName",
                "text": "Radio",
                "top": "338px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldSiterepName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldSiterepName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "Mo Chun",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "359px",
                "width": "330px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblUserID = new kony.ui.Label({
                "height": "16px",
                "id": "lblUserID",
                "isVisible": true,
                "left": "30px",
                "skin": "CopylblName",
                "text": "User ID",
                "top": "427px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldUserID = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldUserID",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "User ID",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "446px",
                "width": "330px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxSegData = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "250dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "509dp",
                "verticalScrollIndicator": true,
                "width": "330dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSegData.setDefaultUnit(kony.flex.DP);
            var segAddPassenger = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgAddPassenger": "crossimageblue.png",
                    "lblPassenger": "Passenger",
                    "lblPassengerMobile": "Mobile",
                    "lblPassengerName": "Name",
                    "txtPassengerMobile": {
                        "placeholder": "Mobile",
                        "text": "897777"
                    },
                    "txtPassengerName": {
                        "placeholder": "Murali",
                        "text": "Murali"
                    }
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segAddPassenger",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSegTmpAddPassenger",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAddPassenger": "flxAddPassenger",
                    "flxSegTmpAddPassenger": "flxSegTmpAddPassenger",
                    "imgAddPassenger": "imgAddPassenger",
                    "lblPassenger": "lblPassenger",
                    "lblPassengerMobile": "lblPassengerMobile",
                    "lblPassengerName": "lblPassengerName",
                    "txtPassengerMobile": "txtPassengerMobile",
                    "txtPassengerName": "txtPassengerName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegData.add(segAddPassenger);
            var flxAddPassenger = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "48px",
                "id": "flxAddPassenger",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_bc3d67e496b140e1ab90b062cc378e5b,
                "skin": "CopyslFbox0aacbda37a36146",
                "top": "509px",
                "width": "195px",
                "zIndex": 1
            }, {}, {});
            flxAddPassenger.setDefaultUnit(kony.flex.DP);
            var imgPlusIcon = new kony.ui.Image2({
                "height": "48px",
                "id": "imgPlusIcon",
                "isVisible": true,
                "left": "12px",
                "skin": "slImage",
                "src": "plus.png",
                "top": "0px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddPassenger = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "48px",
                "id": "btnAddPassenger",
                "isVisible": true,
                "right": "0px",
                "skin": "CopydefBtnNormal0gf08e7ec380348",
                "text": "Add Passenger",
                "top": "0dp",
                "width": "147px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddPassengerVerticalLine = new kony.ui.Label({
                "height": "44px",
                "id": "lblAddPassengerVerticalLine",
                "isVisible": true,
                "left": "46px",
                "skin": "CopydefLabel0bf4e4e48c7c947",
                "top": "1px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddPassenger.add(imgPlusIcon, btnAddPassenger, lblAddPassengerVerticalLine);
            var btnNextStep = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "48px",
                "id": "btnNextStep",
                "isVisible": true,
                "onClick": controller.AS_Button_hfd3b107f131452b9b50de2ca25499ca,
                "right": "30px",
                "skin": "CopyCopydefBtnNormal0a6835a37c10c44",
                "text": "Save",
                "top": "600px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTravellerEditDetails.add(lblTravellerDetailsDashboard, lblName, TextFieldName, lblMobile, TextFieldMobile, lblRoomNo, TextFieldRoomNo, lblSiterepName, TextFieldSiterepName, lblUserID, TextFieldUserID, flxSegData, flxAddPassenger, btnNextStep);
            var FlxRoute = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "239px",
                "id": "FlxRoute",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "10px",
                "width": "496px",
                "zIndex": 1
            }, {}, {});
            FlxRoute.setDefaultUnit(kony.flex.DP);
            var lblRouteHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Route Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRouteDetailsEdit = new kony.ui.Image2({
                "height": "24px",
                "id": "imgRouteDetailsEdit",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_a9cc44748d624fa09bbffdcb76839ad6,
                "right": "30px",
                "skin": "slImage",
                "src": "edit.png",
                "top": "30px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteFrom = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteFrom",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "From",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteFromValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblRouteFromValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "123 Backer Street",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteTo = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteTo",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "To",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteToValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblRouteToValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "221 Birmingham Street",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteCheckIn = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteCheckIn",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Checkin Details",
                "top": "173px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteCheckInValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblRouteCheckInValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "3 Hour time frame based Check ins",
                "top": "193px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteStartDate = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteStartDate",
                "isVisible": true,
                "right": "76px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Start",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteStartDateValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblRouteStartDateValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "25 Sep  10:10 AM",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteArrivalDate = new kony.ui.Label({
                "height": "21px",
                "id": "lblRouteArrivalDate",
                "isVisible": true,
                "right": "76px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Arrival",
                "top": "117px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRouteArrivalDateValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblRouteArrivalDateValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "25 Sep  4:10 PM",
                "top": "137px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRoute.add(lblRouteHeader, imgRouteDetailsEdit, lblRouteFrom, lblRouteFromValue, lblRouteTo, lblRouteToValue, lblRouteCheckIn, lblRouteCheckInValue, lblRouteStartDate, lblRouteStartDateValue, lblRouteArrivalDate, lblRouteArrivalDateValue);
            var flxRouteDetailsEdit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxRouteDetailsEdit",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "400px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "390px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxRouteDetailsEdit.setDefaultUnit(kony.flex.DP);
            var lblRouteDetailsHeader = new kony.ui.Label({
                "height": "32px",
                "id": "lblRouteDetailsHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopykonyqfsSknLblRouteDetailsHeader0e03edbb23c9c4e",
                "text": "Route Details",
                "top": "50px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var FlxEditRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "322px",
                "id": "FlxEditRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0ifab49c9e81f43",
                "top": "101px",
                "width": "380px",
                "zIndex": 1
            }, {}, {});
            FlxEditRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblDepatureDetailsHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblDepatureDetailsHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Departure Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDepature = new kony.ui.Image2({
                "height": "16px",
                "id": "imgDepature",
                "isVisible": true,
                "left": "30px",
                "right": "30px",
                "skin": "slImage",
                "src": "departurepoint_2.png",
                "top": "71px",
                "width": "16px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDepartureFrom = new kony.ui.Label({
                "height": "21px",
                "id": "lblDepartureFrom",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "From",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDepartureFromValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblDepartureFromValue",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "123 Backer Street",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTo = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalTo",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "To",
                "top": "178px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalToValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblArrivalToValue",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "221 Birmingham Street",
                "top": "198px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStartTime = new kony.ui.Label({
                "height": "21px",
                "id": "lblStartTime",
                "isVisible": true,
                "right": "76px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "Start",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStartTimeValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblStartTimeValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "25 Sep  10:10 AM",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTime = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalTime",
                "isVisible": true,
                "right": "76px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "Arrival",
                "top": "178px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTimeValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblArrivalTimeValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "25 Sep  4:10 PM",
                "top": "198px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgArrival = new kony.ui.Image2({
                "height": "16px",
                "id": "imgArrival",
                "isVisible": true,
                "left": "30px",
                "right": "30px",
                "skin": "slImage",
                "src": "arrival.png",
                "top": "178px",
                "width": "16px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditDepartureDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "48px",
                "id": "btnEditDepartureDetails",
                "isVisible": true,
                "left": "240px",
                "onClick": controller.AS_Button_cd87da0ce5574c9aa1894db88bc3956d,
                "skin": "CopyCopydefBtnNormal2",
                "text": "EDIT",
                "top": "244px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalDetails = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalDetails",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Arrival Details",
                "top": "137px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxEditRouteDetails.add(lblDepatureDetailsHeader, imgDepature, lblDepartureFrom, lblDepartureFromValue, lblArrivalTo, lblArrivalToValue, lblStartTime, lblStartTimeValue, lblArrivalTime, lblArrivalTimeValue, imgArrival, btnEditDepartureDetails, lblArrivalDetails);
            var FlxCheckinDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "380px",
                "id": "FlxCheckinDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0cdf27c4481e445",
                "top": "450px",
                "width": "380px",
                "zIndex": 1
            }, {}, {});
            FlxCheckinDetails.setDefaultUnit(kony.flex.DP);
            var lblCheckInDetailsHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblCheckInDetailsHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Checkin Details",
                "top": "30px",
                "width": "128px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLocationCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxLocationCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "71dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxLocationCheckin.setDefaultUnit(kony.flex.DP);
            var lblLocationCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblLocationCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Location Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLocationCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnLocationCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLocationCheckin = new kony.ui.Image2({
                "height": "24px",
                "id": "imgLocationCheckin",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "15dp",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLocationCheckin.add(lblLocationCheckin, btnLocationCheckin, imgLocationCheckin);
            var flxTimeBasedCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxTimeBasedCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d86d16bd16e9465097a0668693efff40,
                "skin": "slFbox",
                "top": "137dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxTimeBasedCheckin.setDefaultUnit(kony.flex.DP);
            var lblTimeBasedCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblTimeBasedCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Time based Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTimeBasedCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnTimeBasedCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgTimeBasedCheckin = new kony.ui.Image2({
                "height": "24px",
                "id": "imgTimeBasedCheckin",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "selected.png",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTimeBasedCheckin.add(lblTimeBasedCheckin, btnTimeBasedCheckin, imgTimeBasedCheckin);
            var flxNoCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxNoCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ff2e3bed761447898dd5da627af06063,
                "skin": "slFbox",
                "top": "309px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxNoCheckin.setDefaultUnit(kony.flex.DP);
            var lblNoCheckins = new kony.ui.Label({
                "height": "56px",
                "id": "lblNoCheckins",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "No Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNoCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnNoCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgNoCheckins = new kony.ui.Image2({
                "height": "24px",
                "id": "imgNoCheckins",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoCheckin.add(lblNoCheckins, btnNoCheckin, imgNoCheckins);
            var lblCheckinTime = new kony.ui.Label({
                "height": "16px",
                "id": "lblCheckinTime",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0ib840098134844",
                "text": "Checkin Time Frame",
                "top": "215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var listboxTimeFrame = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "48px",
                "id": "listboxTimeFrame",
                "isVisible": true,
                "left": "30px",
                "masterData": [
                    ["lb1", "3 hours frame"],
                    ["lb2", "2 hours frame"],
                    ["lb3", "1 hour frame"]
                ],
                "onSelection": controller.AS_ListBox_ebd2f007c51546f4954afe1f17713ea5,
                "selectedKey": "lb1",
                "selectedKeyValue": ["lb1", "3 hours frame"],
                "skin": "CopydefListBoxNormal0b7f0f262408e43",
                "top": "241px",
                "width": "330px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblHorizontalLine = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "368px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHorizontalLineOne = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLineOne",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "129px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHorizontalLineTwo = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLineTwo",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "194px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxCheckinDetails.add(lblCheckInDetailsHeader, flxLocationCheckin, flxTimeBasedCheckin, flxNoCheckin, lblCheckinTime, listboxTimeFrame, lblHorizontalLine, lblHorizontalLineOne, lblHorizontalLineTwo);
            var flxDepartureArrivalFields = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "840px",
                "id": "flxDepartureArrivalFields",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "80px",
                "width": "380px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDepartureArrivalFields.setDefaultUnit(kony.flex.DP);
            var DepartureDetails = new com.konyqfs.placeDetails({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50%",
                "id": "DepartureDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "flxParentSkn",
                "top": "100%",
                "width": "100%",
                "overrides": {
                    "placeDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "retainFlowHorizontalAlignment": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            DepartureDetails.startYear = 1980;
            DepartureDetails.endYear = 2025;
            DepartureDetails.onDone = controller.AS_UWI_c77425f6e5074a2ea61abab4c1276be5;
            var ArrivalDetails = new com.konyqfs.placeDetails({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50%",
                "id": "ArrivalDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "flxParentSkn",
                "top": "100%",
                "width": "100%",
                "overrides": {
                    "lblHeader": {
                        "text": "Arrival Details"
                    },
                    "lblInnerFieldTitle": {
                        "text": "Choose Arrival Point"
                    },
                    "lblInnerFieldTitle2": {
                        "text": "Set a Arrival Date"
                    },
                    "lblInnerFieldTitle3": {
                        "text": "Set a Arrival Time"
                    },
                    "placeDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "retainFlowHorizontalAlignment": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            ArrivalDetails.startYear = 1980;
            ArrivalDetails.endYear = 2025;
            ArrivalDetails.onDone = controller.AS_UWI_i5e8da0e95b245a39adea9484bc68dfb;
            flxDepartureArrivalFields.add(DepartureDetails, ArrivalDetails);
            var btnNext = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "48px",
                "id": "btnNext",
                "isVisible": true,
                "onClick": controller.AS_Button_d8f09bcd0ea9497cb2919f64be48207c,
                "right": "30px",
                "skin": "CopyCopydefBtnNormal2",
                "text": "Save",
                "top": "878px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rchTextNext = new kony.ui.RichText({
                "height": "17px",
                "id": "rchTextNext",
                "isVisible": false,
                "linkSkin": "defRichTextLink",
                "right": "195px",
                "skin": "CopydefRichTextNormal0db697b0963a140",
                "text": "Next step:<b>Tracking Details</B>",
                "top": "936px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRouteDetailsEdit.add(lblRouteDetailsHeader, FlxEditRouteDetails, FlxCheckinDetails, flxDepartureArrivalFields, btnNext, rchTextNext);
            var FlxTrack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "239px",
                "id": "FlxTrack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "10px",
                "width": "496px",
                "zIndex": 1
            }, {}, {});
            FlxTrack.setDefaultUnit(kony.flex.DP);
            var lblTrackerHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Tracking Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgTrackerDetailsEdit = new kony.ui.Image2({
                "height": "24px",
                "id": "imgTrackerDetailsEdit",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_d949b334e5ef4a838a2cc95008d01237,
                "right": "30px",
                "skin": "slImage",
                "src": "edit.png",
                "top": "30px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerReason = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerReason",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Reason for Journey",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerReasonValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerReasonValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Exploration",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerSupervisor = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerSupervisor",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Supervisor ",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerSupervisorValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerSupervisorValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Mo Chun",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerSiderep = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerSiderep",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Employee ID",
                "top": "173px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerSiderepValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerSiderepValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Pol Soria",
                "top": "193px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerMobile = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerMobile",
                "isVisible": true,
                "left": "127px",
                "right": "76px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Mobile Phone Number",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerMobileValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerMobileValue",
                "isVisible": true,
                "left": "127px",
                "right": 127,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "094-228-0095",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerPhone = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerPhone",
                "isVisible": false,
                "left": "127px",
                "right": "76px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Phone Number",
                "top": "173px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerPhoneValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerPhoneValue",
                "isVisible": false,
                "left": "127px",
                "right": 30,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "912-3822-6312721",
                "top": "193px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerCPN = new kony.ui.Label({
                "height": "21px",
                "id": "lblTrackerCPN",
                "isVisible": true,
                "right": "83px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "CRN",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackerCPNValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblTrackerCPNValue",
                "isVisible": true,
                "right": 83,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "32",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrack.add(lblTrackerHeader, imgTrackerDetailsEdit, lblTrackerReason, lblTrackerReasonValue, lblTrackerSupervisor, lblTrackerSupervisorValue, lblTrackerSiderep, lblTrackerSiderepValue, lblTrackerMobile, lblTrackerMobileValue, lblTrackerPhone, lblTrackerPhoneValue, lblTrackerCPN, lblTrackerCPNValue);
            var flxTrackDetailsEdit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "926px",
                "id": "flxTrackDetailsEdit",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "400px",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "10px",
                "width": "390px",
                "zIndex": 1
            }, {}, {});
            flxTrackDetailsEdit.setDefaultUnit(kony.flex.DP);
            var lblTrackingHeader = new kony.ui.Label({
                "height": "37px",
                "id": "lblTrackingHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Tracking Details",
                "top": "90px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingSubheader = new kony.ui.Label({
                "height": "20px",
                "id": "lblTrackingSubheader",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Reason for journey",
                "top": "141px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupervisor = new kony.ui.Label({
                "id": "lblSupervisor",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0bf1f22f2d0884b",
                "text": "Supervisor",
                "top": "245px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNameSupervisor = new kony.ui.Label({
                "height": "16px",
                "id": "lblNameSupervisor",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Name",
                "top": "289px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldNameSupervisor = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldNameSupervisor",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "Mo Chun",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "310px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobileHeader = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobileHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Mobile Phone Number",
                "top": "378px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldMobileValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldMobileValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "094-228-0095",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "399px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRoomNoHeader = new kony.ui.Label({
                "height": "16px",
                "id": "lblRoomNoHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Camp Room Number",
                "top": "467px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldRoomNoValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldRoomNoValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "32",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "488px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblSiterep = new kony.ui.Label({
                "id": "lblSiterep",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0bf1f22f2d0884b",
                "text": "Siterep",
                "top": "581px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSiterepNameHeader = new kony.ui.Label({
                "height": "16px",
                "id": "lblSiterepNameHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Name",
                "top": "625px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldSiterepNameValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldSiterepNameValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "Mo Chun",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "646px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobileNumber = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobileNumber",
                "isVisible": true,
                "left": "30px",
                "skin": "lblName",
                "text": "Mobile Phone Number",
                "top": "716px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxMobileNumber = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "txtboxMobileNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30px",
                "placeholder": "094-228-0095",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "735px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnTrackingDetailsSave = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50px",
                "id": "btnTrackingDetailsSave",
                "isVisible": true,
                "onClick": controller.AS_Button_ae1b928820144a0c864386035a401d91,
                "right": "30px",
                "skin": "CopyCopydefBtnNormal4",
                "text": "Save",
                "top": "823px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var listboxData = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "56px",
                "id": "listboxData",
                "isVisible": true,
                "left": "30px",
                "masterData": [
                    ["lbl1", "One"],
                    ["lb2", "Two"],
                    ["lb3", "Three"]
                ],
                "onSelection": controller.AS_ListBox_g453d0505ca84c51bb01608686fc2432,
                "selectedKey": "lbl1",
                "selectedKeyValue": ["lbl1", "One"],
                "skin": "defListBoxNormal",
                "top": "165px",
                "width": "343px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var rchtxtNextStep = new kony.ui.RichText({
                "height": "14px",
                "id": "rchtxtNextStep",
                "isVisible": false,
                "left": "408px",
                "linkSkin": "defRichTextLink",
                "skin": "CopyCopydefRichTextNormal",
                "text": "Next step:<b>Vehicle Details</B>",
                "top": "880px",
                "width": "145px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTrackDetailsEdit.add(lblTrackingHeader, lblTrackingSubheader, lblSupervisor, lblNameSupervisor, TextFieldNameSupervisor, lblMobileHeader, TextFieldMobileValue, lblRoomNoHeader, TextFieldRoomNoValue, lblSiterep, lblSiterepNameHeader, TextFieldSiterepNameValue, lblMobileNumber, txtboxMobileNumber, btnTrackingDetailsSave, listboxData, rchtxtNextStep);
            var FlxVehicle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "188px",
                "id": "FlxVehicle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0a406d21e333840",
                "top": "10px",
                "width": "496px",
                "zIndex": 1
            }, {}, {});
            FlxVehicle.setDefaultUnit(kony.flex.DP);
            var lblVehicleHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblVehicleHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Vehicle Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleDetailsEdit = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleDetailsEdit",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_ba5d7fc138b44b4cadf835c8368c0da5,
                "right": "30px",
                "skin": "slImage",
                "src": "edit.png",
                "top": "30px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleCompany = new kony.ui.Label({
                "height": "21px",
                "id": "lblVehicleCompany",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Company Car",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleCompanyValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblVehicleCompanyValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Ford Focus",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleColor = new kony.ui.Label({
                "height": "21px",
                "id": "lblVehicleColor",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Color",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleColorValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblVehicleColorValue",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "Red",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleRegistration = new kony.ui.Label({
                "height": "21px",
                "id": "lblVehicleRegistration",
                "isVisible": true,
                "left": "127px",
                "right": "76px",
                "skin": "CopydefLabel0f6b9680067c840",
                "text": "Registration",
                "top": "122px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleRegistrationValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblVehicleRegistrationValue",
                "isVisible": true,
                "left": "127px",
                "right": 30,
                "skin": "CopydefLabel0e6f9d81902f84b",
                "text": "345226",
                "top": "142px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicle.add(lblVehicleHeader, imgVehicleDetailsEdit, lblVehicleCompany, lblVehicleCompanyValue, lblVehicleColor, lblVehicleColorValue, lblVehicleRegistration, lblVehicleRegistrationValue);
            var flxVehicleDetailsEdit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxVehicleDetailsEdit",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "400px",
                "isModalContainer": false,
                "skin": "CopyslFbox0cdf27c4481e445",
                "top": "10px",
                "width": "390px",
                "zIndex": 1
            }, {}, {});
            flxVehicleDetailsEdit.setDefaultUnit(kony.flex.DP);
            var lblVehicleHeaderEdit = new kony.ui.Label({
                "height": "21px",
                "id": "lblVehicleHeaderEdit",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0f728758dcb8445",
                "text": "Vehicle Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleType = new kony.ui.Label({
                "height": "24px",
                "id": "lblVehicleType",
                "isVisible": true,
                "left": "50px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Vehicle Type",
                "top": "25px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionOne = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionOne",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_bcb17fd203e84454bb3cee95f50484e3,
                "skin": "slFbox",
                "top": "10px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionOne.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionOne = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionOne",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Company Vehicle",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionOne = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionOne",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_f92d76e6f7f54b91b954f9943a334724,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionOne = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionOne",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionOne.add(lblVehicleOptionOne, btnVehicleOptionOne, imgVehicleOptionOne);
            var FlxCompanyVehicleListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "FlxCompanyVehicleListBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            FlxCompanyVehicleListBox.setDefaultUnit(kony.flex.DP);
            var listboxVehicleDetails = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "listboxVehicleDetails",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "onSelection": controller.AS_ListBox_b35a32c0b324406a97e99b19376aa256,
                "skin": "defListBoxNormal",
                "top": "18dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            FlxCompanyVehicleListBox.add(listboxVehicleDetails);
            var lblHorizontalLine1 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine1",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "5px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionTwo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionTwo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d9941a7222f645058d2c0b17bbcdd91f,
                "skin": "slFbox",
                "top": "5px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionTwo.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionTwo = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionTwo",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Personal Vehicle",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionTwo = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionTwo",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_hab5349f38c6411e9bc7676fac73f157,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionTwo = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionTwo",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionTwo.add(lblVehicleOptionTwo, btnVehicleOptionTwo, imgVehicleOptionTwo);
            var FlxPersonalVehicleListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "FlxPersonalVehicleListBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            FlxPersonalVehicleListBox.setDefaultUnit(kony.flex.DP);
            var listboxPersonalVehicleDetails = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "listboxPersonalVehicleDetails",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "onSelection": controller.AS_ListBox_addf7c9993cd4a23a692936e959973ff,
                "skin": "defListBoxNormal",
                "top": "18dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            FlxPersonalVehicleListBox.add(listboxPersonalVehicleDetails);
            var lblHorizontalLine2 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine2",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "5px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionThree = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionThree",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i62fdd33d13c446eaa4dee1004b47d61,
                "skin": "slFbox",
                "top": "5px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionThree.setDefaultUnit(kony.flex.DP);
            var lblNoCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblNoCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Decide Later",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "160dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "137dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            var imgDummy = new kony.ui.Image2({
                "height": "24px",
                "id": "imgDummy",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "10px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDummy = new kony.ui.Label({
                "height": "56px",
                "id": "lblDummy",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Time based Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDummy.add(imgDummy, lblDummy);
            var CopybtnNoCheckin0bad1a658c26c4f = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "CopybtnNoCheckin0bad1a658c26c4f",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionThree = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionThree",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionThree.add(lblNoCheckin, flxDummy, CopybtnNoCheckin0bad1a658c26c4f, imgVehicleOptionThree);
            var lblHorizontalLine3 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine3",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "5px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionFour = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionFour",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_be3e5b2341fa4009a3cadd5d0f84dd9e,
                "skin": "slFbox",
                "top": "5px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionFour.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionFour = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionFour",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Add New",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionFour = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionFour",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_fd31e3540c67443bb217af705cdcc47f,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionFour = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionFour",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionFour.add(lblVehicleOptionFour, btnVehicleOptionFour, imgVehicleOptionFour);
            var FlxAddNewVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxAddNewVehicleDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300px",
                "zIndex": 1
            }, {}, {});
            FlxAddNewVehicleDetails.setDefaultUnit(kony.flex.DP);
            var lblMake = new kony.ui.Label({
                "id": "lblMake",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Make",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxMake = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxMake",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "MAKE",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0if2ea817675d40",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblModel = new kony.ui.Label({
                "id": "lblModel",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Model",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxModel = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxModel",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "MODEL",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0c6674e5533a34b",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblColor = new kony.ui.Label({
                "id": "lblColor",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "color",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxColor = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxColor",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "COLOR",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0e5e8103747b64c",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRegistration = new kony.ui.Label({
                "height": "25px",
                "id": "lblRegistration",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Registration",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxRegistration = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxRegistration",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "1832 445",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0b224084407cb43",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblNewVehicleType = new kony.ui.Label({
                "height": "25px",
                "id": "lblNewVehicleType",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Vehicle Type",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxNewVehicleType = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxNewVehicleType",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Vehicle Type",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0b224084407cb43",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            FlxAddNewVehicleDetails.add(lblMake, txtboxMake, lblModel, txtboxModel, lblColor, txtboxColor, lblRegistration, txtboxRegistration, lblNewVehicleType, txtboxNewVehicleType);
            var lblHorizontalLine4 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine4",
                "isVisible": false,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "0px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleDetailsSave = new kony.ui.Button({
                "bottom": "10px",
                "focusSkin": "defBtnFocus",
                "height": "50px",
                "id": "btnVehicleDetailsSave",
                "isVisible": true,
                "onClick": controller.AS_Button_b77197ae36d340459b0acd143b4bc5a9,
                "right": "30px",
                "skin": "CopyCopydefBtnNormal4",
                "text": "Save",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleDetailsEdit.add(lblVehicleHeaderEdit, lblVehicleType, flxVehicleOptionOne, FlxCompanyVehicleListBox, lblHorizontalLine1, flxVehicleOptionTwo, FlxPersonalVehicleListBox, lblHorizontalLine2, flxVehicleOptionThree, lblHorizontalLine3, flxVehicleOptionFour, FlxAddNewVehicleDetails, lblHorizontalLine4, btnVehicleDetailsSave);
            var btnReviewNext = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnReviewNext",
                "isVisible": false,
                "left": "459px",
                "skin": "CopydefBtnNormal0b8aa8153bf694b",
                "text": "Next",
                "top": "605px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateJourney = new kony.ui.Button({
                "bottom": "10px",
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "50px",
                "id": "btnCreateJourney",
                "isVisible": true,
                "onClick": controller.AS_Button_he8598d2157a4fe08377f57876c1a4b7,
                "right": "0px",
                "skin": "CopydefBtnNormal0b8aa8153bf694b",
                "text": "Create Journey",
                "top": "22px",
                "width": "174px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReviewDashboardData.add(FlxTraveller, flxTravellerEditDetails, FlxRoute, flxRouteDetailsEdit, FlxTrack, flxTrackDetailsEdit, FlxVehicle, flxVehicleDetailsEdit, btnReviewNext, btnCreateJourney);
            RightFlex.add(lblReviewDashboard, flxReviewDashboardData);
            ParentFlex.add(LeftFlex, RightFlex);
            this.add(ParentFlex);
        };
        return [{
            "addWidgets": addWidgetsfrmReviewDetails,
            "enabledForIdleTimeout": false,
            "id": "frmReviewDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_j06e86a003914ed693f20394f70419a2,
            "skin": "CopyslForm0i5998a1253b94a",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});