define("frmJourneyList", function() {
    return function(controller) {
        function addWidgetsfrmJourneyList() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minWidth": "1200dp",
                "isModalContainer": false,
                "skin": "sknFlxBGFAFAFA",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minWidth": "330dp",
                "isModalContainer": false,
                "skin": "sknFlxBGFAFAFA",
                "top": "0dp",
                "width": "29.20%",
                "zIndex": 1
            }, {}, {});
            flxMenu.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBGWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var jrmgmtheader = new com.konysa.jrmgmtheader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "jrmgmtheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxBGWhite",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "jrmgmtheader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            jrmgmtheader.onClickOfBtnRefresh = controller.AS_UWI_dfe28cbc07b146eebac9384118b0218c;
            jrmgmtheader.onClickOfFlxRefresh = controller.AS_UWI_haf809f07eb74af7b56559ff1efa5bb6;
            jrmgmtheader.onClickOfLogOut = controller.AS_UWI_b48b864a89b24621bd8c9ab45f09f98e;
            jrmgmtheader.onAddClick = controller.AS_UWI_j786026f97f942afad8ad7d1cc8bcd0a;
            jrmgmtheader.onBellClick = controller.AS_UWI_i1492552b8454295914be88b92e2fa59;
            jrmgmtheader.onLogOutClick = controller.AS_UWI_a1ec3a9f842b46fc97bea1a913bb407e;
            flxHeader.add(jrmgmtheader);
            var flxNotify = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxNotify",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxNotify.setDefaultUnit(kony.flex.DP);
            var btnNotify = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "defBtnFocus",
                "height": "60%",
                "id": "btnNotify",
                "isVisible": true,
                "onClick": controller.AS_Button_b57cecbbb3824538a95782e6c68da03d,
                "right": "10%",
                "skin": "konyqfsSknBtnNotify",
                "text": "Notify",
                "top": "3%",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedData = new kony.ui.Label({
                "centerY": "50%",
                "height": "20px",
                "id": "lblSelectedData",
                "isVisible": true,
                "left": "10%",
                "skin": "konyqfsSknLblSelectedData",
                "text": "1 selected journey",
                "top": "29dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotify.add(btnNotify, lblSelectedData);
            var flxScMenuRoot = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "10dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxScMenuRoot",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "right": "-16dp",
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "70dp",
                "verticalScrollIndicator": false,
                "zIndex": 1
            }, {}, {});
            flxScMenuRoot.setDefaultUnit(kony.flex.DP);
            var flxTabPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "44dp",
                "id": "flxTabPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTabPane.setDefaultUnit(kony.flex.DP);
            var tabpane = new com.konysa.tabpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "tabpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_af2db03d134f47e28f7d937b99e7d15b,
                "right": "30dp",
                "skin": "sknFlxBgWhiteBorder575ee7",
                "top": "0dp",
                "overrides": {
                    "tabpane": {
                        "bottom": "viz.val_cleared",
                        "width": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            tabpane.allTabOnClick = controller.AS_UWI_f4d1aac08cf84e3d84e1e8f61610ff03;
            tabpane.delayTabOnClick = controller.AS_UWI_fe41a29704c24646bd04c502239cb139;
            tabpane.incidentTabOnClick = controller.AS_UWI_b895d26363dd4362bcca5ebe7f0fae72;
            tabpane.liveTabOnClick = controller.AS_UWI_b9a975eb2e0444478ea830e8aa80d91a;
            flxTabPane.add(tabpane);
            var flxSearchNFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSearchNFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSearchNFilter.setDefaultUnit(kony.flex.DP);
            var searchnfilter = new com.konysa.searchnfilter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "searchnfilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "10dp",
                "overrides": {
                    "searchnfilter": {
                        "bottom": "viz.val_cleared",
                        "width": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            searchnfilter.selectedIndices = "";
            searchnfilter.closeFilter = controller.AS_UWI_c298512c399548a7b7a69d76b44a73dd;
            searchnfilter.closeSearch = controller.AS_UWI_e8b65465ec5a4bb586e9612ff504defd;
            searchnfilter.onDoneOfTxtBoxUser = controller.AS_UWI_cc729a4bce26407b931a50744ecddaa0;
            searchnfilter.onSelectionCallBack = controller.AS_UWI_hf26053530b44be8a82ab81691e661fa;
            searchnfilter.onSelectionOfTrackingPoints = controller.AS_UWI_be962e8d47ca44bbad6ac766e74cc63b;
            searchnfilter.onSelectionOfTrackingPointsSegment = controller.AS_UWI_adc89a31cd9d42c59c14efa883a7b57c;
            flxSearchNFilter.add(searchnfilter);
            var flxJourneyRootList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxJourneyRootList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "99.50%",
                "zIndex": 1
            }, {}, {});
            flxJourneyRootList.setDefaultUnit(kony.flex.DP);
            var segJourneyList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgCheckIn": "chechbox_unselected.png",
                    "imgMenu": "menu_icon.png",
                    "lblActionText": "Contact Supervisor",
                    "lblDriverName": "Peter Oliver",
                    "lblETA": "ETA",
                    "lblEmailID": "Label",
                    "lblFooter2": "",
                    "lblJourneyStatus": "Normal",
                    "lblLastKnownLocation": "10 Georgetown Street",
                    "lblLastKonwnLocationTitle": "Last Known Location",
                    "lblShadow": "Label",
                    "lblTime": "28 Jun, 16:10 PM"
                }],
                "groupCells": false,
                "height": "850dp",
                "id": "segJourneyList",
                "isVisible": true,
                "left": "2dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_ff39eb080d91432b8e795d455b73ea4f,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "Copyseg0ab658126fa534b",
                "rowTemplate": "flxRootJourneyCard",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_MULTI_SELECT_BEHAVIOR,
                "selectionBehaviorConfig": {
                    "imageIdentifier": "imgCheckIn",
                    "selectedStateImage": "checkbox_selected.png",
                    "unselectedStateImage": "chechbox_unselected.png"
                },
                "separatorColor": "fafafa00",
                "separatorRequired": true,
                "separatorThickness": 10,
                "showScrollbars": false,
                "top": 0,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAction": "flxAction",
                    "flxActionRoot": "flxActionRoot",
                    "flxCheckIn": "flxCheckIn",
                    "flxContainer": "flxContainer",
                    "flxJourneyCardHeader": "flxJourneyCardHeader",
                    "flxLocationTime": "flxLocationTime",
                    "flxMenu": "flxMenu",
                    "flxRoot": "flxRoot",
                    "flxRootJourneyCard": "flxRootJourneyCard",
                    "flxTitle": "flxTitle",
                    "imgCheckIn": "imgCheckIn",
                    "imgMenu": "imgMenu",
                    "lblActionText": "lblActionText",
                    "lblDriverName": "lblDriverName",
                    "lblETA": "lblETA",
                    "lblEmailID": "lblEmailID",
                    "lblFooter2": "lblFooter2",
                    "lblJourneyStatus": "lblJourneyStatus",
                    "lblLastKnownLocation": "lblLastKnownLocation",
                    "lblLastKonwnLocationTitle": "lblLastKonwnLocationTitle",
                    "lblShadow": "lblShadow",
                    "lblTime": "lblTime"
                },
                "width": "99.90%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxJourneyRootList.add(segJourneyList);
            flxScMenuRoot.add(flxTabPane, flxSearchNFilter, flxJourneyRootList);
            var flxJourneyDetail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxJourneyDetail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknFlxBGWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10
            }, {}, {});
            flxJourneyDetail.setDefaultUnit(kony.flex.DP);
            var journeydetail = new com.konysa.journeydetail({
                "bottom": "0dp",
                "clipBounds": true,
                "id": "journeydetail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "30dp",
                "overrides": {
                    "journeydetail": {
                        "width": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            journeydetail.onClickOfCreateCheckInBtn = controller.AS_UWI_b44b68f718674cf79bfce23916b9d888;
            journeydetail.onBackClick = controller.AS_UWI_c5da25c5417949619c75f4d5f3b61c21;
            journeydetail.actionOfChangeETABtn = controller.AS_UWI_bb69736aa78c4ff98c2341b70f7eb166;
            journeydetail.actionOfCloseJourneyBtn = controller.AS_UWI_b7eb136173be48d6858d7a3792c08317;
            flxJourneyDetail.add(journeydetail);
            var flxNotificationContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "90%",
                "id": "flxNotificationContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 15
            }, {}, {});
            flxNotificationContainer.setDefaultUnit(kony.flex.DP);
            var imgUpArraow = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgUpArraow",
                "isVisible": true,
                "right": "50dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNotificationRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNotificationRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "57dp",
                "isModalContainer": false,
                "right": "17dp",
                "skin": "sknFlxBGWhiteBoxShadow2",
                "top": "17dp",
                "zIndex": 1
            }, {}, {});
            flxNotificationRoot.setDefaultUnit(kony.flex.DP);
            var flxNotificationTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "21dp",
                "id": "flxNotificationTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0b648fd2600c248",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxNotificationTitle.setDefaultUnit(kony.flex.DP);
            var lblNotification = new kony.ui.Label({
                "height": "100%",
                "id": "lblNotification",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblBGTransFont545963",
                "text": "Notifications",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseNotificationMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCloseNotificationMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f9751b35941e48eda431984dd5429073,
                "right": "32dp",
                "skin": "sknFlxBGTransCursorPointer",
                "width": "20dp",
                "zIndex": 1
            }, {}, {});
            flxCloseNotificationMsg.setDefaultUnit(kony.flex.DP);
            var imgCloseNotificationMsg = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgCloseNotificationMsg",
                "isVisible": true,
                "skin": "slImage",
                "src": "close_search.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseNotificationMsg.add(imgCloseNotificationMsg);
            flxNotificationTitle.add(lblNotification, flxCloseNotificationMsg);
            var segNotificationMsg = new kony.ui.SegmentedUI2({
                "alternateRowSkin": "sknSegBGfafafa",
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblMsg": "",
                    "lblNotificationMsg": "",
                    "lblNotificationSymbol": "",
                    "lblTime": ""
                }],
                "groupCells": false,
                "id": "segNotificationMsg",
                "isVisible": true,
                "left": "0dp",
                "maxHeight": "600dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxNotificationRoot",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "61dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxNotificationIcon": "flxNotificationIcon",
                    "flxNotificationRoot": "flxNotificationRoot",
                    "flxTitle": "flxTitle",
                    "lblMsg": "lblMsg",
                    "lblNotificationMsg": "lblNotificationMsg",
                    "lblNotificationSymbol": "lblNotificationSymbol",
                    "lblTime": "lblTime"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotificationRoot.add(flxNotificationTitle, segNotificationMsg);
            flxNotificationContainer.add(imgUpArraow, flxNotificationRoot);
            flxMenu.add(flxHeader, flxNotify, flxScMenuRoot, flxJourneyDetail, flxNotificationContainer);
            var flxMap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMap",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29.20%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "zIndex": 1
            }, {}, {});
            flxMap.setDefaultUnit(kony.flex.DP);
            var journeymap = new com.konysa.journeymap({
                "clipBounds": true,
                "height": "100%",
                "id": "journeymap",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "journeymap": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            journeymap.mapKey = "AIzaSyBeIDNhaa-u8IZcdqkNub-N648OCzb9QH4";
            var vuegooglemaps = new com.konymp.vuegooglemaps({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "vuegooglemaps",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "vuegooglemaps": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            vuegooglemaps.centerLat = "17.3850";
            vuegooglemaps.mapType = "satellite";
            vuegooglemaps.addMarkerLat = "";
            vuegooglemaps.googleApiKey = "AIzaSyBeIDNhaa-u8IZcdqkNub-N648OCzb9QH4";
            vuegooglemaps.mapZoom = 12;
            vuegooglemaps.centerLong = " 78.4867";
            vuegooglemaps.addMarkerLong = "";
            vuegooglemaps.addMarkerText = "";
            flxMap.add(journeymap, vuegooglemaps);
            flxRoot.add(flxMenu, flxMap);
            var flxEscalationpolocy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxEscalationpolocy",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEscalationpolocy.setDefaultUnit(kony.flex.DP);
            var escalationpolicy = new com.konysa.escalationpolicy({
                "clipBounds": true,
                "height": "100%",
                "id": "escalationpolicy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxBGBlackOpacity20",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "escalationpolicy": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            escalationpolicy.onClickOfContactDriverCancel = controller.AS_UWI_fcac8f9a51b14028bfe32d22f295ede4;
            escalationpolicy.onClickOfFlxCancel = controller.AS_UWI_d0f10c94b0344f5b891789b0d76dc80d;
            escalationpolicy.onClickOfNoCancelAction = controller.AS_UWI_f323da83d81b451f8e1bdb73ddc33b10;
            escalationpolicy.onClickOfNoContinueAction = controller.AS_UWI_h26099c71eb74b7e90f8985714787583;
            escalationpolicy.onClickOfYesCancelAction = controller.AS_UWI_c9fb0a45516d4a06a88bb4cb521d9199;
            escalationpolicy.onClickofYesContinueAction = controller.AS_UWI_d6225be8372c43fbafef78ef9ffb9a5a;
            flxEscalationpolocy.add(escalationpolicy);
            var flxETA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxETA",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxETA.setDefaultUnit(kony.flex.DP);
            var ETAReporting = new com.konysa.ETAReporting({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "ETAReporting",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyCopyflxBackgroundAlertSkn1",
                "top": "0%",
                "width": "100%",
                "overrides": {
                    "ETAReporting": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            ETAReporting.onClickOfUpdateETA = controller.AS_UWI_d63b8ae9a0d447cca32abc2ace40ab51;
            ETAReporting.onClickOfUpdateETACancel = controller.AS_UWI_ib866057f3684175914841f498b8dd82;
            flxETA.add(ETAReporting);
            var flxTerminateJourney = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTerminateJourney",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTerminateJourney.setDefaultUnit(kony.flex.DP);
            var terminateJourney = new com.konysa.terminateJourney({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "terminateJourney",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyCopyflxBackgroundAlertSkn1",
                "top": "0%",
                "width": "100%",
                "overrides": {
                    "terminateJourney": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            terminateJourney.OnClickOfTerminateJourneyConform = controller.AS_UWI_f592aec7a5b7468099a9621941e42083;
            terminateJourney.onClickOfTerminateJourneyCancel = controller.AS_UWI_d73cad65855546e6a6740b73018e0284;
            flxTerminateJourney.add(terminateJourney);
            this.add(flxRoot, flxEscalationpolocy, flxETA, flxTerminateJourney);
        };
        return [{
            "addWidgets": addWidgetsfrmJourneyList,
            "enabledForIdleTimeout": false,
            "id": "frmJourneyList",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_h753595f0f374d7dab4279b72929e2ef,
            "preShow": function(eventobject) {
                controller.AS_Form_b2ff41a7dfef4076a7d6f6811c686f68(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});