var methodInNativeContext = function() {
  (kony.evaluateJavaScriptInNativeContext("NativeContextMethod();"));
};
window.onload = function() {
  setTimeout(function() { methodInNativeContext(); }, 100);
};

var VueJSGoogleMapObj;
function AppJSContextApplyProperties(ExposedProperties) {
  Vue.use(VueGoogleMaps, {
    load: {
      key: ExposedProperties.GoogleAPIKey
    },
  });
  VueJSGoogleMapObj = new Vue({
    el: '#root',
    data: {
      polygonsList: {
        "polygons": [
        ]
      },
      polylinesList: {
        "polylines": [
                     ]
      },

      center: {
        lat: parseFloat(ExposedProperties.CenterLat),
        lng: parseFloat(ExposedProperties.CenterLong)
      },
      zoom: ExposedProperties.AllowMapZoom,
      maptypeid: ExposedProperties.MapType,
      options: {
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: true,
        streetViewControl: false,
        rotateControl: true,
        scrollwheel: true,
        fullscreenControl: true,
        disableDefaultUi: false
      },
      infoContent: 'Hello World',
      infoWindowPos: null,
      infoWinOpen: false,
      currentMidx: null,
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -35
        }
      },
      markers: [{
        position: {
          lat: parseFloat(ExposedProperties.AddMarkerLat),
          lng: parseFloat(ExposedProperties.AddMarkerLong)
        },
        infoText: ExposedProperties.AddMarkerText
      }]
    },
    methods: {
      toggleInfoWindow: function(marker, idx) {
        this.infoWindowPos = marker.position;
        this.infoContent = marker.infoText;
        if (this.currentMidx == idx) {
          this.infoWinOpen = !this.infoWinOpen;
        }
        else {
          this.infoWinOpen = true;
          this.currentMidx = idx;
        }
      },
      mapClicked(mouseArgs) {
        onMapClicks(mouseArgs);
      },
      mapRClicked(mouseArgs) {
        onMapRClicks(mouseArgs);
      },
      showDescPolygon(event, desc) {
        var contentString = desc;
        this.infoWindowPos = event.latLng;
        this.infoContent = contentString;
        this.infoWinOpen = true;
      },
      addPolygon:function(data)
      {
        this.polygonsList.polygons.push(data);
      },
      addPolyline:function(data)
      {
        this.polylinesList.polylines.push(data);
      },
      addMarker: function addMarker(data) {
        this.markers.push({
          position: data.position,
          opacity: 1,
          draggable: true,
          enabled: true,
          clicked: 0,
          rightClicked: 0,
          dragended: 0,
          ifw: true,
          infoText: data.text
        });
        return this.markers[this.markers.length - 1];
      }
    }
  });
}
function onMapClicks(mouseArgs)
{
  (kony.evaluateJavaScriptInNativeContext("onMapClickEvent(" + JSON.stringify(mouseArgs) + ")"));
}
function onMapRClicks(mouseArgs)
{
  (kony.evaluateJavaScriptInNativeContext("onMapRightClickEvent(" + JSON.stringify(mouseArgs) + ")"));
}
function addMarkerAppJSContext(data) {
  VueJSGoogleMapObj.addMarker(data);
}
function addPolygonAppJSContext(data) {
  VueJSGoogleMapObj.addPolygon(data);
}
function addPolylineAppJSContext(data) {
  VueJSGoogleMapObj.addPolyline(data);
}