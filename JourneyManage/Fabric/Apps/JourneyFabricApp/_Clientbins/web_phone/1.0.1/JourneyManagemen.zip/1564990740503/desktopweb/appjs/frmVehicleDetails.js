define("frmVehicleDetails", function() {
    return function(controller) {
        function addWidgetsfrmVehicleDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var ParentFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1800px",
                "id": "ParentFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0e6c89439fd1844",
                "top": "0px",
                "width": "1440px",
                "zIndex": 1
            }, {}, {});
            ParentFlex.setDefaultUnit(kony.flex.DP);
            var RightFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "RightFlex",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "330px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0e818de43d74e40",
                "top": "0px",
                "width": "780px",
                "zIndex": 1
            }, {}, {});
            RightFlex.setDefaultUnit(kony.flex.DP);
            var lblVehicleHeader = new kony.ui.Label({
                "height": "31px",
                "id": "lblVehicleHeader",
                "isVisible": true,
                "left": "195px",
                "skin": "CopyCopydefLabel0bcdac1f0930c40",
                "text": "Vehicle Details",
                "top": "90px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleDetailsDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxVehicleDetailsDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "195px",
                "isModalContainer": false,
                "skin": "CopyslFbox0cdf27c4481e445",
                "top": "30px",
                "width": "390px",
                "zIndex": 1
            }, {}, {});
            flxVehicleDetailsDashboard.setDefaultUnit(kony.flex.DP);
            var lblVehicleType = new kony.ui.Label({
                "height": "24px",
                "id": "lblVehicleType",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Vehicle Type",
                "top": "30px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionOne = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionOne",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d92c6534c62a4dfebabfeb9fd767d96a,
                "skin": "slFbox",
                "top": "40dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionOne.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionOne = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionOne",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Company Vehicle",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionOne = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionOne",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_c0c96c3dce8846a38a6ec4a40b0dd6a3,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionOne = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionOne",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionOne.add(lblVehicleOptionOne, btnVehicleOptionOne, imgVehicleOptionOne);
            var FlxCompanyVehicleListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "FlxCompanyVehicleListBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            FlxCompanyVehicleListBox.setDefaultUnit(kony.flex.DP);
            var listboxVehicleDetails = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "listboxVehicleDetails",
                "isVisible": true,
                "left": "0dp",
                "onSelection": controller.AS_ListBox_j3635c98820546da927cd06d0b04f941,
                "skin": "defListBoxNormal",
                "top": "18dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            FlxCompanyVehicleListBox.add(listboxVehicleDetails);
            var lblHorizontalLine1 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine1",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "20px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionTwo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionTwo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_cd22b74e88fb47e4bf244c8a07ebd726,
                "skin": "slFbox",
                "top": "10dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionTwo.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionTwo = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionTwo",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Personal Vehicle",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionTwo = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionTwo",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_b4e09ab756da4f8c9adecb5d3642a260,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionTwo = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionTwo",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionTwo.add(lblVehicleOptionTwo, btnVehicleOptionTwo, imgVehicleOptionTwo);
            var FlxPersonalVehicleListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "FlxPersonalVehicleListBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            FlxPersonalVehicleListBox.setDefaultUnit(kony.flex.DP);
            var listboxPersonalVehicleDetails = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "listboxPersonalVehicleDetails",
                "isVisible": true,
                "left": "0dp",
                "onSelection": controller.AS_ListBox_eebe2039b66c408d9ad3a303e2850173,
                "skin": "defListBoxNormal",
                "top": "18dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            FlxPersonalVehicleListBox.add(listboxPersonalVehicleDetails);
            var lblHorizontalLine2 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine2",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "20px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionThree = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionThree",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_j804b12ad4684ad5bc3d919834dcd44c,
                "skin": "slFbox",
                "top": "10px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionThree.setDefaultUnit(kony.flex.DP);
            var lblNoCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblNoCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Decide Later",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "160dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "137dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            var imgDummy = new kony.ui.Image2({
                "height": "24px",
                "id": "imgDummy",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "10px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDummy = new kony.ui.Label({
                "height": "56px",
                "id": "lblDummy",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Time based Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDummy.add(imgDummy, lblDummy);
            var btnNoCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnNoCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionThree = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionThree",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionThree.add(lblNoCheckin, flxDummy, btnNoCheckin, imgVehicleOptionThree);
            var lblHorizontalLine3 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine3",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "20px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVehicleOptionFour = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxVehicleOptionFour",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "47dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f2d162fec6c74109b6c2515b0d440b61,
                "skin": "slFbox",
                "top": "10dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxVehicleOptionFour.setDefaultUnit(kony.flex.DP);
            var lblVehicleOptionFour = new kony.ui.Label({
                "height": "56px",
                "id": "lblVehicleOptionFour",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Add New",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnVehicleOptionFour = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnVehicleOptionFour",
                "isVisible": false,
                "left": "0px",
                "onClick": controller.AS_Button_af812e5d858d4528b9eb276715902e42,
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVehicleOptionFour = new kony.ui.Image2({
                "height": "24px",
                "id": "imgVehicleOptionFour",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "17px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleOptionFour.add(lblVehicleOptionFour, btnVehicleOptionFour, imgVehicleOptionFour);
            var FlxAddNewVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxAddNewVehicleDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "47dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300px",
                "zIndex": 1
            }, {}, {});
            FlxAddNewVehicleDetails.setDefaultUnit(kony.flex.DP);
            var lblMake = new kony.ui.Label({
                "id": "lblMake",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Make",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxMake = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxMake",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "MAKE",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0if2ea817675d40",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblModel = new kony.ui.Label({
                "id": "lblModel",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Model",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxModel = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxModel",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "MODEL",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0c6674e5533a34b",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblColor = new kony.ui.Label({
                "id": "lblColor",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "color",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxColor = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxColor",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "COLOR",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0e5e8103747b64c",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRegistration = new kony.ui.Label({
                "height": "25px",
                "id": "lblRegistration",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Registration",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxRegistration = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxRegistration",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "1832 445",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0b224084407cb43",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblNewVehicleType = new kony.ui.Label({
                "height": "25px",
                "id": "lblNewVehicleType",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0f5cef606e85840",
                "text": "Vehicle Type",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxNewVehicleType = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "45dp",
                "id": "txtboxNewVehicleType",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Vehicle Type",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0b224084407cb43",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            FlxAddNewVehicleDetails.add(lblMake, txtboxMake, lblModel, txtboxModel, lblColor, txtboxColor, lblRegistration, txtboxRegistration, lblNewVehicleType, txtboxNewVehicleType);
            var lblHorizontalLine4 = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine4",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "20px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxVehicleDetailsDashboard.add(lblVehicleType, flxVehicleOptionOne, FlxCompanyVehicleListBox, lblHorizontalLine1, flxVehicleOptionTwo, FlxPersonalVehicleListBox, lblHorizontalLine2, flxVehicleOptionThree, lblHorizontalLine3, flxVehicleOptionFour, FlxAddNewVehicleDetails, lblHorizontalLine4);
            var btnNext = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnNext",
                "isVisible": true,
                "left": "459px",
                "onClick": controller.AS_Button_d4ad6539194c4d78a06ce7f67a36c7e6,
                "skin": "CopyCopydefBtnNormal2",
                "text": "Next Step",
                "top": "30px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSave = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnSave",
                "isVisible": false,
                "left": "459px",
                "onClick": controller.AS_Button_he535bb4fd804441bb99c6fddbcc24e4,
                "skin": "CopyCopydefBtnNormal2",
                "text": "Save",
                "top": "30px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rchTextNext = new kony.ui.RichText({
                "height": "18px",
                "id": "rchTextNext",
                "isVisible": true,
                "linkSkin": "defRichTextLink",
                "right": "190px",
                "skin": "CopydefRichTextNormal0db697b0963a140",
                "text": "Next step:<b>Review And Verification</b>",
                "top": "10px",
                "width": "250px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            RightFlex.add(lblVehicleHeader, flxVehicleDetailsDashboard, btnNext, btnSave, rchTextNext);
            var LeftFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "LeftFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0bcd49123877f4a",
                "top": "0px",
                "width": "330px",
                "zIndex": 1
            }, {}, {});
            LeftFlex.setDefaultUnit(kony.flex.DP);
            var flxCreationList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "240px",
                "id": "flxCreationList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "32px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99px",
                "width": "197px",
                "zIndex": 1
            }, {}, {});
            flxCreationList.setDefaultUnit(kony.flex.DP);
            flxCreationList.add();
            var FlxTravelerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTravelerDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTravelerDetails.setDefaultUnit(kony.flex.DP);
            var btnTravelerDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTravelerDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "1",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravelerDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblTravelerDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Traveller Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTravelerDetails.add(btnTravelerDetails, lblTravelerDetails);
            var FlxRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "149dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblRouteDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblRouteDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Route Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRouteDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30px",
                "id": "btnRouteDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "2",
                "top": "0px",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRouteDetails.add(lblRouteDetails, btnRouteDetails);
            var FlxTrackingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTrackingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "199dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTrackingDetails.setDefaultUnit(kony.flex.DP);
            var btnTrackingDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTrackingDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "3",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingDetails = new kony.ui.Label({
                "height": "25px",
                "id": "lblTrackingDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Tracking Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrackingDetails.add(btnTrackingDetails, lblTrackingDetails);
            var FlxVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxVehicleDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "249dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxVehicleDetails.setDefaultUnit(kony.flex.DP);
            var btnVehicleDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnVehicleDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal1",
                "text": "4",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblVehicleDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Vehicle Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicleDetails.add(btnVehicleDetails, lblVehicleDetails);
            var FlxReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxReview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "299dp",
                "width": "220px",
                "zIndex": 2
            }, {}, {});
            FlxReview.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "5",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Review & Verification",
                "top": "6px",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxReview.add(btnReview, lblReview);
            var lblVerticalLine = new kony.ui.Label({
                "height": "189px",
                "id": "lblVerticalLine",
                "isVisible": true,
                "left": "42px",
                "skin": "CopyCopydefLabel0jcee779a5e3f48",
                "top": "125px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "33px",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b65c8b24f9bb47c8bbba3a199a821246,
                "skin": "slFbox",
                "top": "33px",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "height": "21px",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "32px",
                "minWidth": "156px",
                "skin": "CopyCopydefLabel0f52d96ab22d343",
                "text": "Back to Dashboard",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20px",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "murali_1.png",
                "top": "0px",
                "width": "20px",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            LeftFlex.add(flxCreationList, FlxTravelerDetails, FlxRouteDetails, FlxTrackingDetails, FlxVehicleDetails, FlxReview, lblVerticalLine, flxDashboard);
            ParentFlex.add(RightFlex, LeftFlex);
            this.add(ParentFlex);
        };
        return [{
            "addWidgets": addWidgetsfrmVehicleDetails,
            "enabledForIdleTimeout": false,
            "id": "frmVehicleDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_d556725a10e84baab7b44a88e5a77309,
            "skin": "CopyCopyslForm0be328b7f7b094b",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});