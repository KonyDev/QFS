define("frmTrackingDetails", function() {
    return function(controller) {
        function addWidgetsfrmTrackingDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var ParentFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "926px",
                "id": "ParentFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0ceab9799cca547",
                "top": "0px",
                "width": "1440px",
                "zIndex": 1
            }, {}, {});
            ParentFlex.setDefaultUnit(kony.flex.DP);
            var RightFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "926px",
                "id": "RightFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "330px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0ac0daf0365824b",
                "top": "0px",
                "width": "780px",
                "zIndex": 1
            }, {}, {});
            RightFlex.setDefaultUnit(kony.flex.DP);
            var lblTrackingHeader = new kony.ui.Label({
                "height": "37px",
                "id": "lblTrackingHeader",
                "isVisible": true,
                "left": "195px",
                "skin": "CopyCopydefLabel0h6569b77a82c43",
                "text": "Tracking Details",
                "top": "90px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingSubheader = new kony.ui.Label({
                "height": "20px",
                "id": "lblTrackingSubheader",
                "isVisible": true,
                "left": "195px",
                "skin": "lblName",
                "text": "Reason for journey",
                "top": "141px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupervisor = new kony.ui.Label({
                "id": "lblSupervisor",
                "isVisible": true,
                "left": "195px",
                "skin": "CopydefLabel0bf1f22f2d0884b",
                "text": "Supervisor",
                "top": "245px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblName = new kony.ui.Label({
                "height": "16px",
                "id": "lblName",
                "isVisible": true,
                "left": "195px",
                "skin": "lblName",
                "text": "Name",
                "top": "289px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Supervisor Name",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "310px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobile = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobile",
                "isVisible": true,
                "left": "195px",
                "skin": "lblName",
                "text": "Mobile Phone Number",
                "top": "378px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldMobile = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldMobile",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "999-999-9999",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "399px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRoomNo = new kony.ui.Label({
                "height": "16px",
                "id": "lblRoomNo",
                "isVisible": true,
                "left": "195px",
                "skin": "lblName",
                "text": "Camp Room Number",
                "top": "467px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldRoomNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldRoomNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Camp Room Number",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "488px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblSiterep = new kony.ui.Label({
                "id": "lblSiterep",
                "isVisible": false,
                "left": "195px",
                "skin": "CopydefLabel0bf1f22f2d0884b",
                "text": "Siterep",
                "top": "581px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSiterepName = new kony.ui.Label({
                "height": "16px",
                "id": "lblSiterepName",
                "isVisible": true,
                "left": "195px",
                "skin": "lblName",
                "text": "Employee ID",
                "top": "556px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldSiterepName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldSiterepName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Employee ID",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "583px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobileNumber = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobileNumber",
                "isVisible": false,
                "left": "195px",
                "skin": "lblName",
                "text": "Mobile Phone Number",
                "top": "716px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtboxMobileNumber = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "txtboxMobileNumber",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "999-999-9999",
                "secureTextEntry": false,
                "skin": "CopydefTextBoxNormal0be7331a8bdc942",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "735px",
                "width": "343px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnNextStep = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "50px",
                "id": "btnNextStep",
                "isVisible": true,
                "left": "408px",
                "onClick": controller.AS_Button_gd1491d275464b629a31a4785532768a,
                "skin": "CopyCopydefBtnNormal4",
                "text": "Next Step",
                "top": "700px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSave = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "50px",
                "id": "btnSave",
                "isVisible": false,
                "left": "408px",
                "onClick": controller.AS_Button_f90cead7bd094fc49e31a6f1a245dc3a,
                "skin": "CopyCopydefBtnNormal4",
                "text": "Save",
                "top": "700px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var listboxData = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "56px",
                "id": "listboxData",
                "isVisible": true,
                "left": "195px",
                "onSelection": controller.AS_ListBox_f9642273f6a94b358c955a86ce14142a,
                "skin": "defListBoxNormal",
                "top": "165px",
                "width": "343px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var rchtxtNextStep = new kony.ui.RichText({
                "height": "14px",
                "id": "rchtxtNextStep",
                "isVisible": true,
                "left": "408px",
                "linkSkin": "defRichTextLink",
                "skin": "CopyCopydefRichTextNormal",
                "text": "Next step:<b>Vehicle Details</B>",
                "top": "757px",
                "width": "145px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            RightFlex.add(lblTrackingHeader, lblTrackingSubheader, lblSupervisor, lblName, TextFieldName, lblMobile, TextFieldMobile, lblRoomNo, TextFieldRoomNo, lblSiterep, lblSiterepName, TextFieldSiterepName, lblMobileNumber, txtboxMobileNumber, btnNextStep, btnSave, listboxData, rchtxtNextStep);
            var LeftFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "926px",
                "id": "LeftFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0bcd49123877f4a",
                "top": "0px",
                "width": "330px",
                "zIndex": 1
            }, {}, {});
            LeftFlex.setDefaultUnit(kony.flex.DP);
            var flxCreationList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "240px",
                "id": "flxCreationList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "32px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99px",
                "width": "197px",
                "zIndex": 1
            }, {}, {});
            flxCreationList.setDefaultUnit(kony.flex.DP);
            flxCreationList.add();
            var FlxTravelerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTravelerDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTravelerDetails.setDefaultUnit(kony.flex.DP);
            var btnTravelerDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTravelerDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "1",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravelerDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblTravelerDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Traveller Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTravelerDetails.add(btnTravelerDetails, lblTravelerDetails);
            var FlxRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "149dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblRouteDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblRouteDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Route Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRouteDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30px",
                "id": "btnRouteDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "2",
                "top": "0px",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRouteDetails.add(lblRouteDetails, btnRouteDetails);
            var FlxTrackingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTrackingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "199dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTrackingDetails.setDefaultUnit(kony.flex.DP);
            var btnTrackingDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTrackingDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal1",
                "text": "3",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingDetails = new kony.ui.Label({
                "height": "25px",
                "id": "lblTrackingDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Tracking Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrackingDetails.add(btnTrackingDetails, lblTrackingDetails);
            var FlxVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxVehicleDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "249dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxVehicleDetails.setDefaultUnit(kony.flex.DP);
            var btnVehicleDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnVehicleDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "4",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblVehicleDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Vehicle Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicleDetails.add(btnVehicleDetails, lblVehicleDetails);
            var FlxReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxReview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "299dp",
                "width": "220px",
                "zIndex": 2
            }, {}, {});
            FlxReview.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "5",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Review & Verification",
                "top": "6px",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxReview.add(btnReview, lblReview);
            var lblVerticalLine = new kony.ui.Label({
                "height": "189px",
                "id": "lblVerticalLine",
                "isVisible": true,
                "left": "42px",
                "skin": "CopyCopydefLabel0jcee779a5e3f48",
                "top": "125px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "33px",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f07adb94dc284473beaa5feff513f88f,
                "skin": "slFbox",
                "top": "33px",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "height": "21px",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "32px",
                "minWidth": "156px",
                "skin": "CopyCopydefLabel0f52d96ab22d343",
                "text": "Back to Dashboard",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20px",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "murali_1.png",
                "top": "0px",
                "width": "20px",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            LeftFlex.add(flxCreationList, FlxTravelerDetails, FlxRouteDetails, FlxTrackingDetails, FlxVehicleDetails, FlxReview, lblVerticalLine, flxDashboard);
            ParentFlex.add(RightFlex, LeftFlex);
            this.add(ParentFlex);
        };
        return [{
            "addWidgets": addWidgetsfrmTrackingDetails,
            "enabledForIdleTimeout": false,
            "id": "frmTrackingDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_i069826679c647329280023c44d65faa,
            "skin": "CopyCopyslForm0c2101d065cbc42",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});