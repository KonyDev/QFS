define('applicationController',{
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.konymp.alertpopup", "alertpopup", "alertpopupController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "alertpopup",
            "name": "com.konymp.alertpopup"
        });
        kony.mvc.registry.add("com.konymp.animatedtextfield", "animatedtextfield", "animatedtextfieldController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "animatedtextfield",
            "name": "com.konymp.animatedtextfield"
        });
        kony.mvc.registry.add("com.konymp.HeaderEntry", "HeaderEntry", "HeaderEntryController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "HeaderEntry",
            "name": "com.konymp.HeaderEntry"
        });
        kony.mvc.registry.add("com.konymp.HeaderEntry1", "HeaderEntry1", "HeaderEntry1Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "HeaderEntry1",
            "name": "com.konymp.HeaderEntry1"
        });
        kony.mvc.registry.add("com.konymp.HeaderEntry2", "HeaderEntry2", "HeaderEntry2Controller");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "HeaderEntry2",
            "name": "com.konymp.HeaderEntry2"
        });
        kony.mvc.registry.add("com.konymp.JourneyTracking", "JourneyTracking", "JourneyTrackingController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "JourneyTracking",
            "name": "com.konymp.JourneyTracking"
        });
        kony.mvc.registry.add("com.konymp.progressBarIndicator", "progressBarIndicator", "progressBarIndicatorController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "progressBarIndicator",
            "name": "com.konymp.progressBarIndicator"
        });
        kony.mvc.registry.add("com.konymp.vuegooglemaps", "vuegooglemaps", "vuegooglemapsController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "vuegooglemaps",
            "name": "com.konymp.vuegooglemaps"
        });
        kony.mvc.registry.add("com.konyqfs.placeDetails", "placeDetails", "placeDetailsController");
        kony.application.registerMaster({
            "namespace": "com.konyqfs",
            "classname": "placeDetails",
            "name": "com.konyqfs.placeDetails"
        });
        kony.mvc.registry.add("com.konysa.animatedtext", "animatedtext", "animatedtextController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "animatedtext",
            "name": "com.konysa.animatedtext"
        });
        kony.mvc.registry.add("com.konysa.customAlertWithContactcheckin", "customAlertWithContactcheckin", "customAlertWithContactcheckinController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "customAlertWithContactcheckin",
            "name": "com.konysa.customAlertWithContactcheckin"
        });
        kony.mvc.registry.add("com.konysa.customAlertWithImage", "customAlertWithImage", "customAlertWithImageController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "customAlertWithImage",
            "name": "com.konysa.customAlertWithImage"
        });
        kony.mvc.registry.add("com.konysa.customAlertWithoutContactCheckin", "customAlertWithoutContactCheckin", "customAlertWithoutContactCheckinController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "customAlertWithoutContactCheckin",
            "name": "com.konysa.customAlertWithoutContactCheckin"
        });
        kony.mvc.registry.add("com.konysa.emergencydetails", "emergencydetails", "emergencydetailsController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "emergencydetails",
            "name": "com.konysa.emergencydetails"
        });
        kony.mvc.registry.add("com.konysa.escalationpolicy", "escalationpolicy", "escalationpolicyController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "escalationpolicy",
            "name": "com.konysa.escalationpolicy"
        });
        kony.mvc.registry.add("com.konysa.ETAReporting", "ETAReporting", "ETAReportingController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "ETAReporting",
            "name": "com.konysa.ETAReporting"
        });
        kony.mvc.registry.add("com.konysa.journeymap", "journeymap", "journeymapController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "journeymap",
            "name": "com.konysa.journeymap"
        });
        kony.mvc.registry.add("com.konysa.jrmgmtheader", "jrmgmtheader", "jrmgmtheaderController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "jrmgmtheader",
            "name": "com.konysa.jrmgmtheader"
        });
        kony.mvc.registry.add("com.konysa.masktext", "masktext", "masktextController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "masktext",
            "name": "com.konysa.masktext"
        });
        kony.mvc.registry.add("com.konysa.pathinfo", "pathinfo", "pathinfoController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "pathinfo",
            "name": "com.konysa.pathinfo"
        });
        kony.mvc.registry.add("com.konysa.processstatus", "processstatus", "processstatusController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "processstatus",
            "name": "com.konysa.processstatus"
        });
        kony.mvc.registry.add("com.konysa.searchnfilter", "searchnfilter", "searchnfilterController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "searchnfilter",
            "name": "com.konysa.searchnfilter"
        });
        kony.mvc.registry.add("com.konysa.tabpane", "tabpane", "tabpaneController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "tabpane",
            "name": "com.konysa.tabpane"
        });
        kony.mvc.registry.add("com.konysa.terminateJourney", "terminateJourney", "terminateJourneyController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "terminateJourney",
            "name": "com.konysa.terminateJourney"
        });
        kony.mvc.registry.add("com.konymp.Passenger", "Passenger", "PassengerController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "Passenger",
            "name": "com.konymp.Passenger"
        });
        kony.mvc.registry.add("com.konysa.journeydetail", "journeydetail", "journeydetailController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "journeydetail",
            "name": "com.konysa.journeydetail"
        });
        kony.mvc.registry.add("com.konysa.journeyTracker", "journeyTracker", "journeyTrackerController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "journeyTracker",
            "name": "com.konysa.journeyTracker"
        });
        kony.mvc.registry.add("com.konysa.normallogin", "normallogin", "normalloginController");
        kony.application.registerMaster({
            "namespace": "com.konysa",
            "classname": "normallogin",
            "name": "com.konysa.normallogin"
        });
        kony.mvc.registry.add("CopyflxMain0f0004db7fa7f48", "CopyflxMain0f0004db7fa7f48", "CopyflxMain0f0004db7fa7f48Controller");
        kony.mvc.registry.add("flxParent", "flxParent", "flxParentController");
        kony.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        kony.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        kony.mvc.registry.add("flxRootJourneyCard", "flxRootJourneyCard", "flxRootJourneyCardController");
        kony.mvc.registry.add("flxNotificationRoot", "flxNotificationRoot", "flxNotificationRootController");
        kony.mvc.registry.add("flxSegTmpAddPassenger", "flxSegTmpAddPassenger", "flxSegTmpAddPassengerController");
        kony.mvc.registry.add("flxEscalationRoot", "flxEscalationRoot", "flxEscalationRootController");
        kony.mvc.registry.add("flxPathRoot", "flxPathRoot", "flxPathRootController");
        kony.mvc.registry.add("flxRootProcessStatusDW", "flxRootProcessStatusDW", "flxRootProcessStatusDWController");
        kony.mvc.registry.add("Flex0ab488ced76e94b", "Flex0ab488ced76e94b", "Flex0ab488ced76e94bController");
        kony.mvc.registry.add("CopyflxMapTemplate0cad7fd75f04947", "CopyflxMapTemplate0cad7fd75f04947", "CopyflxMapTemplate0cad7fd75f04947Controller");
        kony.mvc.registry.add("CopyflxMapTemplate0a0ff65a9bba142", "CopyflxMapTemplate0a0ff65a9bba142", "CopyflxMapTemplate0a0ff65a9bba142Controller");
        kony.mvc.registry.add("flxMapTemplate", "flxMapTemplate", "flxMapTemplateController");
        kony.mvc.registry.add("fmLogin", "fmLogin", "fmLoginController");
        kony.mvc.registry.add("frmETA", "frmETA", "frmETAController");
        kony.mvc.registry.add("frmJourneyList", "frmJourneyList", "frmJourneyListController");
        kony.mvc.registry.add("frmLogOut", "frmLogOut", "frmLogOutController");
        kony.mvc.registry.add("frmQFSLogin", "frmQFSLogin", "frmQFSLoginController");
        kony.mvc.registry.add("frmReviewDetails", "frmReviewDetails", "frmReviewDetailsController");
        kony.mvc.registry.add("frmRoute", "frmRoute", "frmRouteController");
        kony.mvc.registry.add("frmTrackingDetails", "frmTrackingDetails", "frmTrackingDetailsController");
        kony.mvc.registry.add("frmTravellerDetails", "frmTravellerDetails", "frmTravellerDetailsController");
        kony.mvc.registry.add("frmVehicleDetails", "frmVehicleDetails", "frmVehicleDetailsController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmQFSLogin").navigate();
    }
});

define("com/konymp/alertpopup/useralertpopupController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/alertpopup/alertpopupControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/alertpopup/alertpopupController", ["com/konymp/alertpopup/useralertpopupController", "com/konymp/alertpopup/alertpopupControllerActions"], function() {
    var controller = require("com/konymp/alertpopup/useralertpopupController");
    var actions = require("com/konymp/alertpopup/alertpopupControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "headingText", function(val) {
            this.view.lblPasswordChangedMessage.text = val;
        });
        defineGetter(this, "headingText", function() {
            return this.view.lblPasswordChangedMessage.text;
        });
        defineSetter(this, "descriptionText", function(val) {
            this.view.lblPasswordChangedDescription.text = val;
        });
        defineGetter(this, "descriptionText", function() {
            return this.view.lblPasswordChangedDescription.text;
        });
        defineSetter(this, "buttonText", function(val) {
            this.view.btnForgotPassProceed.text = val;
        });
        defineGetter(this, "buttonText", function() {
            return this.view.btnForgotPassProceed.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/alertpopup/alertpopup',[],function() {
    return function(controller) {
        var alertpopup = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "alertpopup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0d65214ddc9704c",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "alertpopup"), extendConfig({}, controller.args[1], "alertpopup"), extendConfig({}, controller.args[2], "alertpopup"));
        alertpopup.setDefaultUnit(kony.flex.DP);
        var flxCenter = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "49.99%",
            "centerY": "50.00%",
            "clipBounds": true,
            "height": "200dp",
            "id": "flxCenter",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0d22285c8a2754a",
            "top": "0dp",
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "flxCenter"), extendConfig({}, controller.args[1], "flxCenter"), extendConfig({}, controller.args[2], "flxCenter"));
        flxCenter.setDefaultUnit(kony.flex.DP);
        var lblPasswordChangedMessage = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblPasswordChangedMessage",
            "isVisible": true,
            "left": "127dp",
            "skin": "CopydefLabel0a82fe6e1b2e64d",
            "text": "Password Changed",
            "textStyle": {},
            "top": "15dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPasswordChangedMessage"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPasswordChangedMessage"), extendConfig({}, controller.args[2], "lblPasswordChangedMessage"));
        var lblHorizontalLinePassChanged = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "lblHorizontalLinePassChanged",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0h154aa45223d43",
            "textStyle": {},
            "top": "10dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblHorizontalLinePassChanged"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHorizontalLinePassChanged"), extendConfig({}, controller.args[2], "lblHorizontalLinePassChanged"));
        var lblPasswordChangedDescription = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblPasswordChangedDescription",
            "isVisible": true,
            "left": "71dp",
            "skin": "CopydefLabel0cec947e6036147",
            "text": "Email link will be sent to you shortly.",
            "textStyle": {},
            "top": "31dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPasswordChangedDescription"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPasswordChangedDescription"), extendConfig({}, controller.args[2], "lblPasswordChangedDescription"));
        var btnForgotPassProceed = new kony.ui.Button(extendConfig({
            "centerX": "50%",
            "focusSkin": "sknFocusBtnSignIn",
            "height": "50dp",
            "id": "btnForgotPassProceed",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknBtnSignIn",
            "text": "Proceed",
            "top": "30dp",
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "btnForgotPassProceed"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnForgotPassProceed"), extendConfig({}, controller.args[2], "btnForgotPassProceed"));
        flxCenter.add(lblPasswordChangedMessage, lblHorizontalLinePassChanged, lblPasswordChangedDescription, btnForgotPassProceed);
        alertpopup.add(flxCenter);
        return alertpopup;
    }
})
;
define('com/konymp/alertpopup/alertpopupConfig',[],function() {
    return {
        "properties": [{
            "name": "headingText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "descriptionText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "buttonText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

/*
#
#  Created by Team Kony.
#  Copyright (c) 2017 Kony Inc. All rights reserved.
#
*/
define('com/konymp/animatedtextfield/KonyLogger',[],function() {
    /**
     * @member of  KonyLogger.js
     * @function KonyLogger
     * @param method - The function to be called to log the given message. 
     * When no parameter is passed, kony.print is called by default.
     * @returns an instance of KonyLogger class.
     * @description - This is the constructor for KonyLogger. 
     * This method initializes the instance created.
     **/
    var KonyLogger = function() {
        this.printMethod = kony.print;
        this.reuseableComponentName = arguments[0] || "appContext";
        var loggerGenerator = function() {
            this.trace = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "TRACE", message, event);
            };
            this.debug = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "DEBUG", message, event);
            };
            this.info = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "INFO", message, event);
            };
            this.warn = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "WARN", message, event);
            };
            this.error = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "ERROR", message, event);
            };
        };
        this.setLogLevel = function(logLevel) {
            if (this.isValidLogLevel(logLevel)) {
                if (typeof logLevel === "string") {
                    this.currentLogLevel = this.logLevels[logLevel];
                } else if (typeof logLevel === "number") {
                    this.currentLogLevel = logLevel;
                }
                var logMethods = Object.keys(this.logLevels);
                for (var i = 0; i < logMethods.length; i++) {
                    var methodName = logMethods[i].toLowerCase();
                    this[methodName] = (i < this.currentLogLevel) ? function() {} : (new loggerGenerator())[methodName];
                }
                return true;
            } else {
                return false;
            }
        };
        this.logMethod = function(functionName, logLevel, message, eventType) {
            var logObj = {
                "component": this.reuseableComponentName || "",
                "event": this.supportedEventTypes[eventType] || this.supportedEventTypes[this.DEFAULT],
                "function": functionName || "",
                "timestamp": KonyLogger.Utils.getDateTimeStamp() || "",
                "level": logLevel || "",
                "message": message || ""
            };
            this.printMethod(JSON.stringify(logObj, null, '\t'));
        };
        this.setLogLevel("TRACE");
    };
    /**
     * @member of  KonyLogger
     * @property logLevels - This enum holds the 6 levels of logging and their order.
     **/
    KonyLogger.prototype.logLevels = {
        "TRACE": 0,
        "DEBUG": 1,
        "INFO": 2,
        "WARN": 3,
        "ERROR": 4,
        "SILENT": 5
    };
    /**
     * @member of  KonyLogger
     * @property eventTypes - This array holds 8 types of events.
     **/
    KonyLogger.prototype.supportedEventTypes = ["DEFAULT", "FUNCTION_ENTRY", "FUNCTION_EXIT", "SUCCESS_CALLBACK", "ERROR_CALLBACK", "EXCEPTION", "SERVICE_CALL", "DATA_STORE"];
    /** KonyLogger EventTypes**/
    KonyLogger.prototype.DEFAULT = 0;
    KonyLogger.prototype.FUNCTION_ENTRY = 1;
    KonyLogger.prototype.FUNCTION_EXIT = 2;
    KonyLogger.prototype.SUCCESS_CALLBACK = 3;
    KonyLogger.prototype.ERROR_CALLBACK = 4;
    KonyLogger.prototype.EXCEPTION = 5;
    KonyLogger.prototype.SERVICE_CALL = 6;
    KonyLogger.prototype.DATA_STORE = 7;
    /**
     * @member of  KonyLogger
     * @property defaultLogLevel - This property holds the default logLevel
     * It is intialised to "TRACE".
     **/
    KonyLogger.prototype.defaultLogLevel = KonyLogger.prototype.logLevels["TRACE"];
    /**
     * @member of  KonyLogger
     * @function isValidLogLevel
     * @param logLevel - (string or number)
     * @description - This method validates the logLevel parameter with the enum logLevels
     * @return boolean
     **/
    KonyLogger.prototype.isValidLogLevel = function(logLevel) {
        if ((logLevel !== undefined) && (logLevel !== null) && (logLevel !== "")) {
            if (typeof logLevel === "string") {
                if (logLevel.toUpperCase() in this.logLevels) {
                    return true;
                } else {
                    return false;
                }
            } else if (typeof logLevel === "number") {
                for (var logLevelKey in this.logLevels) {
                    if (logLevel === this.logLevels.logLevelKey) {
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        }
    };
    /**
     * @member of  KonyLogger
     * @function getLogLevel
     * @param none
     * @description - This method returns the current log level of the instance
     * @return type number
     **/
    KonyLogger.prototype.getLogLevel = function() {
        return this.currentLogLevel;
    };
    /**
     * @member of  KonyLogger
     * @function setPrintMethod
     * @param method: type function - The method to print the log/message.
     * The default value is kony.print
     * @description - This method sets the current log method to 'method'
     * @return none
     **/
    KonyLogger.prototype.setPrintMethod = function(method) {
        if ((method !== undefined) && (method !== null) && (method !== "")) {
            if (typeof method === "function") {
                this.printMethod = method;
            }
        }
    };
    KonyLogger.Utils = {};
    /**
     * @member of  KonyLogger
     * @function getDateTimeStamp
     * @param none
     * @description - It returns the current date and time stamp in "DD/MM/YY HH:MM AM/PM" format
     * @return type string
     **/
    KonyLogger.Utils.getDateTimeStamp = function() {
        var dateTimeStamp = "";
        var currentDateObj = new Date();
        dateTimeStamp += currentDateObj.getDate() + "/" + (currentDateObj.getMonth() + 1) + "/" + currentDateObj.getFullYear();
        dateTimeStamp += " ";
        var hours = currentDateObj.getHours();
        if (hours > 12) {
            dateTimeStamp += (hours - 12) + ":" + currentDateObj.getMinutes() + " PM";
        } else {
            dateTimeStamp += hours + ":" + currentDateObj.getMinutes() + " AM";
        }
        return dateTimeStamp;
    };
    return KonyLogger;
});

/*
#
#  Created by Team Kony.
#  Copyright (c) 2017 Kony Inc. All rights reserved.
#
*/
define("com/konymp/animatedtextfield/useranimatedtextfieldController", ['com/konymp/animatedtextfield/KonyLogger'],function() {
    var konymp = konymp || {};
    var KonyLoggerModule = require("com/konymp/animatedtextfield/KonyLogger");
    konymp.logger = (new KonyLoggerModule("Animated Text Field")) || function() {};
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            konymp.logger.info("Entered constructor of component", konymp.logger.FUNCTION_ENTRY);
            this._placeholderSkin = this.placeholderSkin;
            this._placeholderFocusSkin = this.placeholderFocusSkin;
            this._underlineSkin = this.underlineSkin;
            this._underlineFocusSkin = this.underlineFocusSkin;
            konymp.logger.info("Exiting constructor of component", konymp.logger.FUNCTION_EXIT);
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            konymp.logger.info("Entered initGettersSetters function of component", konymp.logger.FUNCTION_ENTRY);
            defineSetter(this, "maxTextLength", function(val) {
                konymp.logger.trace("----------Entering maxTextLength Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (!isNaN(val) && val > 0) {
                    this.view.txtBoxComponent.maxTextLength = val;
                } else {
                    throw {
                        error: 2100,
                        message: 'wrong value passed to maxTextLength of animated Text Field'
                    };
                }
                konymp.logger.trace("----------Exiting maxTextLength Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "maxTextLength", function() {
                konymp.logger.trace("----------Entering maxTextLength Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting maxTextLength Getter---------", konymp.logger.FUNCTION_EXIT);
                return this.view.txtBoxComponent.maxTextLength;
            });
            konymp.logger.info("Exiting initGettersSetters function of component", konymp.logger.FUNCTION_EXIT);
        },
        preshow: function() {
            this.view.lblPlaceholder.padding = [2, 0, 0, 0];
            this.view.txtBoxComponent.padding = [2, 0, 0, 0];
            if (this.view.txtBoxComponent.text !== null && this.view.txtBoxComponent.text !== "") {
                this.view.lblPlaceholder.skin = this.placeholderFocusSkin;
                this.view.lblPlaceholder.top = "-30%";
                this.view.lblPlaceholder.width = "90%";
                this.view.lblUnderline.height = "5%";
                this.view.lblUnderline.skin = this.underlineFocusSkin;
                this.view.lblPlaceholder.top = "-30%";
            }
        },
        animateComponent: function(obj) {
            konymp.logger.info("Entered animateComponent function of component", konymp.logger.FUNCTION_ENTRY);
            obj.animate(kony.ui.createAnimation({
                "100": {
                    "top": "-30%",
                    "stepConfig": {
                        "timingFunction": kony.anim.EASE
                    },
                }
            }), {
                "delay": 0,
                "iterationCount": 1,
                "fillMode": kony.anim.FILL_MODE_FORWARDS,
                "duration": 0.25
            }, {
                "animationEnd": this.changeSkins(obj, "animate")
            });
            konymp.logger.info("Exiting animateComponent function of component", konymp.logger.FUNCTION_EXIT);
        },
        changeSkins: function(obj, animateVal) {
            konymp.logger.info("Entered changeSkins function of component", konymp.logger.FUNCTION_ENTRY);
            if (animateVal === "animate") {
                obj.skin = this._placeholderFocusSkin;
                obj.padding = [2, 0, 0, 0];
                obj.width = "90%";
                this.view.txtBoxComponent.setFocus(true);
                this.view.lblUnderline.height = "1dp";
                this.view.lblUnderline.skin = this._underlineFocusSkin;
            } else {
                obj.skin = this._placeholderSkin;
                obj.width = "100%";
                this.view.lblUnderline.height = "1dp";
                this.view.lblPlaceholder.setFocus(true);
                this.view.lblUnderline.skin = this._underlineSkin;
            }
            this.view.forceLayout();
            konymp.logger.info("Exiting changeSkins function of component", konymp.logger.FUNCTION_EXIT);
        },
        onDone: function(obj) {
            konymp.logger.info("Entered onDone function of component", konymp.logger.FUNCTION_ENTRY);
            if (this.onTextBoxDone !== undefined && this.onTextBoxDone !== null) {
                this.onTextBoxDone();
            } else {
                if (this.view.txtBoxComponent.text === null || this.view.txtBoxComponent.text === "") {
                    obj.animate(kony.ui.createAnimation({
                        "100": {
                            "top": "0%",
                            "stepConfig": {
                                "timingFunction": kony.anim.EASE
                            },
                        }
                    }), {
                        "delay": 0,
                        "iterationCount": 1,
                        "fillMode": kony.anim.FILL_MODE_FORWARDS,
                        "duration": 0.25
                    }, {
                        "animationEnd": this.changeSkins(obj, "reverse")
                    });
                }
            }
            konymp.logger.info("Exiting onDone function of component", konymp.logger.FUNCTION_EXIT);
        },
        getText: function() {
            konymp.logger.info("Entered getText API of component", konymp.logger.FUNCTION_ENTRY);
            konymp.logger.info("Exiting getText API of component", konymp.logger.FUNCTION_EXIT);
            return this.view.txtBoxComponent.text;
        }
    };
});
define("com/konymp/animatedtextfield/animatedtextfieldControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_h5e4652b0b944a389c3fde089fd6bd3e: function AS_TextField_h5e4652b0b944a389c3fde089fd6bd3e(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_b778fa88d4d54a66a1c26913f9889d3e: function AS_TextField_b778fa88d4d54a66a1c26913f9889d3e(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_be78a8d5208a4adc8a6b93b2029b5a2b: function AS_TextField_be78a8d5208a4adc8a6b93b2029b5a2b(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_a06c427860104cab9dd43d33bc95ac2c: function AS_TextField_a06c427860104cab9dd43d33bc95ac2c(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_cdea689f0fff4439803ee992e86053ad: function AS_TextField_cdea689f0fff4439803ee992e86053ad(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onEndEditing defined for txtBoxComponent **/
    AS_TextField_f253673a66064e7693d2872e4e34f5bb: function AS_TextField_f253673a66064e7693d2872e4e34f5bb(eventobject, changedtext) {
        var self = this;
        this.onDone(this.view.lblPlaceholder);
    },
    /** onTouchStart defined for lblPlaceholder **/
    AS_Label_acd2edb1c5604cb892bdad714391b580: function AS_Label_acd2edb1c5604cb892bdad714391b580(eventobject, x, y) {
        var self = this;
    },
    /** onClick defined for flxTextBox **/
    AS_FlexContainer_f2c99520aa404a27b5699107ebb025e7: function AS_FlexContainer_f2c99520aa404a27b5699107ebb025e7(eventobject) {
        var self = this;
        this.animateComponent(this.view.lblPlaceholder);
    },
    /** preShow defined for animatedtextfield **/
    AS_FlexContainer_ga69f6eae1fa410187a6e919be851113: function AS_FlexContainer_ga69f6eae1fa410187a6e919be851113(eventobject) {
        var self = this;
        this.preshow();
    }
});
define("com/konymp/animatedtextfield/animatedtextfieldController", ["com/konymp/animatedtextfield/useranimatedtextfieldController", "com/konymp/animatedtextfield/animatedtextfieldControllerActions"], function() {
    var controller = require("com/konymp/animatedtextfield/useranimatedtextfieldController");
    var actions = require("com/konymp/animatedtextfield/animatedtextfieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "placeholderText", function(val) {
            this.view.lblPlaceholder.text = val;
        });
        defineGetter(this, "placeholderText", function() {
            return this.view.lblPlaceholder.text;
        });
        defineSetter(this, "underlineVisibility", function(val) {
            this.view.lblUnderline.isVisible = val;
        });
        defineGetter(this, "underlineVisibility", function() {
            return this.view.lblUnderline.isVisible;
        });
        defineSetter(this, "placeholderSkin", function(val) {
            this.view.lblPlaceholder.skin = val;
        });
        defineGetter(this, "placeholderSkin", function() {
            return this.view.lblPlaceholder.skin;
        });
        defineSetter(this, "placeholderFocusSkin", function(val) {
            this.view.lblPlaceholderFocusSkin.skin = val;
        });
        defineGetter(this, "placeholderFocusSkin", function() {
            return this.view.lblPlaceholderFocusSkin.skin;
        });
        defineSetter(this, "underlineSkin", function(val) {
            this.view.lblUnderline.skin = val;
        });
        defineGetter(this, "underlineSkin", function() {
            return this.view.lblUnderline.skin;
        });
        defineSetter(this, "underlineFocusSkin", function(val) {
            this.view.lblUnderlineFocusSkin.skin = val;
        });
        defineGetter(this, "underlineFocusSkin", function() {
            return this.view.lblUnderlineFocusSkin.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/animatedtextfield/animatedtextfield',[],function() {
    return function(controller) {
        var animatedtextfield = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "isMaster": true,
            "height": "10%",
            "id": "animatedtextfield",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_ga69f6eae1fa410187a6e919be851113(eventobject);
            },
            "skin": "CopykonympatfsknFlxFFFFFFBG",
            "top": "0%",
            "width": "95%"
        }, controller.args[0], "animatedtextfield"), extendConfig({}, controller.args[1], "animatedtextfield"), extendConfig({}, controller.args[2], "animatedtextfield"));
        animatedtextfield.setDefaultUnit(kony.flex.DP);
        var flxTextBox = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxTextBox",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_f2c99520aa404a27b5699107ebb025e7,
            "skin": "CopykonympatfsknFlxFFFFFFBG",
            "top": "0%",
            "width": "100%",
            "zIndex": 10
        }, controller.args[0], "flxTextBox"), extendConfig({}, controller.args[1], "flxTextBox"), extendConfig({}, controller.args[2], "flxTextBox"));
        flxTextBox.setDefaultUnit(kony.flex.DP);
        var txtBoxComponent = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "bottom": "0%",
            "focusSkin": "CopykonympatfsknTextBoxComponent2",
            "height": "100%",
            "id": "txtBoxComponent",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0%",
            "maxTextLength": null,
            "secureTextEntry": false,
            "skin": "CopykonympatfsknTextBoxComponent2",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "txtBoxComponent"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [2, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtBoxComponent"), extendConfig({
            "autoCorrect": false,
            "onEndEditing": controller.AS_TextField_f253673a66064e7693d2872e4e34f5bb
        }, controller.args[2], "txtBoxComponent"));
        var lblUnderline = new kony.ui.Label(extendConfig({
            "bottom": "0%",
            "height": "1dp",
            "id": "lblUnderline",
            "isVisible": true,
            "left": "0%",
            "skin": "CopykonympatfsknTextBoxComponent1",
            "textStyle": {},
            "width": "100%",
            "zIndex": 10
        }, controller.args[0], "lblUnderline"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUnderline"), extendConfig({}, controller.args[2], "lblUnderline"));
        var lblPlaceholder = new kony.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblPlaceholder",
            "isVisible": true,
            "left": "0%",
            "onTouchStart": controller.AS_Label_acd2edb1c5604cb892bdad714391b580,
            "skin": "CopykonympatfsknTextBoxComponent",
            "text": "Username",
            "textStyle": {},
            "top": "0%",
            "width": "100%",
            "zIndex": 5
        }, controller.args[0], "lblPlaceholder"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [2, 0, 0, 2],
            "paddingInPixel": false
        }, controller.args[1], "lblPlaceholder"), extendConfig({}, controller.args[2], "lblPlaceholder"));
        var lblPlaceholderFocusSkin = new kony.ui.Label(extendConfig({
            "id": "lblPlaceholderFocusSkin",
            "isVisible": true,
            "left": "37dp",
            "skin": "CopykonympatfsknPlaceholderAnimated",
            "text": "Label",
            "textStyle": {},
            "top": "319dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 10
        }, controller.args[0], "lblPlaceholderFocusSkin"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPlaceholderFocusSkin"), extendConfig({}, controller.args[2], "lblPlaceholderFocusSkin"));
        var lblUnderlineFocusSkin = new kony.ui.Label(extendConfig({
            "height": "1dp",
            "id": "lblUnderlineFocusSkin",
            "isVisible": false,
            "left": "30dp",
            "skin": "CopykonympatfsknUnderlineAnimated",
            "text": "Label",
            "textStyle": {},
            "top": "353dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 10
        }, controller.args[0], "lblUnderlineFocusSkin"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUnderlineFocusSkin"), extendConfig({}, controller.args[2], "lblUnderlineFocusSkin"));
        flxTextBox.add(txtBoxComponent, lblUnderline, lblPlaceholder, lblPlaceholderFocusSkin, lblUnderlineFocusSkin);
        animatedtextfield.add(flxTextBox);
        return animatedtextfield;
    }
})
;
define('com/konymp/animatedtextfield/animatedtextfieldConfig',[],function() {
    return {
        "properties": [{
            "name": "placeholderText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "underlineVisibility",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "placeholderSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "placeholderFocusSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "underlineSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "underlineFocusSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onTextBoxDone"]
    }
});

define("com/konymp/HeaderEntry/userHeaderEntryController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/HeaderEntry/HeaderEntryControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/HeaderEntry/HeaderEntryController", ["com/konymp/HeaderEntry/userHeaderEntryController", "com/konymp/HeaderEntry/HeaderEntryControllerActions"], function() {
    var controller = require("com/konymp/HeaderEntry/userHeaderEntryController");
    var actions = require("com/konymp/HeaderEntry/HeaderEntryControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "headertext", function(val) {
            this.view.Label0c042960debc142.text = val;
        });
        defineGetter(this, "headertext", function() {
            return this.view.Label0c042960debc142.text;
        });
        defineSetter(this, "text", function(val) {
            this.view.txtUserName.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.txtUserName.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/HeaderEntry/HeaderEntry',[],function() {
    return function(controller) {
        var HeaderEntry = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "HeaderEntry",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "HeaderEntry"), extendConfig({}, controller.args[1], "HeaderEntry"), extendConfig({}, controller.args[2], "HeaderEntry"));
        HeaderEntry.setDefaultUnit(kony.flex.DP);
        var flxMain = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "60dp",
            "id": "flxMain",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0jabce9b6e81f46",
            "top": "10dp",
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "flxMain"), extendConfig({}, controller.args[1], "flxMain"), extendConfig({}, controller.args[2], "flxMain"));
        flxMain.setDefaultUnit(kony.flex.DP);
        var Label0c042960debc142 = new kony.ui.Label(extendConfig({
            "id": "Label0c042960debc142",
            "isVisible": true,
            "left": "5dp",
            "skin": "CopydefLabel0d7aa61720ec942",
            "text": "Label",
            "textStyle": {},
            "top": "1dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0c042960debc142"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0c042960debc142"), extendConfig({}, controller.args[2], "Label0c042960debc142"));
        var txtUserName = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "bottom": "5dp",
            "focusSkin": "txtUserNameSNormal0jb8a884faef347",
            "height": "40dp",
            "id": "txtUserName",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "-8dp",
            "right": "10dp",
            "secureTextEntry": false,
            "skin": "txtUserNameSNormal0jb8a884faef347",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "width": "100%",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, controller.args[0], "txtUserName"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtUserName"), extendConfig({
            "autoCorrect": false
        }, controller.args[2], "txtUserName"));
        var Label0e7e2d15b18a34e = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "Label0e7e2d15b18a34e",
            "isVisible": true,
            "left": "1dp",
            "skin": "CopydefLabel0if70421aee1240",
            "textStyle": {},
            "top": "-10dp",
            "width": "98%",
            "zIndex": 1
        }, controller.args[0], "Label0e7e2d15b18a34e"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0e7e2d15b18a34e"), extendConfig({}, controller.args[2], "Label0e7e2d15b18a34e"));
        flxMain.add(Label0c042960debc142, txtUserName, Label0e7e2d15b18a34e);
        HeaderEntry.add(flxMain);
        return HeaderEntry;
    }
})
;
define('com/konymp/HeaderEntry/HeaderEntryConfig',[],function() {
    return {
        "properties": [{
            "name": "headertext",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/konymp/HeaderEntry1/userHeaderEntry1Controller", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/HeaderEntry1/HeaderEntry1ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/HeaderEntry1/HeaderEntry1Controller", ["com/konymp/HeaderEntry1/userHeaderEntry1Controller", "com/konymp/HeaderEntry1/HeaderEntry1ControllerActions"], function() {
    var controller = require("com/konymp/HeaderEntry1/userHeaderEntry1Controller");
    var actions = require("com/konymp/HeaderEntry1/HeaderEntry1ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.Label0c042960debc142.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.Label0c042960debc142.text;
        });
        defineSetter(this, "textboxText", function(val) {
            this.view.txtUserName.text = val;
        });
        defineGetter(this, "textboxText", function() {
            return this.view.txtUserName.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/HeaderEntry1/HeaderEntry1',[],function() {
    return function(controller) {
        var HeaderEntry1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "HeaderEntry1",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "HeaderEntry1"), extendConfig({}, controller.args[1], "HeaderEntry1"), extendConfig({}, controller.args[2], "HeaderEntry1"));
        HeaderEntry1.setDefaultUnit(kony.flex.DP);
        var flxMain = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxMain",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "flxMain"), extendConfig({}, controller.args[1], "flxMain"), extendConfig({}, controller.args[2], "flxMain"));
        flxMain.setDefaultUnit(kony.flex.DP);
        var Label0c042960debc142 = new kony.ui.Label(extendConfig({
            "id": "Label0c042960debc142",
            "isVisible": true,
            "left": "1dp",
            "skin": "CopydefLabel0d7aa61720ec942",
            "text": "Label",
            "textStyle": {},
            "top": "1dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0c042960debc142"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0c042960debc142"), extendConfig({}, controller.args[2], "Label0c042960debc142"));
        var txtUserName = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "bottom": "5dp",
            "focusSkin": "txtUserNameSNormal0jb8a884faef347",
            "height": "40dp",
            "id": "txtUserName",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "-8dp",
            "right": "10dp",
            "secureTextEntry": false,
            "skin": "txtUserNameSNormal0jb8a884faef347",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "width": "100%",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, controller.args[0], "txtUserName"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtUserName"), extendConfig({
            "autoCorrect": false
        }, controller.args[2], "txtUserName"));
        var Label0e7e2d15b18a34e = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "Label0e7e2d15b18a34e",
            "isVisible": true,
            "left": "1dp",
            "skin": "CopydefLabel0if70421aee1240",
            "textStyle": {},
            "top": "-10dp",
            "width": "98%",
            "zIndex": 1
        }, controller.args[0], "Label0e7e2d15b18a34e"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0e7e2d15b18a34e"), extendConfig({}, controller.args[2], "Label0e7e2d15b18a34e"));
        flxMain.add(Label0c042960debc142, txtUserName, Label0e7e2d15b18a34e);
        HeaderEntry1.add(flxMain);
        return HeaderEntry1;
    }
})
;
define('com/konymp/HeaderEntry1/HeaderEntry1Config',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textboxText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/konymp/HeaderEntry2/userHeaderEntry2Controller", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/HeaderEntry2/HeaderEntry2ControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/HeaderEntry2/HeaderEntry2Controller", ["com/konymp/HeaderEntry2/userHeaderEntry2Controller", "com/konymp/HeaderEntry2/HeaderEntry2ControllerActions"], function() {
    var controller = require("com/konymp/HeaderEntry2/userHeaderEntry2Controller");
    var actions = require("com/konymp/HeaderEntry2/HeaderEntry2ControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.Label0c042960debc142.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.Label0c042960debc142.text;
        });
        defineSetter(this, "src", function(val) {
            this.view.Image0ba6fce7d159b40.src = val;
        });
        defineGetter(this, "src", function() {
            return this.view.Image0ba6fce7d159b40.src;
        });
        defineSetter(this, "textboxText", function(val) {
            this.view.txtUserName.text = val;
        });
        defineGetter(this, "textboxText", function() {
            return this.view.txtUserName.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/HeaderEntry2/HeaderEntry2',[],function() {
    return function(controller) {
        var HeaderEntry2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "80dp",
            "id": "HeaderEntry2",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "HeaderEntry2"), extendConfig({}, controller.args[1], "HeaderEntry2"), extendConfig({}, controller.args[2], "HeaderEntry2"));
        HeaderEntry2.setDefaultUnit(kony.flex.DP);
        var flxMain = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "60dp",
            "id": "flxMain",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0e45f846cbbbb44",
            "top": "10dp",
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "flxMain"), extendConfig({}, controller.args[1], "flxMain"), extendConfig({}, controller.args[2], "flxMain"));
        flxMain.setDefaultUnit(kony.flex.DP);
        var Label0c042960debc142 = new kony.ui.Label(extendConfig({
            "id": "Label0c042960debc142",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0dba591d5882445",
            "text": "Label",
            "textStyle": {},
            "top": "1dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0c042960debc142"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0c042960debc142"), extendConfig({}, controller.args[2], "Label0c042960debc142"));
        var FlexGroup0db8313aa93b641 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "FlexGroup0db8313aa93b641",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0c2246bdc85cc4c",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "FlexGroup0db8313aa93b641"), extendConfig({}, controller.args[1], "FlexGroup0db8313aa93b641"), extendConfig({}, controller.args[2], "FlexGroup0db8313aa93b641"));
        FlexGroup0db8313aa93b641.setDefaultUnit(kony.flex.DP);
        var Image0ba6fce7d159b40 = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "20dp",
            "id": "Image0ba6fce7d159b40",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "cargrey.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "Image0ba6fce7d159b40"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0ba6fce7d159b40"), extendConfig({}, controller.args[2], "Image0ba6fce7d159b40"));
        var txtUserName = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "txtUserNameSNormal0jb8a884faef347",
            "height": "40dp",
            "id": "txtUserName",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "5dp",
            "secureTextEntry": false,
            "skin": "txtUserNameSNormal0jb8a884faef347",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "width": "90%",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, controller.args[0], "txtUserName"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtUserName"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "Copys0be71710630b948"
        }, controller.args[2], "txtUserName"));
        FlexGroup0db8313aa93b641.add(Image0ba6fce7d159b40, txtUserName);
        var Label0e7e2d15b18a34e = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "Label0e7e2d15b18a34e",
            "isVisible": true,
            "left": "1dp",
            "skin": "CopydefLabel0if70421aee1240",
            "textStyle": {},
            "width": "98%",
            "zIndex": 1
        }, controller.args[0], "Label0e7e2d15b18a34e"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0e7e2d15b18a34e"), extendConfig({}, controller.args[2], "Label0e7e2d15b18a34e"));
        flxMain.add(Label0c042960debc142, FlexGroup0db8313aa93b641, Label0e7e2d15b18a34e);
        HeaderEntry2.add(flxMain);
        return HeaderEntry2;
    }
})
;
define('com/konymp/HeaderEntry2/HeaderEntry2Config',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "src",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textboxText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/konymp/JourneyTracking/userJourneyTrackingController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/JourneyTracking/JourneyTrackingControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/JourneyTracking/JourneyTrackingController", ["com/konymp/JourneyTracking/userJourneyTrackingController", "com/konymp/JourneyTracking/JourneyTrackingControllerActions"], function() {
    var controller = require("com/konymp/JourneyTracking/userJourneyTrackingController");
    var actions = require("com/konymp/JourneyTracking/JourneyTrackingControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "sknTraveller", function(val) {
            this.view.flxImgTravelling.skin = val;
        });
        defineGetter(this, "sknTraveller", function() {
            return this.view.flxImgTravelling.skin;
        });
        defineSetter(this, "sknTracking", function(val) {
            this.view.flxImageTracking.skin = val;
        });
        defineGetter(this, "sknTracking", function() {
            return this.view.flxImageTracking.skin;
        });
        defineSetter(this, "sknRoute", function(val) {
            this.view.flxImageRoute.skin = val;
        });
        defineGetter(this, "sknRoute", function() {
            return this.view.flxImageRoute.skin;
        });
        defineSetter(this, "sknVehicle", function(val) {
            this.view.flxImageVehicle.skin = val;
        });
        defineGetter(this, "sknVehicle", function() {
            return this.view.flxImageVehicle.skin;
        });
        defineSetter(this, "sknVerification", function(val) {
            this.view.flxImageTrackingVerification.skin = val;
        });
        defineGetter(this, "sknVerification", function() {
            return this.view.flxImageTrackingVerification.skin;
        });
        defineSetter(this, "srcTravelling", function(val) {
            this.view.imgTravelling.src = val;
        });
        defineGetter(this, "srcTravelling", function() {
            return this.view.imgTravelling.src;
        });
        defineSetter(this, "srcTracking", function(val) {
            this.view.imgTracking.src = val;
        });
        defineGetter(this, "srcTracking", function() {
            return this.view.imgTracking.src;
        });
        defineSetter(this, "srcRoute", function(val) {
            this.view.imgRoute.src = val;
        });
        defineGetter(this, "srcRoute", function() {
            return this.view.imgRoute.src;
        });
        defineSetter(this, "srcVehicle", function(val) {
            this.view.imgVehicle.src = val;
        });
        defineGetter(this, "srcVehicle", function() {
            return this.view.imgVehicle.src;
        });
        defineSetter(this, "srcVerification", function(val) {
            this.view.imgVerification.src = val;
        });
        defineGetter(this, "srcVerification", function() {
            return this.view.imgVerification.src;
        });
        defineSetter(this, "textTravelling", function(val) {
            this.view.lblTravelling.text = val;
        });
        defineGetter(this, "textTravelling", function() {
            return this.view.lblTravelling.text;
        });
        defineSetter(this, "textTracking", function(val) {
            this.view.lblTracking.text = val;
        });
        defineGetter(this, "textTracking", function() {
            return this.view.lblTracking.text;
        });
        defineSetter(this, "textRoute", function(val) {
            this.view.lblRoute.text = val;
        });
        defineGetter(this, "textRoute", function() {
            return this.view.lblRoute.text;
        });
        defineSetter(this, "textVehicle", function(val) {
            this.view.lblVehicle.text = val;
        });
        defineGetter(this, "textVehicle", function() {
            return this.view.lblVehicle.text;
        });
        defineSetter(this, "textVerification", function(val) {
            this.view.lblVerification.text = val;
        });
        defineGetter(this, "textVerification", function() {
            return this.view.lblVerification.text;
        });
        defineSetter(this, "sknFirstLine", function(val) {
            this.view.flxFirst.skin = val;
        });
        defineGetter(this, "sknFirstLine", function() {
            return this.view.flxFirst.skin;
        });
        defineSetter(this, "sknSecondLine", function(val) {
            this.view.flxSecond.skin = val;
        });
        defineGetter(this, "sknSecondLine", function() {
            return this.view.flxSecond.skin;
        });
        defineSetter(this, "sknThirdLine", function(val) {
            this.view.flxThird.skin = val;
        });
        defineGetter(this, "sknThirdLine", function() {
            return this.view.flxThird.skin;
        });
        defineSetter(this, "sknFourthLine", function(val) {
            this.view.flxFourth.skin = val;
        });
        defineGetter(this, "sknFourthLine", function() {
            return this.view.flxFourth.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/JourneyTracking/JourneyTracking',[],function() {
    return function(controller) {
        var JourneyTracking = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "10%",
            "id": "JourneyTracking",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "JourneyTracking"), extendConfig({}, controller.args[1], "JourneyTracking"), extendConfig({}, controller.args[2], "JourneyTracking"));
        JourneyTracking.setDefaultUnit(kony.flex.DP);
        var flxTracker = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxTracker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0df6ed33272a84b",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxTracker"), extendConfig({}, controller.args[1], "flxTracker"), extendConfig({}, controller.args[2], "flxTracker"));
        flxTracker.setDefaultUnit(kony.flex.DP);
        var flxTravellerIconContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTravellerIconContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "5%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "flxTravellerIconContainer"), extendConfig({}, controller.args[1], "flxTravellerIconContainer"), extendConfig({}, controller.args[2], "flxTravellerIconContainer"));
        flxTravellerIconContainer.setDefaultUnit(kony.flex.DP);
        var flxImgTravelling = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxImgTravelling",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderBlueBackgroundBlue",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "flxImgTravelling"), extendConfig({}, controller.args[1], "flxImgTravelling"), extendConfig({}, controller.args[2], "flxImgTravelling"));
        flxImgTravelling.setDefaultUnit(kony.flex.DP);
        var imgTravelling = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "imgTravelling",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "whiteman.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgTravelling"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgTravelling"), extendConfig({}, controller.args[2], "imgTravelling"));
        flxImgTravelling.add(imgTravelling);
        var lblTravelling = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblTravelling",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Traveller",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTravelling"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTravelling"), extendConfig({}, controller.args[2], "lblTravelling"));
        flxTravellerIconContainer.add(flxImgTravelling, lblTravelling);
        var flxRouteIconContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxRouteIconContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "23%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "flxRouteIconContainer"), extendConfig({}, controller.args[1], "flxRouteIconContainer"), extendConfig({}, controller.args[2], "flxRouteIconContainer"));
        flxRouteIconContainer.setDefaultUnit(kony.flex.DP);
        var flxImageRoute = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxImageRoute",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderBlueBackgroundBlue",
            "top": "11dp",
            "width": "35dp"
        }, controller.args[0], "flxImageRoute"), extendConfig({}, controller.args[1], "flxImageRoute"), extendConfig({}, controller.args[2], "flxImageRoute"));
        flxImageRoute.setDefaultUnit(kony.flex.DP);
        var imgRoute = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "imgRoute",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "whitelocation.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgRoute"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgRoute"), extendConfig({}, controller.args[2], "imgRoute"));
        flxImageRoute.add(imgRoute);
        var lblRoute = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblRoute",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Route",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblRoute"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRoute"), extendConfig({}, controller.args[2], "lblRoute"));
        flxRouteIconContainer.add(flxImageRoute, lblRoute);
        var flxTrackingIconContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTrackingIconContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "41%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "flxTrackingIconContainer"), extendConfig({}, controller.args[1], "flxTrackingIconContainer"), extendConfig({}, controller.args[2], "flxTrackingIconContainer"));
        flxTrackingIconContainer.setDefaultUnit(kony.flex.DP);
        var flxImageTracking = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxImageTracking",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderBlueBackgroundBlue",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "flxImageTracking"), extendConfig({}, controller.args[1], "flxImageTracking"), extendConfig({}, controller.args[2], "flxImageTracking"));
        flxImageTracking.setDefaultUnit(kony.flex.DP);
        var imgTracking = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "imgTracking",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "whitetarget.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgTracking"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgTracking"), extendConfig({}, controller.args[2], "imgTracking"));
        flxImageTracking.add(imgTracking);
        var lblTracking = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblTracking",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Tracking",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTracking"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTracking"), extendConfig({}, controller.args[2], "lblTracking"));
        flxTrackingIconContainer.add(flxImageTracking, lblTracking);
        var flxVehicleIconContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxVehicleIconContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "59%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "flxVehicleIconContainer"), extendConfig({}, controller.args[1], "flxVehicleIconContainer"), extendConfig({}, controller.args[2], "flxVehicleIconContainer"));
        flxVehicleIconContainer.setDefaultUnit(kony.flex.DP);
        var flxImageVehicle = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxImageVehicle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderBlueBackgroundWhite",
            "top": "11dp",
            "width": "35dp"
        }, controller.args[0], "flxImageVehicle"), extendConfig({}, controller.args[1], "flxImageVehicle"), extendConfig({}, controller.args[2], "flxImageVehicle"));
        flxImageVehicle.setDefaultUnit(kony.flex.DP);
        var imgVehicle = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "imgVehicle",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "bluecar.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgVehicle"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgVehicle"), extendConfig({}, controller.args[2], "imgVehicle"));
        flxImageVehicle.add(imgVehicle);
        var lblVehicle = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblVehicle",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Vehicle",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVehicle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVehicle"), extendConfig({}, controller.args[2], "lblVehicle"));
        flxVehicleIconContainer.add(flxImageVehicle, lblVehicle);
        var flxVerificationIconContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxVerificationIconContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "77%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "flxVerificationIconContainer"), extendConfig({}, controller.args[1], "flxVerificationIconContainer"), extendConfig({}, controller.args[2], "flxVerificationIconContainer"));
        flxVerificationIconContainer.setDefaultUnit(kony.flex.DP);
        var flxImageTrackingVerification = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxImageTrackingVerification",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorder",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "flxImageTrackingVerification"), extendConfig({}, controller.args[1], "flxImageTrackingVerification"), extendConfig({}, controller.args[2], "flxImageTrackingVerification"));
        flxImageTrackingVerification.setDefaultUnit(kony.flex.DP);
        var imgVerification = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "imgVerification",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "whitetick.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgVerification"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgVerification"), extendConfig({}, controller.args[2], "imgVerification"));
        flxImageTrackingVerification.add(imgVerification);
        var lblVerification = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblVerification",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Verification",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVerification"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVerification"), extendConfig({}, controller.args[2], "lblVerification"));
        flxVerificationIconContainer.add(flxImageTrackingVerification, lblVerification);
        var flxHorizontalConnector = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "2dp",
            "id": "flxHorizontalConnector",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0df36b48b298e4a",
            "top": "20dp",
            "width": "70%",
            "zIndex": 3
        }, controller.args[0], "flxHorizontalConnector"), extendConfig({}, controller.args[1], "flxHorizontalConnector"), extendConfig({}, controller.args[2], "flxHorizontalConnector"));
        flxHorizontalConnector.setDefaultUnit(kony.flex.DP);
        var flxFirst = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxFirst",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBlueHorizontalLine",
            "top": "0dp",
            "width": "25%",
            "zIndex": 3
        }, controller.args[0], "flxFirst"), extendConfig({}, controller.args[1], "flxFirst"), extendConfig({}, controller.args[2], "flxFirst"));
        flxFirst.setDefaultUnit(kony.flex.DP);
        flxFirst.add();
        var flxSecond = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxSecond",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "sknBlueHorizontalLine",
            "top": "0dp",
            "width": "25%",
            "zIndex": 3
        }, controller.args[0], "flxSecond"), extendConfig({}, controller.args[1], "flxSecond"), extendConfig({}, controller.args[2], "flxSecond"));
        flxSecond.setDefaultUnit(kony.flex.DP);
        flxSecond.add();
        var flxThird = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxThird",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "sknBlueHorizontalLine",
            "top": "0dp",
            "width": "25%",
            "zIndex": 3
        }, controller.args[0], "flxThird"), extendConfig({}, controller.args[1], "flxThird"), extendConfig({}, controller.args[2], "flxThird"));
        flxThird.setDefaultUnit(kony.flex.DP);
        flxThird.add();
        var flxFourth = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxFourth",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0b8bc24a38d0b41",
            "top": "0dp",
            "width": "25%",
            "zIndex": 3
        }, controller.args[0], "flxFourth"), extendConfig({}, controller.args[1], "flxFourth"), extendConfig({}, controller.args[2], "flxFourth"));
        flxFourth.setDefaultUnit(kony.flex.DP);
        flxFourth.add();
        flxHorizontalConnector.add(flxFirst, flxSecond, flxThird, flxFourth);
        flxTracker.add(flxTravellerIconContainer, flxRouteIconContainer, flxTrackingIconContainer, flxVehicleIconContainer, flxVerificationIconContainer, flxHorizontalConnector);
        JourneyTracking.add(flxTracker);
        return JourneyTracking;
    }
})
;
define('com/konymp/JourneyTracking/JourneyTrackingConfig',[],function() {
    return {
        "properties": [{
            "name": "sknTraveller",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknTracking",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknRoute",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknVehicle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknVerification",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "srcTravelling",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "srcTracking",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "srcRoute",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "srcVehicle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "srcVerification",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textTravelling",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textTracking",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textRoute",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textVehicle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textVerification",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknFirstLine",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknSecondLine",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknThirdLine",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknFourthLine",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/konymp/progressBarIndicator/userprogressBarIndicatorController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/progressBarIndicator/progressBarIndicatorControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konymp/progressBarIndicator/progressBarIndicatorController", ["com/konymp/progressBarIndicator/userprogressBarIndicatorController", "com/konymp/progressBarIndicator/progressBarIndicatorControllerActions"], function() {
    var controller = require("com/konymp/progressBarIndicator/userprogressBarIndicatorController");
    var actions = require("com/konymp/progressBarIndicator/progressBarIndicatorControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/progressBarIndicator/progressBarIndicator',[],function() {
    return function(controller) {
        var progressBarIndicator = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "10%",
            "id": "progressBarIndicator",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "progressBarIndicator"), extendConfig({}, controller.args[1], "progressBarIndicator"), extendConfig({}, controller.args[2], "progressBarIndicator"));
        progressBarIndicator.setDefaultUnit(kony.flex.DP);
        var FlexGroup0be874bdc57b949 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "FlexGroup0be874bdc57b949",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "FlexGroup0be874bdc57b949"), extendConfig({}, controller.args[1], "FlexGroup0be874bdc57b949"), extendConfig({}, controller.args[2], "FlexGroup0be874bdc57b949"));
        FlexGroup0be874bdc57b949.setDefaultUnit(kony.flex.DP);
        var flxTracker = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxTracker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0df6ed33272a84b",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxTracker"), extendConfig({}, controller.args[1], "flxTracker"), extendConfig({}, controller.args[2], "flxTracker"));
        flxTracker.setDefaultUnit(kony.flex.DP);
        var FlexContainer0f2ccf00d64614d = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "FlexContainer0f2ccf00d64614d",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "5%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "FlexContainer0f2ccf00d64614d"), extendConfig({}, controller.args[1], "FlexContainer0f2ccf00d64614d"), extendConfig({}, controller.args[2], "FlexContainer0f2ccf00d64614d"));
        FlexContainer0f2ccf00d64614d.setDefaultUnit(kony.flex.DP);
        var flxTravellerIcon = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "flxTravellerIcon",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0i9326579ae0640",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "flxTravellerIcon"), extendConfig({}, controller.args[1], "flxTravellerIcon"), extendConfig({}, controller.args[2], "flxTravellerIcon"));
        flxTravellerIcon.setDefaultUnit(kony.flex.DP);
        var Image0gc8d3fa5977f46 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "Image0gc8d3fa5977f46",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "myaccount.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "Image0gc8d3fa5977f46"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0gc8d3fa5977f46"), extendConfig({}, controller.args[2], "Image0gc8d3fa5977f46"));
        flxTravellerIcon.add(Image0gc8d3fa5977f46);
        var Label0i4190dc1fdc640 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "Label0i4190dc1fdc640",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Traveller",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0i4190dc1fdc640"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0i4190dc1fdc640"), extendConfig({}, controller.args[2], "Label0i4190dc1fdc640"));
        FlexContainer0f2ccf00d64614d.add(flxTravellerIcon, Label0i4190dc1fdc640);
        var CopyFlexContainer0gffbe4e3795c45 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "CopyFlexContainer0gffbe4e3795c45",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "23%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "CopyFlexContainer0gffbe4e3795c45"), extendConfig({}, controller.args[1], "CopyFlexContainer0gffbe4e3795c45"), extendConfig({}, controller.args[2], "CopyFlexContainer0gffbe4e3795c45"));
        CopyFlexContainer0gffbe4e3795c45.setDefaultUnit(kony.flex.DP);
        var CopyflxTravellerIcon0b782e24267dc47 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "CopyflxTravellerIcon0b782e24267dc47",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorder",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "CopyflxTravellerIcon0b782e24267dc47"), extendConfig({}, controller.args[1], "CopyflxTravellerIcon0b782e24267dc47"), extendConfig({}, controller.args[2], "CopyflxTravellerIcon0b782e24267dc47"));
        CopyflxTravellerIcon0b782e24267dc47.setDefaultUnit(kony.flex.DP);
        var CopyImage0e1a4439465e740 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "CopyImage0e1a4439465e740",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "myaccount.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "CopyImage0e1a4439465e740"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyImage0e1a4439465e740"), extendConfig({}, controller.args[2], "CopyImage0e1a4439465e740"));
        CopyflxTravellerIcon0b782e24267dc47.add(CopyImage0e1a4439465e740);
        var CopyLabel0f17e05cf0acf47 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "CopyLabel0f17e05cf0acf47",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Tracking",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "CopyLabel0f17e05cf0acf47"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyLabel0f17e05cf0acf47"), extendConfig({}, controller.args[2], "CopyLabel0f17e05cf0acf47"));
        CopyFlexContainer0gffbe4e3795c45.add(CopyflxTravellerIcon0b782e24267dc47, CopyLabel0f17e05cf0acf47);
        var CopyFlexContainer0d8777e20c4cc44 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "CopyFlexContainer0d8777e20c4cc44",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "41%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "CopyFlexContainer0d8777e20c4cc44"), extendConfig({}, controller.args[1], "CopyFlexContainer0d8777e20c4cc44"), extendConfig({}, controller.args[2], "CopyFlexContainer0d8777e20c4cc44"));
        CopyFlexContainer0d8777e20c4cc44.setDefaultUnit(kony.flex.DP);
        var CopyflxTravellerIcon0g08d7af0d92041 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "CopyflxTravellerIcon0g08d7af0d92041",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorder",
            "top": "11dp",
            "width": "35dp"
        }, controller.args[0], "CopyflxTravellerIcon0g08d7af0d92041"), extendConfig({}, controller.args[1], "CopyflxTravellerIcon0g08d7af0d92041"), extendConfig({}, controller.args[2], "CopyflxTravellerIcon0g08d7af0d92041"));
        CopyflxTravellerIcon0g08d7af0d92041.setDefaultUnit(kony.flex.DP);
        var CopyImage0aae2f8aa92234d = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "CopyImage0aae2f8aa92234d",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "myaccount.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "CopyImage0aae2f8aa92234d"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyImage0aae2f8aa92234d"), extendConfig({}, controller.args[2], "CopyImage0aae2f8aa92234d"));
        CopyflxTravellerIcon0g08d7af0d92041.add(CopyImage0aae2f8aa92234d);
        var CopyLabel0ge7cd07946b047 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "CopyLabel0ge7cd07946b047",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Route",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "CopyLabel0ge7cd07946b047"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyLabel0ge7cd07946b047"), extendConfig({}, controller.args[2], "CopyLabel0ge7cd07946b047"));
        CopyFlexContainer0d8777e20c4cc44.add(CopyflxTravellerIcon0g08d7af0d92041, CopyLabel0ge7cd07946b047);
        var CopyFlexContainer0e25a5aa0eea145 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "CopyFlexContainer0e25a5aa0eea145",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "59%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "CopyFlexContainer0e25a5aa0eea145"), extendConfig({}, controller.args[1], "CopyFlexContainer0e25a5aa0eea145"), extendConfig({}, controller.args[2], "CopyFlexContainer0e25a5aa0eea145"));
        CopyFlexContainer0e25a5aa0eea145.setDefaultUnit(kony.flex.DP);
        var CopyflxTravellerIcon0a5d4739b932b49 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "CopyflxTravellerIcon0a5d4739b932b49",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorder",
            "top": "11dp",
            "width": "35dp"
        }, controller.args[0], "CopyflxTravellerIcon0a5d4739b932b49"), extendConfig({}, controller.args[1], "CopyflxTravellerIcon0a5d4739b932b49"), extendConfig({}, controller.args[2], "CopyflxTravellerIcon0a5d4739b932b49"));
        CopyflxTravellerIcon0a5d4739b932b49.setDefaultUnit(kony.flex.DP);
        var CopyImage0h52d1c3c01cd4a = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "CopyImage0h52d1c3c01cd4a",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "myaccount.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "CopyImage0h52d1c3c01cd4a"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyImage0h52d1c3c01cd4a"), extendConfig({}, controller.args[2], "CopyImage0h52d1c3c01cd4a"));
        CopyflxTravellerIcon0a5d4739b932b49.add(CopyImage0h52d1c3c01cd4a);
        var CopyLabel0ab3f8fc12ebf44 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "CopyLabel0ab3f8fc12ebf44",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Vehicle",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "CopyLabel0ab3f8fc12ebf44"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyLabel0ab3f8fc12ebf44"), extendConfig({}, controller.args[2], "CopyLabel0ab3f8fc12ebf44"));
        CopyFlexContainer0e25a5aa0eea145.add(CopyflxTravellerIcon0a5d4739b932b49, CopyLabel0ab3f8fc12ebf44);
        var CopyFlexContainer0i0bc677a171a45 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "CopyFlexContainer0i0bc677a171a45",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "77%",
            "isModalContainer": false,
            "skin": "CopyslFbox0gd82f5261e3748",
            "width": "18%",
            "zIndex": 4
        }, controller.args[0], "CopyFlexContainer0i0bc677a171a45"), extendConfig({}, controller.args[1], "CopyFlexContainer0i0bc677a171a45"), extendConfig({}, controller.args[2], "CopyFlexContainer0i0bc677a171a45"));
        CopyFlexContainer0i0bc677a171a45.setDefaultUnit(kony.flex.DP);
        var CopyflxTravellerIcon0d42cc6ba70e64e = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "35dp",
            "id": "CopyflxTravellerIcon0d42cc6ba70e64e",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorder",
            "top": "11dp",
            "width": "35dp",
            "zIndex": 3
        }, controller.args[0], "CopyflxTravellerIcon0d42cc6ba70e64e"), extendConfig({}, controller.args[1], "CopyflxTravellerIcon0d42cc6ba70e64e"), extendConfig({}, controller.args[2], "CopyflxTravellerIcon0d42cc6ba70e64e"));
        CopyflxTravellerIcon0d42cc6ba70e64e.setDefaultUnit(kony.flex.DP);
        var CopyImage0e35571f33abb48 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "20dp",
            "id": "CopyImage0e35571f33abb48",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "myaccount.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "CopyImage0e35571f33abb48"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyImage0e35571f33abb48"), extendConfig({}, controller.args[2], "CopyImage0e35571f33abb48"));
        CopyflxTravellerIcon0d42cc6ba70e64e.add(CopyImage0e35571f33abb48);
        var CopyLabel0id4e44bd701541 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "CopyLabel0id4e44bd701541",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0ce185da7206c4f",
            "text": "Verification",
            "textStyle": {},
            "top": "0",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "CopyLabel0id4e44bd701541"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyLabel0id4e44bd701541"), extendConfig({}, controller.args[2], "CopyLabel0id4e44bd701541"));
        CopyFlexContainer0i0bc677a171a45.add(CopyflxTravellerIcon0d42cc6ba70e64e, CopyLabel0id4e44bd701541);
        var FlexContainer0cbf01f2cfafa4e = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "40%",
            "clipBounds": true,
            "height": "2dp",
            "id": "FlexContainer0cbf01f2cfafa4e",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0df36b48b298e4a",
            "top": "20dp",
            "width": "70%",
            "zIndex": 3
        }, controller.args[0], "FlexContainer0cbf01f2cfafa4e"), extendConfig({}, controller.args[1], "FlexContainer0cbf01f2cfafa4e"), extendConfig({}, controller.args[2], "FlexContainer0cbf01f2cfafa4e"));
        FlexContainer0cbf01f2cfafa4e.setDefaultUnit(kony.flex.DP);
        FlexContainer0cbf01f2cfafa4e.add();
        flxTracker.add(FlexContainer0f2ccf00d64614d, CopyFlexContainer0gffbe4e3795c45, CopyFlexContainer0d8777e20c4cc44, CopyFlexContainer0e25a5aa0eea145, CopyFlexContainer0i0bc677a171a45, FlexContainer0cbf01f2cfafa4e);
        FlexGroup0be874bdc57b949.add(flxTracker);
        progressBarIndicator.add(FlexGroup0be874bdc57b949);
        return progressBarIndicator;
    }
})
;
define('com/konymp/progressBarIndicator/progressBarIndicatorConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define('com/konymp/vuegooglemaps/analytics',[],function() {
    return {
        analyticsHost: "https://sampleapps.konycloud.com:443/services/data/v1/analytics/objects/log",
        constructBody: function() {
            try {
                var date = new Date();
                var deviceInfo = this.getDeviceOS();
                var body = {
                    "deviceModel": deviceInfo.model,
                    "Locale": kony.i18n.getCurrentDeviceLocale().language,
                    "Platform": deviceInfo.name,
                    "PlatformVersion": deviceInfo.version,
                    "appId": appConfig.appId,
                    "serviceUrl": appConfig.serviceUrl,
                    "itemGuid": "a9e85f7665864bad872de6122349dc3c",
                    "assetName": "com.konymp.vuegooglemaps",
                    "assetVersion": "1.0.0",
                    "releaseMode": !appConfig.isDebug,
                    "konySdkVersion": kony.sdk.version,
                    "date": date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear(),
                    "endpointId": this.generateUniqueId(),
                    "deviceHeight": deviceInfo.deviceHeight,
                    "deviceWidth": deviceInfo.deviceWidth,
                    "kuid": "u624f5929bef41838b0dfafd4252270c",
                };
                return body;
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        notifyAnalytics: function() {
            try {
                if (this.checkInternetConnectivity() && this.isItFirstTime()) {
                    var httpclient = new kony.net.HttpRequest();
                    httpclient.open(constants.HTTP_METHOD_POST, this.analyticsHost);
                    httpclient.setRequestHeader("Content-Type", "application/json");
                    httpclient.send(JSON.stringify(this.constructBody()));
                }
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        getDeviceOS: function() {
            try {
                return kony.os.deviceInfo();
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        generateUniqueId: function() {
            try {
                return kony.crypto.createHMacHash("SHA512", this.getDeviceOS().deviceid, "KonyAnalytics");
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        isItFirstTime: function() {
            var bodyDetails = this.constructBody();
            var assetVersion = kony.store.getItem(bodyDetails.assetName + "Version");
            if (kony.sdk.isNullOrUndefined(assetVersion) || assetVersion != bodyDetails.assetVersion) {
                kony.store.setItem(bodyDetails.assetName + "Version", bodyDetails.assetVersion);
                return true;
            } else {
                return false;
            }
        },
        checkInternetConnectivity: function() {
            return kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
        }
    };
});

/*
#
#  Created by Team Kony.
#  Copyright (c) 2018 Kony Inc. All rights reserved.
#
*/
define('com/konymp/vuegooglemaps/KonyLogger',[],function() {
    /**
     * @member of  KonyLogger.js
     * @function KonyLogger
     * @param method - The function to be called to log the given message. 
     * When no parameter is passed, kony.print is called by default.
     * @returns an instance of KonyLogger class.
     * @description - This is the constructor for KonyLogger. 
     * This method initializes the instance created.
     **/
    var KonyLogger = function() {
        this.printMethod = kony.print;
        this.reuseableComponentName = arguments[0] || "appContext";
        var loggerGenerator = function() {
            this.trace = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "TRACE", message, event);
            };
            this.debug = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "DEBUG", message, event);
            };
            this.info = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "INFO", message, event);
            };
            this.warn = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "WARN", message, event);
            };
            this.error = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "ERROR", message, event);
            };
        };
        this.setLogLevel = function(logLevel) {
            if (this.isValidLogLevel(logLevel)) {
                if (typeof logLevel === "string") {
                    this.currentLogLevel = this.logLevels[logLevel];
                } else if (typeof logLevel === "number") {
                    this.currentLogLevel = logLevel;
                }
                var logMethods = Object.keys(this.logLevels);
                for (var i = 0; i < logMethods.length; i++) {
                    var methodName = logMethods[i].toLowerCase();
                    this[methodName] = (i < this.currentLogLevel) ? function() {} : (new loggerGenerator())[methodName];
                }
                return true;
            } else {
                return false;
            }
        };
        this.enableServerLogging = false;
        this.logMethod = function(functionName, logLevel, message, eventType) {
            var logObj = {
                "component": this.reuseableComponentName || "",
                "event": this.supportedEventTypes[eventType] || this.supportedEventTypes[this.DEFAULT],
                "function": functionName || "",
                "timestamp": KonyLogger.Utils.getDateTimeStamp() || "",
                "level": logLevel || "",
                "message": message || ""
            };
            if (this.enableServerLogging === true) {
                if ((KNYMetricsService !== undefined) && (KNYMetricsService !== null) && (KNYMetricsService !== "")) {
                    if (typeof KNYMetricsService.sendEvent === "function") {
                        /** sendEvent params - eventType, subEventType, formID, widgetID, flowTag, metaInfo{JSON} **/
                        KNYMetricsService.sendEvent("Custom", "KonyLogger", "MarketPlaceComponent", logObj.component, null, logObj);
                    }
                }
            }
            this.printMethod(JSON.stringify(logObj, null, '\t'));
        };
        this.setLogLevel("TRACE");
    };
    /**
     * @member of  KonyLogger
     * @property logLevels - This enum holds the 6 levels of logging and their order.
     **/
    KonyLogger.prototype.logLevels = {
        "TRACE": 0,
        "DEBUG": 1,
        "INFO": 2,
        "WARN": 3,
        "ERROR": 4,
        "SILENT": 5
    };
    /**
     * @member of  KonyLogger
     * @property eventTypes - This array holds 8 types of events.
     **/
    KonyLogger.prototype.supportedEventTypes = ["DEFAULT", "FUNCTION_ENTRY", "FUNCTION_EXIT", "SUCCESS_CALLBACK", "ERROR_CALLBACK", "EXCEPTION", "SERVICE_CALL", "DATA_STORE"];
    /** KonyLogger EventTypes**/
    KonyLogger.prototype.DEFAULT = 0;
    KonyLogger.prototype.FUNCTION_ENTRY = 1;
    KonyLogger.prototype.FUNCTION_EXIT = 2;
    KonyLogger.prototype.SUCCESS_CALLBACK = 3;
    KonyLogger.prototype.ERROR_CALLBACK = 4;
    KonyLogger.prototype.EXCEPTION = 5;
    KonyLogger.prototype.SERVICE_CALL = 6;
    KonyLogger.prototype.DATA_STORE = 7;
    /**
     * @member of  KonyLogger
     * @property defaultLogLevel - This property holds the default logLevel
     * It is intialised to "TRACE".
     **/
    KonyLogger.prototype.defaultLogLevel = KonyLogger.prototype.logLevels["TRACE"];
    /**
     * @member of  KonyLogger
     * @function isValidLogLevel
     * @param logLevel - (string or number)
     * @description - This method validates the logLevel parameter with the enum logLevels
     * @return boolean
     **/
    KonyLogger.prototype.isValidLogLevel = function(logLevel) {
        if ((logLevel !== undefined) && (logLevel !== null) && (logLevel !== "")) {
            if (typeof logLevel === "string") {
                if (logLevel.toUpperCase() in this.logLevels) {
                    return true;
                } else {
                    return false;
                }
            } else if (typeof logLevel === "number") {
                for (var logLevelKey in this.logLevels) {
                    if (logLevel === this.logLevels.logLevelKey) {
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        }
    };
    /**
     * @member of  KonyLogger
     * @function getLogLevel
     * @param none
     * @description - This method returns the current log level of the instance
     * @return type number
     **/
    KonyLogger.prototype.getLogLevel = function() {
        return this.currentLogLevel;
    };
    /**
     * @member of  KonyLogger
     * @function setPrintMethod
     * @param method: type function - The method to print the log/message.
     * The default value is kony.print
     * @description - This method sets the current log method to 'method'
     * @return none
     **/
    KonyLogger.prototype.setPrintMethod = function(method) {
        if ((method !== undefined) && (method !== null) && (method !== "")) {
            if (typeof method === "function") {
                this.printMethod = method;
            }
        }
    };
    KonyLogger.Utils = {};
    /**
     * @member of  KonyLogger
     * @function getDateTimeStamp
     * @param none
     * @description - It returns the current date and time stamp in "DD/MM/YY HH:MM AM/PM" format
     * @return type string
     **/
    KonyLogger.Utils.getDateTimeStamp = function() {
        var dateTimeStamp = "";
        var currentDateObj = new Date();
        dateTimeStamp += currentDateObj.getDate() + "/" + (currentDateObj.getMonth() + 1) + "/" + currentDateObj.getFullYear();
        dateTimeStamp += " ";
        var hours = currentDateObj.getHours();
        if (hours > 12) {
            dateTimeStamp += (hours - 12) + ":" + currentDateObj.getMinutes() + " PM";
        } else {
            dateTimeStamp += hours + ":" + currentDateObj.getMinutes() + " AM";
        }
        return dateTimeStamp;
    };
    return KonyLogger;
});

define('com/konymp/vuegooglemaps/ControllerImplementation',['./KonyLogger'], function(konyLoggerModule) {
    var konymp = konymp || {};
    konymp.logger = (new konyLoggerModule("Vue Google Maps")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    var ControllerImplementation = function(componentInstance, componentName) {
        this.componentInstance = componentInstance;
        /**
         * @function addPolygon
         * @private
         * @param {JSON} path
         * @description: Add polygon to the Google Map with the provided json path object.
         */
        this.addPolygon = function(path) {
            konymp.logger.trace("------Entering addPolygon Function------", konymp.logger.FUNCTION_ENTRY);
            try {
                this.componentInstance.view.brsrGoogleMaps.evaluateJavaScript('addPolygonAppJSContext(' + JSON.stringify(path) + ');');
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
                this.errorCallback(this.componentInstance._commonExceptionCode, exception.message);
            }
            konymp.logger.trace("------Exiting addPolygon Function------", konymp.logger.FUNCTION_EXIT);
        };
        /**
         * @function addPolyline
         * @private
         * @param {JSON} path
         * @description: Add Polyline to the Google Map with the provided json path object.
         */
        this.addPolyline = function(path) {
            konymp.logger.trace("------Entering addPolyline Function------", konymp.logger.FUNCTION_ENTRY);
            try {
                this.componentInstance.view.brsrGoogleMaps.evaluateJavaScript('addPolylineAppJSContext(' + JSON.stringify(path) + ');');
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
                this.errorCallback(this.componentInstance._commonExceptionCode, exception.message);
            }
            konymp.logger.trace("------Exiting addPolyline Function------", konymp.logger.FUNCTION_EXIT);
        };
        /**
         * @function addMarker
         * @private
         * @param {JSON} path
         * @description: Add Marker to the Google Map with the provided json path object.
         */
        this.addMarker = function(path) {
            konymp.logger.trace("------Entering addMarker Function------", konymp.logger.FUNCTION_ENTRY);
            try {
                this.componentInstance.view.brsrGoogleMaps.evaluateJavaScript('addMarkerAppJSContext(' + JSON.stringify(path) + ');');
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
                this.errorCallback(this.componentInstance._commonExceptionCode, exception.message);
            }
            konymp.logger.trace("------Exiting addMarker Function------", konymp.logger.FUNCTION_EXIT);
        };
        this.destroy = function() {
            this.componentInstance.view.brsrGoogleMaps.evaluateJavaScript('destroyAppJSContext();');
        };
        /**
         * @function createPropertiesJSON
         * @private
         * @param {String} GoogleAPIKey
         * @param {String} CenterLat
         * @param {String} CenterLong
         * @param {String} MapType
         * @param {String} AddMarkerLat
         * @param {String} AddMarkerLong
         * @param {String} AddMarkerText
         * @param {boolean} AllowMapZoom
         * @description: Returns a JSON string of the exposed properties for the component.
         */
        this.createPropertiesJSON = function(GoogleAPIKey, CenterLat, CenterLong, MapType, AddMarkerLat, AddMarkerLong, AddMarkerText, AllowMapZoom) {
            konymp.logger.trace("------Entering addMarker Function------", konymp.logger.FUNCTION_ENTRY);
            let stringOutput = "{";
            stringOutput = stringOutput + "'GoogleAPIKey':'" + GoogleAPIKey + "'" + "," + "'CenterLat':'" + CenterLat + "'";
            stringOutput = stringOutput + "," + "'CenterLong':'" + CenterLong + "'" + "," + "'MapType':'" + MapType + "'";
            stringOutput = stringOutput + "," + "'AddMarkerLat':'" + AddMarkerLat + "'" + "," + "'AddMarkerLong':'" + AddMarkerLong + "'" + ",";
            stringOutput = stringOutput + "'AddMarkerText':'" + AddMarkerText + "'" + "," + "'AllowMapZoom':" + AllowMapZoom + "}";
            konymp.logger.trace("------Exiting errorCallback Function------", konymp.logger.FUNCTION_EXIT);
            return stringOutput;
        };
        /**
         * @function errorCallback
         * @private
         * @param {number} expCode
         * @param {string} expMesg
         * @description: invokes onErrorCallback event
         */
        this.errorCallback = function(expCode, expMesg) {
            konymp.logger.trace("------Entering errorCallback Function------", konymp.logger.FUNCTION_ENTRY);
            if (this.componentInstance.onErrorCallback) {
                var errObj = konymp.logger.getErrorObject(expCode, expMesg);
                this.componentInstance.onErrorCallback(errObj);
            } else {
                konymp.logger.error("onErrorCallback event undefined, throwing the exception to application context", konymp.logger.EXCEPTION);
                throw {
                    "errorCode": expCode,
                    "message": expMesg
                };
            }
            konymp.logger.trace("------Exiting errorCallback Function------", konymp.logger.FUNCTION_EXIT);
        };
    };
    return ControllerImplementation;
});

define("com/konymp/vuegooglemaps/uservuegooglemapsController", ['./KonyLogger', './ControllerImplementation'], function(konyLoggerModule, ControllerImplementation) {
    var konymp = konymp || {};
    konymp.logger = (new konyLoggerModule("VueGoogleMaps Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            var analytics = require("com/konymp/" + "vuegooglemaps" + "/analytics");
            analytics.notifyAnalytics();
            this._centerLat = null;
            this._centerLong = null;
            this._googleApiKey = null;
            this._mapZoom = false;
            this._mapType = null;
            this._addMarketLat = null;
            this._addMarketLong = null;
            this._addMarketText = null;
            this._commonExceptionCode = 90005;
            this.handler = new ControllerImplementation(this, baseConfig.id);
            /**
             * @Function: NativeContextMethod
             * @description: Interaction method between the Component Controller and the Browser Widget.
             */
            NativeContextMethod = function() {
                if (this._centerLat === null || this._centerLong === null) {
                    this.onErrorCallback('Please Provide Center Lattitude/Longitude', 4569);
                    return;
                }
                this.view.brsrGoogleMaps.evaluateJavaScript('AppJSContextApplyProperties(' + this.handler.createPropertiesJSON(this._googleApiKey, this._centerLat, this._centerLong, this._mapType, this._addMarkerLat, this._addMarkerLong, this._addMarkerText, this._mapZoom) + ');');
            }.bind(this);
            /**
             * @Event: onMapClickEvent
             * @description: Calls the further event for the on click of the map.
             * @param {Object} param
             */
            onMapClickEvent = function(param) {
                if (this.onMapClick === undefined) return;
                this.onMapClick(param);
            }.bind(this);
            /**
             * @Event: onMapRClickEvent
             * @description: Calls the further event for the on right click of the map.
             * @param {Object} param
             */
            onMapRightClickEvent = function(param) {
                if (this.onMapRightClick === undefined) return;
                this.onMapRightClick(param);
            }.bind(this);
            /**
             * @Event: onErrorCallback
             * @description: Event fired on any of the error during the component.
             * @param {Object} param
             */
            onErrorCallback = function(param) {
                if (this.onErrorCallback === undefined) return;
                this.onErrorCallback(param);
            }.bind(this);
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            /**
             * @property: googleApiKey
             * @description: This googleApiKey is for the google map key.
             * @param: string
             */
            defineSetter(this, "googleApiKey", function(val) {
                konymp.logger.trace("----------Entering googleApiKey Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._googleApiKey = val;
                }
                konymp.logger.trace("----------Exiting googleApiKey Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "googleApiKey", function() {
                konymp.logger.trace("----------Entering googleApiKey Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting googleApiKey Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._googleApiKey;
            });
            /**
             * @property: centerLat
             * @description: This centerLat is for getting the map center's latitude location.
             * @param: string
             */
            defineSetter(this, "centerLat", function(val) {
                konymp.logger.trace("----------Entering centerLat Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._centerLat = val;
                }
                konymp.logger.trace("----------Exiting centerLat Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "centerLat", function() {
                konymp.logger.trace("----------Entering centerLat Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting centerLat Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._centerLat;
            });
            /**
             * @property: centerLong
             * @description: This centerLong is for getting the map center's longitude location.
             * @param: string
             */
            defineSetter(this, "centerLong", function(val) {
                konymp.logger.trace("----------Entering centerLong Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._centerLong = val;
                }
                konymp.logger.trace("----------Exiting centerLong Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "centerLong", function() {
                konymp.logger.trace("----------Entering centerLong Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting centerLong Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._centerLong;
            });
            /**
             * @property: mapZoom
             * @description: This mapZoom is for allowing whether user can zoom in or out on the map
             * @param: Number
             */
            defineSetter(this, "mapZoom", function(val) {
                konymp.logger.trace("----------Entering mapZoom Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._mapZoom = val;
                }
                konymp.logger.trace("----------Exiting mapZoom Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "mapZoom", function() {
                konymp.logger.trace("----------Entering mapZoom Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting googmapZoomlmapZoomeApiKey Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._mapZoom;
            });
            /**
             * @property: mapType
             * @description: This mapType is for what type of map to be displayed (For eg. Terrain, Satellite)
             * @param: List
             */
            defineSetter(this, "mapType", function(val) {
                konymp.logger.trace("----------Entering mapType Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._mapType = val;
                }
                konymp.logger.trace("----------Exiting mapType Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "mapType", function() {
                konymp.logger.trace("----------Entering mapType Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting mapType Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._mapType;
            });
            /**
             * @property: addMarkerLat
             * @description: This addMarkerLat is for adding a marker Latitude at particular lat long position.
             * @param: string
             */
            defineSetter(this, "addMarkerLat", function(val) {
                konymp.logger.trace("----------Entering addMarkerLat Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._addMarkerLat = val;
                }
                konymp.logger.trace("----------Exiting addMarkerLat Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "addMarkerLat", function() {
                konymp.logger.trace("----------Entering addMarkerLat Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting addMarkerLat Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._addMarkerLat;
            });
            /**
             * @property: addMarkerLong
             * @description: This addMarkerLong is for adding a marker Longitude at particular lat long position.
             * @param: string
             */
            defineSetter(this, "addMarkerLong", function(val) {
                konymp.logger.trace("----------Entering addMarkerLong Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._addMarkerLong = val;
                }
                konymp.logger.trace("----------Exiting addMarkerLong Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "addMarkerLong", function() {
                konymp.logger.trace("----------Entering addMarkerLong Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting addMarkerLong Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._addMarkerLong;
            });
            /**
             * @property: addMarkerText
             * @description: This addMarkerText is for adding a marker Text at particular lat long position.
             * @param: string
             */
            defineSetter(this, "addMarkerText", function(val) {
                konymp.logger.trace("----------Entering addMarkerText Setter---------", konymp.logger.FUNCTION_ENTRY);
                if (val !== undefined && val !== "") {
                    this._addMarkerText = val;
                }
                konymp.logger.trace("----------Exiting addMarkerText Setter---------", konymp.logger.FUNCTION_EXIT);
            });
            defineGetter(this, "addMarkerText", function() {
                konymp.logger.trace("----------Entering addMarkerText Getter---------", konymp.logger.FUNCTION_ENTRY);
                konymp.logger.trace("----------Exiting addMarkerText Getter---------", konymp.logger.FUNCTION_EXIT);
                return this._addMarkerText;
            });
        },
        /**
         * @function: addPolygon
         * @description: Add a polygon with the provided path paramter to the map.
         * @param {Object} path
         */
        addPolygon: function(path) {
            konymp.logger.trace("------Entering addPolygon Function------", konymp.logger.FUNCTION_ENTRY);
            this.handler.addPolygon(path);
            konymp.logger.trace("------Exiting addPolygon Function------", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function: addPolyline
         * @description: Adds polyline onto the map with the provided paramteres.
         * @param {Object} path
         */
        addPolyline: function(path) {
            konymp.logger.trace("------Entering addPolyline Function------", konymp.logger.FUNCTION_ENTRY);
            this.handler.addPolyline(path);
            konymp.logger.trace("------Exiting addPolyline Function------", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function: addMarkerText
         * @description: Add a marker with the description onto the map provided by the location as parameter.
         * @param {Object} path
         */
        addMarker: function(path) {
            konymp.logger.trace("------Entering addMarker Function------", konymp.logger.FUNCTION_ENTRY);
            this.handler.addMarker(path);
            konymp.logger.trace("------Exiting addMarker Function------", konymp.logger.FUNCTION_EXIT);
        },
        destroy: function() {
            konymp.logger.trace("------Entering destroy Function------", konymp.logger.FUNCTION_ENTRY);
            this.handler.destroy();
            konymp.logger.trace("------Exiting destroy Function------", konymp.logger.FUNCTION_EXIT);
        }
    };
});
define("com/konymp/vuegooglemaps/vuegooglemapsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/konymp/vuegooglemaps/vuegooglemapsController", ["com/konymp/vuegooglemaps/uservuegooglemapsController", "com/konymp/vuegooglemaps/vuegooglemapsControllerActions"], function() {
    var controller = require("com/konymp/vuegooglemaps/uservuegooglemapsController");
    var actions = require("com/konymp/vuegooglemaps/vuegooglemapsControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/vuegooglemaps/vuegooglemaps',[],function() {
    return function(controller) {
        var vuegooglemaps = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "vuegooglemaps",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "vuegooglemaps"), extendConfig({}, controller.args[1], "vuegooglemaps"), extendConfig({}, controller.args[2], "vuegooglemaps"));
        vuegooglemaps.setDefaultUnit(kony.flex.DP);
        var brsrGoogleMaps = new kony.ui.Browser(extendConfig({
            "detectTelNumber": true,
            "enableNativeCommunication": true,
            "enableZoom": false,
            "height": "100%",
            "id": "brsrGoogleMaps",
            "isVisible": true,
            "left": "0dp",
            "requestURLConfig": {
                "URL": "Copyvuegooglemaps/index.html",
                "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
            },
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "brsrGoogleMaps"), extendConfig({}, controller.args[1], "brsrGoogleMaps"), extendConfig({}, controller.args[2], "brsrGoogleMaps"));
        vuegooglemaps.add(brsrGoogleMaps);
        return vuegooglemaps;
    }
})
;
define('com/konymp/vuegooglemaps/vuegooglemapsConfig',[],function() {
    return {
        "properties": [{
            "name": "centerLat",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "mapType",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "addMarkerLat",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "googleApiKey",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "mapZoom",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "centerLong",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "addMarkerLong",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "addMarkerText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["addPolygon", "addPolyline", "addMarker", "destroy"],
        "events": ["onMapClick", "onMapRightClick", "onErrorCallback"]
    }
});

define("com/konyqfs/placeDetails/userplaceDetailsController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._startYear = 0;
            this._endYear = 0;
            this._totalDays = 31;
            this._totalHours = 12;
            this._totalMins = 60;
            this._totalMonths = 12;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineSetter(this, "startYear", function(val) {
                if (typeof val == 'number') {
                    this._startYear = val;
                } else {
                    this._startYear = null;
                }
            });
            defineGetter(this, "startYear", function() {
                return this._startYear;
            });
            defineSetter(this, "endYear", function(val) {
                if (typeof val == 'number') {
                    this._endYear = val;
                } else {
                    this._endYear = null;
                }
            });
            defineGetter(this, "endYear", function() {
                return this._endYear;
            });
        },
        preShow: function() {
            this.setDefaultData();
        },
        setDefaultData: function() {
            this.setDefaultHourData();
            this.setDefaultMinsData();
            this.setDefaultAMPMData();
            this.setDefaultDatesData(this._totalDays);
            this.setDefaultMonthsData();
            this.setDefaultYearsData();
            this.setCurrentDate();
            this.setCurrentTime();
        },
        setDefaultHourData: function() {
            debugger;
            var hoursMasterData = [];
            for (i = 0; i <= this._totalHours; i++) {
                var hoursDataMap = [];
                if (i === 0) {
                    hoursDataMap.push(i);
                    hoursDataMap.push("HH")
                    hoursMasterData.push(hoursDataMap);
                } else {
                    hoursDataMap.push(i);
                    hoursDataMap.push(i)
                    hoursMasterData.push(hoursDataMap);
                }
            }
            this.view.lsHour.masterData = hoursMasterData;
        },
        setDefaultMinsData: function() {
            debugger;
            var minsMasterData = [];
            for (i = 0; i < this._totalMins; i++) {
                var minsDataMap = [];
                if (i === 0) {
                    minsDataMap.push(i);
                    minsDataMap.push("MM");
                    minsMasterData.push(minsDataMap);
                } else {
                    minsDataMap.push(i);
                    minsDataMap.push(i);
                    minsMasterData.push(minsDataMap);
                }
            }
            this.view.lsMins.masterData = minsMasterData;
        },
        setDefaultAMPMData: function() {
            debugger;
            var ampmMasterData = [];
            var ampmDataMap = [];
            ampmDataMap.push(0);
            ampmDataMap.push("AM");
            ampmMasterData.push(ampmDataMap);
            ampmDataMap = [];
            ampmDataMap.push(1);
            ampmDataMap.push("PM");
            ampmMasterData.push(ampmDataMap);
            this.view.lsAMPM.masterData = ampmMasterData;
        },
        setDefaultDatesData: function(numberOfDays) {
            debugger;
            var datesMasterData = [];
            for (i = 0; i < numberOfDays; i++) {
                var daysDataMap = [];
                daysDataMap.push(i);
                daysDataMap.push(i + 1)
                datesMasterData.push(daysDataMap);
            }
            this.view.lsDate.masterData = datesMasterData;
        },
        setDefaultMonthsData: function() {
            debugger;
            var monthsMasterData = [];
            var monthsDataMap = [];
            monthsDataMap = [];
            monthsDataMap.push(1);
            monthsDataMap.push("January");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(2);
            monthsDataMap.push("February");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(3);
            monthsDataMap.push("March");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(4);
            monthsDataMap.push("April");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(5);
            monthsDataMap.push("May");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(6);
            monthsDataMap.push("June");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(7);
            monthsDataMap.push("July");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(8);
            monthsDataMap.push("August");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(9);
            monthsDataMap.push("September");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(10);
            monthsDataMap.push("October");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(11);
            monthsDataMap.push("November");
            monthsMasterData.push(monthsDataMap);
            monthsDataMap = [];
            monthsDataMap.push(12);
            monthsDataMap.push("December");
            monthsMasterData.push(monthsDataMap);
            this.view.lsMonth.masterData = monthsMasterData;
        },
        setDefaultYearsData: function() {
            debugger;
            var diff = this._endYear - this._startYear;
            var yearsMasterData = [];
            for (i = 0; i <= diff; i++) {
                var yearsDataMap = [];
                yearsDataMap.push(i);
                yearsDataMap.push(this._startYear + (i))
                yearsMasterData.push(yearsDataMap);
            }
            this.view.lsYear.masterData = yearsMasterData;
        },
        getNumberOfDaysinCurrentMonth: function(month, year) {
            debugger;
            return new Date(year, month, 0).getDate();
        },
        setSelections: function(selectedDateKey) {
            debugger;
            this.view.lsDate.selectedKey = selectedDateKey;
        },
        searchForLocation: function() {
            debugger;
            var integrationObj = KNYMobileFabric.getIntegrationService("placeSearchAutoComplete");
            var data = {
                input: this.view.tbxDepartureDetails.text,
                key: "AIzaSyBeIDNhaa-u8IZcdqkNub-N648OCzb9QH4"
            };
            var header = {};
            var operationName = "getPlaceDetails";
            integrationObj.invokeOperation(operationName, header, data, this.operationSuccess.bind(this), this.operationFailure.bind(this));
        },
        operationSuccess: function(response) {
            debugger;
            if (response.predictions.length > 0) {
                this.view.flxSegParent.setVisibility(true);
                this.view.segPlaceDetails.setVisibility(true);
                this.view.segPlaceDetails.rowFocusSkin = "segRowFocusSkin";
                var data = [];
                for (var i = 0; i < response.predictions.length; i++) {
                    var segData = {};
                    segData["lblPlaceData"] = response.predictions[i].description;
                    data.push(segData);
                }
                this.view.segPlaceDetails.setData(data);
            } else {
                this.view.segPlaceDetails.removeAll();
                this.view.segPlaceDetails.setVisibility(false);
            }
            this.view.forceLayout();
        },
        operationFailure: function(err) {
            debugger;
        },
        onButtonClick: function() {
            debugger;
            var data = {};
            data["PlaceDetails"] = this.view.tbxDepartureDetails.text;
            var selectedHourIndex = this.view.lsHour.selectedKeyValue;
            var selectedHour = selectedHourIndex[1];
            var selectedMinsIndex = this.view.lsMins.selectedKeyValue;
            var selectedMins = selectedMinsIndex[1];
            var selectedAMPMIndex = this.view.lsAMPM.selectedKeyValue;
            var selectedAMPM = selectedAMPMIndex[1];
            var selectedDateIndex = this.view.lsDate.selectedKeyValue;
            var selectedDate = selectedDateIndex[1];
            var selectedMonthIndex = this.view.lsMonth.selectedKeyValue;
            var selectedMonth = selectedMonthIndex[1];
            var selectedYearIndex = this.view.lsYear.selectedKeyValue;
            var selectedYear = selectedYearIndex[1];
            var date = new Date(selectedMonth + "/" + selectedDate + "/" + selectedYear);
            data["Date"] = date.toString();
            var time = selectedHour + ":" + selectedMins + selectedAMPM
            data["Time"] = time;
            this.onDone(data);
        },
        setCurrentTime: function() {
            var now = new Date();
            var currentHour = now.getHours();
            var currentMins = now.getMinutes();
            var ampmSelected = "";
            if (currentHour >= 12) {
                if (currentHour === 12) {
                    currentHour = 12;
                    ampmSelected = "PM";
                    this.view.lsAMPM.selectedKey = 1;
                }
                currentHour = currentHour - 12;
                ampmSelected = "PM";
                this.view.lsAMPM.selectedKey = 1;
            } else {
                currentHour = currentHour;
                ampmSelected = "AM";
                this.view.lsAMPM.selectedKey = 0;
            }
            this.view.lsHour.selectedKey = Number(currentHour);
            this.view.lsMins.selectedKey = Number(currentMins);
        },
        setCurrentDate: function() {
            var date = new Date();
            var currentDate = date.getDate();
            var currentMonth = date.getMonth();
            var currentYear = date.getFullYear();
            this.view.lsDate.selectedKey = Number(currentDate) - 1;
            this.view.lsMonth.selectedKey = Number(currentMonth) + 1;
            var diff = Number(currentYear) - Number(this._startYear);
            this.view.lsYear.selectedKey = Number(diff);
        },
        setTime: function(timeString) {
            debugger;
            if (timeString) {
                var inputTime = timeString.split(":");
                var selectedHour = Number(inputTime[0]);
                var selectedMins = Number(inputTime[1]);
                var ampmSelected = ""
                if (selectedHour >= 12) {
                    selectedHour = selectedHour - 12;
                    ampmSelected = "PM";
                    this.view.lsAMPM.selectedKey = 1;
                } else {
                    selectedHour = selectedHour;
                    ampmSelected = "AM";
                    this.view.lsAMPM.selectedKey = 0;
                }
                this.view.lsHour.selectedKey = Number(selectedHour);
                this.view.lsMins.selectedKey = Number(selectedMins);
            } else {
                this.setCurrentTime();
            }
        },
        setDate: function(dateString) {
            debugger;
            if (dateString) {
                var date = new Date(dateString);
                var currentDate = date.getDate();
                var currentMonth = date.getMonth();
                var currentYear = date.getFullYear();
                this.view.lsDate.selectedKey = Number(currentDate) - 1;
                this.view.lsMonth.selectedKey = Number(currentMonth) + 1;
                var diff = Number(currentYear) - Number(this._startYear);
                this.view.lsYear.selectedKey = Number(diff);
            } else {
                this.setCurrentDate();
            }
        },
    };
});
define("com/konyqfs/placeDetails/placeDetailsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onKeyUp defined for tbxDepartureDetails **/
    AS_TextField_j43e6d33ef7b4c5b877487ed06750f10: function AS_TextField_j43e6d33ef7b4c5b877487ed06750f10(eventobject) {
        var self = this;
        return self.searchForLocation.call(this);
    },
    /** onRowClick defined for segPlaceDetails **/
    AS_Segment_c8ec59a4ad4e4be4875087314fd76919: function AS_Segment_c8ec59a4ad4e4be4875087314fd76919(eventobject, sectionNumber, rowNumber) {
        var self = this;
        debugger;
        this.view.segPlaceDetails.pressedSkin = "segRowFocusSkin";
        this.view.tbxDepartureDetails.text = this.view.segPlaceDetails.data[rowNumber].lblPlaceData;
        this.view.segPlaceDetails.setVisibility(false);
    },
    /** onSelection defined for lsMonth **/
    AS_ListBox_i92349be028b42e79f2c27c4f63d21ad: function AS_ListBox_i92349be028b42e79f2c27c4f63d21ad(eventobject) {
        var self = this;
        var selectedMonth = this.view.lsMonth.selectedKey;
        var year = this.view.lsYear.selectedKeyValue;
        var day = this.view.lsDate.selectedKey;
        var noOfDays = this.getNumberOfDaysinCurrentMonth(selectedMonth, year[1]);
        this.setDefaultDatesData(noOfDays);
        this.view.lsDate.selectedKey = day;
    },
    /** onSelection defined for lsYear **/
    AS_ListBox_c71e476da1de4d9aa4c5648b36dac899: function AS_ListBox_c71e476da1de4d9aa4c5648b36dac899(eventobject) {
        var self = this;
        var selectedMonth = this.view.lsMonth.selectedKey;
        var year = this.view.lsYear.selectedKeyValue;
        var day = this.view.lsDate.selectedKey;
        var noOfDays = this.getNumberOfDaysinCurrentMonth(selectedMonth, year[1]);
        this.setDefaultDatesData(noOfDays);
        this.view.lsDate.selectedKey = day;
    },
    /** onClick defined for btnDone **/
    AS_Button_ice095a5f61f40d4aa2e3d5652c31a45: function AS_Button_ice095a5f61f40d4aa2e3d5652c31a45(eventobject) {
        var self = this;
        return self.onButtonClick.call(this);
    },
    /** postShow defined for placeDetails **/
    AS_FlexContainer_d0a176186293433888c1abb05fd91ae9: function AS_FlexContainer_d0a176186293433888c1abb05fd91ae9(eventobject) {
        var self = this;
        return self.preShow.call(this);
    }
});
define("com/konyqfs/placeDetails/placeDetailsController", ["com/konyqfs/placeDetails/userplaceDetailsController", "com/konyqfs/placeDetails/placeDetailsControllerActions"], function() {
    var controller = require("com/konyqfs/placeDetails/userplaceDetailsController");
    var actions = require("com/konyqfs/placeDetails/placeDetailsControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.lblHeader.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblHeader.text;
        });
        defineSetter(this, "text1", function(val) {
            this.view.lblInnerFieldTitle.text = val;
        });
        defineGetter(this, "text1", function() {
            return this.view.lblInnerFieldTitle.text;
        });
        defineSetter(this, "text2", function(val) {
            this.view.lblInnerFieldTitle2.text = val;
        });
        defineGetter(this, "text2", function() {
            return this.view.lblInnerFieldTitle2.text;
        });
        defineSetter(this, "text3", function(val) {
            this.view.lblInnerFieldTitle3.text = val;
        });
        defineGetter(this, "text3", function() {
            return this.view.lblInnerFieldTitle3.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konyqfs/placeDetails/placeDetails',[],function() {
    return function(controller) {
        var placeDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "placeDetails",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "1dp",
            "isModalContainer": false,
            "postShow": controller.AS_FlexContainer_d0a176186293433888c1abb05fd91ae9,
            "skin": "flxParentSkn",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "placeDetails"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "placeDetails"), extendConfig({}, controller.args[2], "placeDetails"));
        placeDetails.setDefaultUnit(kony.flex.DP);
        var lblHeader = new kony.ui.Label(extendConfig({
            "height": "5%",
            "id": "lblHeader",
            "isVisible": true,
            "left": "4%",
            "skin": "headerSkin",
            "text": "Departure Details",
            "top": "10%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblHeader"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeader"), extendConfig({}, controller.args[2], "lblHeader"));
        var lblInnerFieldTitle = new kony.ui.Label(extendConfig({
            "height": "5%",
            "id": "lblInnerFieldTitle",
            "isVisible": true,
            "left": "4%",
            "skin": "lblInnerFieldHeader",
            "text": "Choose Departure Point",
            "top": "2%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblInnerFieldTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblInnerFieldTitle"), extendConfig({}, controller.args[2], "lblInnerFieldTitle"));
        var flxPlaceDetail = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxPlaceDetail",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "4%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "2%",
            "width": "80%"
        }, controller.args[0], "flxPlaceDetail"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxPlaceDetail"), extendConfig({}, controller.args[2], "flxPlaceDetail"));
        flxPlaceDetail.setDefaultUnit(kony.flex.DP);
        var flxDepartureDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "48px",
            "id": "flxDepartureDetails",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "flxTbxSkn",
            "top": "0dp",
            "width": "84.60%",
            "zIndex": 1
        }, controller.args[0], "flxDepartureDetails"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxDepartureDetails"), extendConfig({}, controller.args[2], "flxDepartureDetails"));
        flxDepartureDetails.setDefaultUnit(kony.flex.DP);
        var tbxDepartureDetails = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "height": "100%",
            "id": "tbxDepartureDetails",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "placeholder": "Enter Place Details",
            "secureTextEntry": false,
            "skin": "tbxDepartureDetails",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "0dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "tbxDepartureDetails"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "tbxDepartureDetails"), extendConfig({
            "autoCorrect": false,
            "onKeyUp": controller.AS_TextField_j43e6d33ef7b4c5b877487ed06750f10,
            "placeholderSkin": "tbxPlaceHolderSkn"
        }, controller.args[2], "tbxDepartureDetails"));
        var flxImg = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24px",
            "id": "flxImg",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "2%",
            "skin": "slFbox",
            "top": "0dp",
            "width": "24px",
            "zIndex": 1
        }, controller.args[0], "flxImg"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxImg"), extendConfig({}, controller.args[2], "flxImg"));
        flxImg.setDefaultUnit(kony.flex.DP);
        var imgDeparture = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgDeparture",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "bluetracker_1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgDeparture"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgDeparture"), extendConfig({}, controller.args[2], "imgDeparture"));
        flxImg.add(imgDeparture);
        flxDepartureDetails.add(tbxDepartureDetails, flxImg);
        var flxSegParent = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxSegParent",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "flxBox",
            "top": "0dp",
            "width": "90%"
        }, controller.args[0], "flxSegParent"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxSegParent"), extendConfig({}, controller.args[2], "flxSegParent"));
        flxSegParent.setDefaultUnit(kony.flex.DP);
        var segPlaceDetails = new kony.ui.SegmentedUI2(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "3dp",
            "data": [{
                "lblPlaceData": "label"
            }],
            "groupCells": false,
            "height": "250px",
            "id": "segPlaceDetails",
            "isVisible": false,
            "left": "0.30%",
            "needPageIndicator": true,
            "onRowClick": controller.AS_Segment_c8ec59a4ad4e4be4875087314fd76919,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "rowFocusSkin": "segRowFocusSkin",
            "rowSkin": "segWidgetSkn",
            "rowTemplate": "flxParent",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
            "separatorColor": "aaaaaa00",
            "separatorRequired": false,
            "separatorThickness": 1,
            "showScrollbars": true,
            "top": 0,
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "flxParent": "flxParent",
                "lblPlaceData": "lblPlaceData"
            },
            "widgetSkin": "segSkin",
            "width": "99.30%",
            "zIndex": 1
        }, controller.args[0], "segPlaceDetails"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segPlaceDetails"), extendConfig({}, controller.args[2], "segPlaceDetails"));
        flxSegParent.add(segPlaceDetails);
        flxPlaceDetail.add(flxDepartureDetails, flxSegParent);
        var lblInnerFieldTitle2 = new kony.ui.Label(extendConfig({
            "id": "lblInnerFieldTitle2",
            "isVisible": true,
            "left": "4%",
            "skin": "lblInnerFieldHeader",
            "text": "Set a Departure Date",
            "top": "5%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblInnerFieldTitle2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblInnerFieldTitle2"), extendConfig({}, controller.args[2], "lblInnerFieldTitle2"));
        var flxDateDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxDateDetails",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "4%",
            "isModalContainer": false,
            "skin": "lsFlxSkn",
            "top": "2%",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxDateDetails"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxDateDetails"), extendConfig({}, controller.args[2], "flxDateDetails"));
        flxDateDetails.setDefaultUnit(kony.flex.DP);
        var lsDate = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsDate",
            "isVisible": true,
            "left": "0%",
            "skin": "lsDaySkn",
            "top": "0%",
            "width": "22.80%",
            "zIndex": 1
        }, controller.args[0], "lsDate"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsDate"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsDate"));
        var lsMonth = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsMonth",
            "isVisible": true,
            "left": "4.50%",
            "onSelection": controller.AS_ListBox_i92349be028b42e79f2c27c4f63d21ad,
            "skin": "lsMonthSkn",
            "top": "0%",
            "width": "35%",
            "zIndex": 1
        }, controller.args[0], "lsMonth"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsMonth"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsMonth"));
        var lsYear = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsYear",
            "isVisible": true,
            "left": "4.50%",
            "onSelection": controller.AS_ListBox_c71e476da1de4d9aa4c5648b36dac899,
            "right": "0%",
            "skin": "lsYearSkn",
            "top": "0%",
            "width": "33%",
            "zIndex": 1
        }, controller.args[0], "lsYear"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsYear"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsYear"));
        flxDateDetails.add(lsDate, lsMonth, lsYear);
        var lblInnerFieldTitle3 = new kony.ui.Label(extendConfig({
            "id": "lblInnerFieldTitle3",
            "isVisible": true,
            "left": "4%",
            "skin": "lblInnerFieldHeader",
            "text": "Set a Departure Time",
            "top": "5%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblInnerFieldTitle3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblInnerFieldTitle3"), extendConfig({}, controller.args[2], "lblInnerFieldTitle3"));
        var flxTimeDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxTimeDetails",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "4%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "2%",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxTimeDetails"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxTimeDetails"), extendConfig({}, controller.args[2], "flxTimeDetails"));
        flxTimeDetails.setDefaultUnit(kony.flex.DP);
        var lsHour = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsHour",
            "isVisible": true,
            "left": "0%",
            "skin": "lsDaySkn",
            "top": "0%",
            "width": "22.80%",
            "zIndex": 1
        }, controller.args[0], "lsHour"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsHour"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsHour"));
        var lsMins = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsMins",
            "isVisible": true,
            "left": "4.50%",
            "skin": "lsMonthSkn",
            "top": "0%",
            "width": "22.80%",
            "zIndex": 1
        }, controller.args[0], "lsMins"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsMins"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsMins"));
        var lsAMPM = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "48px",
            "id": "lsAMPM",
            "isVisible": true,
            "left": "4.50%",
            "right": "0%",
            "skin": "lsYearSkn",
            "top": "0%",
            "width": "30%",
            "zIndex": 1
        }, controller.args[0], "lsAMPM"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lsAMPM"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lsAMPM"));
        flxTimeDetails.add(lsHour, lsMins, lsAMPM);
        var btnDone = new kony.ui.Button(extendConfig({
            "focusSkin": "defBtnFocus",
            "height": "48px",
            "id": "btnDone",
            "isVisible": true,
            "onClick": controller.AS_Button_ice095a5f61f40d4aa2e3d5652c31a45,
            "right": "30px",
            "skin": "btnDoneSkn",
            "text": "Done",
            "top": "2%",
            "width": "132px",
            "zIndex": 1
        }, controller.args[0], "btnDone"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnDone"), extendConfig({}, controller.args[2], "btnDone"));
        placeDetails.add(lblHeader, lblInnerFieldTitle, flxPlaceDetail, lblInnerFieldTitle2, flxDateDetails, lblInnerFieldTitle3, flxTimeDetails, btnDone);
        return placeDetails;
    }
})
;
define('com/konyqfs/placeDetails/placeDetailsConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text3",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "startYear",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "endYear",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setDate", "setTime"],
        "events": ["onDone"]
    }
});

define("com/konysa/animatedtext/useranimatedtextController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._isTextBoxEnabled = false;
            this._inputText = null;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        test: function() {
            this.view.txtBox.secureTextEntry = false;
        },
        onTouchEnd: function() {
            this.view.txtBox.secureTextEntry = true;
        },
        onTxtDone: function() {
            var inputText = this.view.txtBox.text;
            if (typeof inputText == 'string') {
                inputText = inputText.trim();
                if (inputText.length > 0) {
                    this._inputText = inputText;
                } else {
                    this._inputText = null;
                    this.disableTextBox();
                }
            } else {
                this.disableTextBox();
            }
        },
        getText: function() {
            return this._inputText;
        },
        enableTextBox: function() {
            var self = this;
            if (self._isTextBoxEnabled === false) {
                var transformProp1 = kony.ui.makeAffineTransform();
                transformProp1.scale(1, 1);
                var transformProp2 = kony.ui.makeAffineTransform();
                transformProp2.scale(0.5, 0.4);
                var animDefinitionOne = {
                    0: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp1
                    },
                    100: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp2
                    }
                };
                var animDefinition = kony.ui.createAnimation(animDefinitionOne);
                this.view.flxInfo.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self._isTextBoxEnabled = true;
                        self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {}
                });
            }
        },
        disableTextBox: function() {
            var self = this;
            if (self._isTextBoxEnabled === true) {
                self.view.flxInfo.setFocus(true);
                var transformProp1 = kony.ui.makeAffineTransform();
                transformProp1.scale(0.5, 0.4);
                var transformProp2 = kony.ui.makeAffineTransform();
                transformProp2.scale(1, 1);
                var animDefinitionOne = {
                    0: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp1
                    },
                    100: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp2
                    }
                };
                var animDefinition = kony.ui.createAnimation(animDefinitionOne);
                this.view.flxInfo.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self._isTextBoxEnabled = false;
                    },
                    "animationStart": function() {}
                });
            }
        }
    };
});
define("com/konysa/animatedtext/animatedtextControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDone defined for txtBox **/
    AS_TextField_e127d713a4244faf9bfcaed016c4b7b2: function AS_TextField_e127d713a4244faf9bfcaed016c4b7b2(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_bc977893f5cf4012ba952d237f6bc0fd: function AS_TextField_bc977893f5cf4012ba952d237f6bc0fd(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_a1c09fd99c004e8899e9e3c6ade1b38e: function AS_TextField_a1c09fd99c004e8899e9e3c6ade1b38e(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_df9e647ab0d740ecb242cb9f0ab8c681: function AS_TextField_df9e647ab0d740ecb242cb9f0ab8c681(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_ab2a384af7304a22bb7916c93b52edd7: function AS_TextField_ab2a384af7304a22bb7916c93b52edd7(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onClick defined for flxInfo **/
    AS_FlexContainer_bfab609b7f9046e08530ac143dda3ea3: function AS_FlexContainer_bfab609b7f9046e08530ac143dda3ea3(eventobject) {
        var self = this;
        this.enableTextBox();
    }
});
define("com/konysa/animatedtext/animatedtextController", ["com/konysa/animatedtext/useranimatedtextController", "com/konysa/animatedtext/animatedtextControllerActions"], function() {
    var controller = require("com/konysa/animatedtext/useranimatedtextController");
    var actions = require("com/konysa/animatedtext/animatedtextControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "skin2", function(val) {
            this.view.txtBox.skin = val;
        });
        defineGetter(this, "skin2", function() {
            return this.view.txtBox.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/animatedtext/animatedtext',[],function() {
    return function(controller) {
        var animatedtext = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "focusSkin": "sknCMPMaskTextFlxWhiteBG",
            "height": "52dp",
            "id": "animatedtext",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknCMPMaskTextFlxWhiteBG",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "animatedtext"), extendConfig({}, controller.args[1], "animatedtext"), extendConfig({
            "hoverSkin": "sknCMPMaskTextFlxBGTransCursorPointer"
        }, controller.args[2], "animatedtext"));
        animatedtext.setDefaultUnit(kony.flex.DP);
        var txtBox = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "bottom": "2dp",
            "focusSkin": "sknCMPMaskTextTxtBoxFontBlackSize18",
            "id": "txtBox",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "onDone": controller.AS_TextField_e127d713a4244faf9bfcaed016c4b7b2,
            "right": "0dp",
            "secureTextEntry": false,
            "skin": "sknCMPMaskTextTxtBoxFontBlackSize18",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "8dp",
            "zIndex": 1
        }, controller.args[0], "txtBox"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtBox"), extendConfig({
            "autoCorrect": false,
            "onEndEditing": controller.AS_TextField_ab2a384af7304a22bb7916c93b52edd7,
            "placeholderSkin": "defTextBoxPlaceholder"
        }, controller.args[2], "txtBox"));
        var flxInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "42dp",
            "id": "flxInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_bfab609b7f9046e08530ac143dda3ea3,
            "skin": "slFbox",
            "top": "8dp",
            "width": "100%",
            "zIndex": 5
        }, controller.args[0], "flxInfo"), extendConfig({}, controller.args[1], "flxInfo"), extendConfig({
            "hoverSkin": "sknCMPMaskTextFlxBGTransCursorPointer"
        }, controller.args[2], "flxInfo"));
        flxInfo.setDefaultUnit(kony.flex.DP);
        var imgInfo = new kony.ui.Image2(extendConfig({
            "bottom": "5dp",
            "height": "60%",
            "id": "imgInfo",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "user_name.png",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgInfo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgInfo"), extendConfig({}, controller.args[2], "imgInfo"));
        flxInfo.add(imgInfo);
        var lblHline = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblHline",
            "isVisible": true,
            "skin": "sknCMPMaskTextLblBGC6cbd4",
            "textStyle": {},
            "width": "100%",
            "zIndex": 5
        }, controller.args[0], "lblHline"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHline"), extendConfig({}, controller.args[2], "lblHline"));
        animatedtext.add(txtBox, flxInfo, lblHline);
        return animatedtext;
    }
})
;
define('com/konysa/animatedtext/animatedtextConfig',[],function() {
    return {
        "properties": [{
            "name": "skin2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["getText"],
        "events": []
    }
});

define("com/konysa/customAlertWithContactcheckin/usercustomAlertWithContactcheckinController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        onDismissClick: function() {
            //       try
            //         {
            //       if(typeof this.DismissAlert=='function'){
            //         this.DismissAlert();
            //       }
            //         }
            //       catch(err)
            //         {
            //           alert(err.message);
            //         }
        },
        dismissAlert: function() {}
    };
});
define("com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinController", ["com/konysa/customAlertWithContactcheckin/usercustomAlertWithContactcheckinController", "com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinControllerActions"], function() {
    var controller = require("com/konysa/customAlertWithContactcheckin/usercustomAlertWithContactcheckinController");
    var actions = require("com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.lblHeaderText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblHeaderText.text;
        });
        defineSetter(this, "text1", function(val) {
            this.view.lblBody.text = val;
        });
        defineGetter(this, "text1", function() {
            return this.view.lblBody.text;
        });
        defineSetter(this, "text2", function(val) {
            this.view.lblProfileData.text = val;
        });
        defineGetter(this, "text2", function() {
            return this.view.lblProfileData.text;
        });
        defineSetter(this, "text3", function(val) {
            this.view.lblPhnno.text = val;
        });
        defineGetter(this, "text3", function() {
            return this.view.lblPhnno.text;
        });
        defineSetter(this, "text4", function(val) {
            this.view.btnOk.text = val;
        });
        defineGetter(this, "text4", function() {
            return this.view.btnOk.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_dismissAlert_h5638c1fcf8545a38e55def983bd990e = function() {
        if (this.dismissAlert) {
            this.dismissAlert.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckin',[],function() {
    return function(controller) {
        var customAlertWithContactcheckin = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "customAlertWithContactcheckin",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "1dp",
            "isModalContainer": false,
            "skin": "CopyCopyflxBackgroundAlertSkn",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "customAlertWithContactcheckin"), extendConfig({}, controller.args[1], "customAlertWithContactcheckin"), extendConfig({}, controller.args[2], "customAlertWithContactcheckin"));
        customAlertWithContactcheckin.setDefaultUnit(kony.flex.DP);
        var alertFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "45%",
            "id": "alertFlex",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "5%",
            "isModalContainer": false,
            "right": "5%",
            "skin": "CopyCopyalertSkin",
            "top": "25%",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "alertFlex"), extendConfig({}, controller.args[1], "alertFlex"), extendConfig({}, controller.args[2], "alertFlex"));
        alertFlex.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var lblHeaderText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "lblHeaderText",
            "isVisible": true,
            "skin": "CopyCopyCopydefLabel1",
            "text": "Label",
            "textStyle": {},
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblHeaderText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeaderText"), extendConfig({}, controller.args[2], "lblHeaderText"));
        flxHeader.add(lblHeaderText);
        var flexShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "1dp",
            "id": "flexShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyCopyCopyslFbox",
            "top": 1,
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flexShadow"), extendConfig({}, controller.args[1], "flexShadow"), extendConfig({}, controller.args[2], "flexShadow"));
        flexShadow.setDefaultUnit(kony.flex.DP);
        flexShadow.add();
        var flxBody = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxBody"), extendConfig({}, controller.args[1], "flxBody"), extendConfig({}, controller.args[2], "flxBody"));
        flxBody.setDefaultUnit(kony.flex.DP);
        var lblBody = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblBody",
            "isVisible": true,
            "left": "16dp",
            "skin": "CopyCopyCopydefLabel",
            "text": "Label",
            "textStyle": {},
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblBody"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBody"), extendConfig({}, controller.args[2], "lblBody"));
        flxBody.add(lblBody);
        var flxProfile = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxProfile",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "25dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxProfile"), extendConfig({}, controller.args[1], "flxProfile"), extendConfig({}, controller.args[2], "flxProfile"));
        flxProfile.setDefaultUnit(kony.flex.DP);
        var flxProfileInnerFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "25dp",
            "id": "flxProfileInnerFlex",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxProfileInnerFlex"), extendConfig({}, controller.args[1], "flxProfileInnerFlex"), extendConfig({}, controller.args[2], "flxProfileInnerFlex"));
        flxProfileInnerFlex.setDefaultUnit(kony.flex.DP);
        var flxImage = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "20dp",
            "id": "flxImage",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "4dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "flxImage"), extendConfig({}, controller.args[1], "flxImage"), extendConfig({}, controller.args[2], "flxImage"));
        flxImage.setDefaultUnit(kony.flex.DP);
        var imgProfile = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgProfile",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "profile_5_1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgProfile"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgProfile"), extendConfig({}, controller.args[2], "imgProfile"));
        flxImage.add(imgProfile);
        var lblProfileData = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblProfileData",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopyCopyCopydefLabel3",
            "text": "Josh Bowers",
            "textStyle": {},
            "top": "15%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblProfileData"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblProfileData"), extendConfig({}, controller.args[2], "lblProfileData"));
        flxProfileInnerFlex.add(flxImage, lblProfileData);
        flxProfile.add(flxProfileInnerFlex);
        var flxPhone = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxPhone",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "5%",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxPhone"), extendConfig({}, controller.args[1], "flxPhone"), extendConfig({}, controller.args[2], "flxPhone"));
        flxPhone.setDefaultUnit(kony.flex.DP);
        var flxPhnImg = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "30dp",
            "id": "flxPhnImg",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxPhnImg"), extendConfig({}, controller.args[1], "flxPhnImg"), extendConfig({}, controller.args[2], "flxPhnImg"));
        flxPhnImg.setDefaultUnit(kony.flex.DP);
        var CopyflxImage0f7d9c17d787848 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "20dp",
            "id": "CopyflxImage0f7d9c17d787848",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "5dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "CopyflxImage0f7d9c17d787848"), extendConfig({}, controller.args[1], "CopyflxImage0f7d9c17d787848"), extendConfig({}, controller.args[2], "CopyflxImage0f7d9c17d787848"));
        CopyflxImage0f7d9c17d787848.setDefaultUnit(kony.flex.DP);
        var CopyimgProfile0f934adb02c0047 = new kony.ui.Image2(extendConfig({
            "height": "75%",
            "id": "CopyimgProfile0f934adb02c0047",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "phone_5_1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "CopyimgProfile0f934adb02c0047"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyimgProfile0f934adb02c0047"), extendConfig({}, controller.args[2], "CopyimgProfile0f934adb02c0047"));
        CopyflxImage0f7d9c17d787848.add(CopyimgProfile0f934adb02c0047);
        var lblPhnno = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblPhnno",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopyCopyCopydefLabel2",
            "text": "011 870 310499999",
            "textStyle": {},
            "top": "10%",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblPhnno"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPhnno"), extendConfig({}, controller.args[2], "lblPhnno"));
        flxPhnImg.add(CopyflxImage0f7d9c17d787848, lblPhnno);
        flxPhone.add(flxPhnImg);
        var btnOk = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "centerX": "50%",
            "focusSkin": "CopyCopybtnPressed",
            "height": "54dp",
            "id": "btnOk",
            "isVisible": true,
            "onClick": controller.AS_dismissAlert_h5638c1fcf8545a38e55def983bd990e,
            "skin": "CopyCopybtnPressed",
            "text": "OK",
            "top": "5%",
            "width": "90%",
            "zIndex": 10
        }, controller.args[0], "btnOk"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnOk"), extendConfig({}, controller.args[2], "btnOk"));
        alertFlex.add(flxHeader, flexShadow, flxBody, flxProfile, flxPhone, btnOk);
        customAlertWithContactcheckin.add(alertFlex);
        return customAlertWithContactcheckin;
    }
})
;
define('com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text3",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text4",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["dismissAlert"],
        "events": ["dismissAlert"]
    }
});

define("com/konysa/customAlertWithImage/usercustomAlertWithImageController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        dismissSuccessAlert: function() {}
    };
});
define("com/konysa/customAlertWithImage/customAlertWithImageControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchMove defined for img **/
    AS_FlexContainer_bab51d1bd13643a1900cb522eeee2d60: function AS_FlexContainer_bab51d1bd13643a1900cb522eeee2d60(eventobject, x, y) {
        var self = this;
        this.dismissSuccessAlert();
    }
});
define("com/konysa/customAlertWithImage/customAlertWithImageController", ["com/konysa/customAlertWithImage/usercustomAlertWithImageController", "com/konysa/customAlertWithImage/customAlertWithImageControllerActions"], function() {
    var controller = require("com/konysa/customAlertWithImage/usercustomAlertWithImageController");
    var actions = require("com/konysa/customAlertWithImage/customAlertWithImageControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.lblHeaderText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblHeaderText.text;
        });
        defineSetter(this, "text1", function(val) {
            this.view.lblBody.text = val;
        });
        defineGetter(this, "text1", function() {
            return this.view.lblBody.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/customAlertWithImage/customAlertWithImage',[],function() {
    return function(controller) {
        var customAlertWithImage = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "customAlertWithImage",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0%",
            "isModalContainer": false,
            "skin": "CopyflxBackgroundAlertSkn2",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "customAlertWithImage"), extendConfig({}, controller.args[1], "customAlertWithImage"), extendConfig({}, controller.args[2], "customAlertWithImage"));
        customAlertWithImage.setDefaultUnit(kony.flex.DP);
        var alertBody = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "30%",
            "id": "alertBody",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "5%",
            "isModalContainer": false,
            "right": "5%",
            "skin": "CopyalertSkin2",
            "top": "25%",
            "width": "90%",
            "zIndex": 7
        }, controller.args[0], "alertBody"), extendConfig({}, controller.args[1], "alertBody"), extendConfig({}, controller.args[2], "alertBody"));
        alertBody.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "15dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var lblHeaderText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "24dp",
            "id": "lblHeaderText",
            "isVisible": true,
            "left": "16dp",
            "skin": "CopyCopydefLabel0cbf00c5f12f340",
            "text": "Label",
            "textStyle": {},
            "top": "10dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblHeaderText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeaderText"), extendConfig({}, controller.args[2], "lblHeaderText"));
        flxHeader.add(lblHeaderText);
        var flexShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "1dp",
            "id": "flexShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0ic6de9933b9840",
            "top": "20dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flexShadow"), extendConfig({}, controller.args[1], "flexShadow"), extendConfig({}, controller.args[2], "flexShadow"));
        flexShadow.setDefaultUnit(kony.flex.DP);
        flexShadow.add();
        var img = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "42dp",
            "id": "img",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onTouchMove": controller.AS_FlexContainer_bab51d1bd13643a1900cb522eeee2d60,
            "skin": "CopyCopyslFbox0ab95df0e7ec548",
            "top": "30dp",
            "width": "42dp",
            "zIndex": 7
        }, controller.args[0], "img"), extendConfig({}, controller.args[1], "img"), extendConfig({}, controller.args[2], "img"));
        img.setDefaultUnit(kony.flex.DP);
        var Image0dbe9eb423f2c48 = new kony.ui.Image2(extendConfig({
            "height": "24dp",
            "id": "Image0dbe9eb423f2c48",
            "isVisible": true,
            "left": "8dp",
            "skin": "slImage",
            "src": "arrow_1.png",
            "top": "8dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "Image0dbe9eb423f2c48"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0dbe9eb423f2c48"), extendConfig({}, controller.args[2], "Image0dbe9eb423f2c48"));
        img.add(Image0dbe9eb423f2c48);
        var lblBody = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblBody",
            "isVisible": true,
            "skin": "CopyCopydefLabel0h09c093ac2954f",
            "text": "Safe Journey!",
            "textStyle": {},
            "top": "30dp",
            "width": "60%",
            "zIndex": 1
        }, controller.args[0], "lblBody"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBody"), extendConfig({}, controller.args[2], "lblBody"));
        alertBody.add(flxHeader, flexShadow, img, lblBody);
        customAlertWithImage.add(alertBody);
        return customAlertWithImage;
    }
})
;
define('com/konysa/customAlertWithImage/customAlertWithImageConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["dismissSuccessAlert"]
    }
});

define("com/konysa/customAlertWithoutContactCheckin/usercustomAlertWithoutContactCheckinController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        dismissAlert: function() {}
    };
});
define("com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnOk **/
    AS_Button_bdbfc79dbd664f6dae079701b9dc325c: function AS_Button_bdbfc79dbd664f6dae079701b9dc325c(eventobject) {
        var self = this;
        this.dismissAlert();
    }
});
define("com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinController", ["com/konysa/customAlertWithoutContactCheckin/usercustomAlertWithoutContactCheckinController", "com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinControllerActions"], function() {
    var controller = require("com/konysa/customAlertWithoutContactCheckin/usercustomAlertWithoutContactCheckinController");
    var actions = require("com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckin',[],function() {
    return function(controller) {
        var customAlertWithoutContactCheckin = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "customAlertWithoutContactCheckin",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyflxBackgroundAlertSkn3",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "customAlertWithoutContactCheckin"), extendConfig({}, controller.args[1], "customAlertWithoutContactCheckin"), extendConfig({}, controller.args[2], "customAlertWithoutContactCheckin"));
        customAlertWithoutContactCheckin.setDefaultUnit(kony.flex.DP);
        var alertFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "35%",
            "id": "alertFlex",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "5%",
            "isModalContainer": false,
            "right": "5%",
            "skin": "CopyalertSkin3",
            "top": "25%",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "alertFlex"), extendConfig({}, controller.args[1], "alertFlex"), extendConfig({}, controller.args[2], "alertFlex"));
        alertFlex.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var lblHeaderText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "lblHeaderText",
            "isVisible": true,
            "skin": "CopyCopydefLabel0ffc77a04fa5e4c",
            "text": "Label",
            "textStyle": {},
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblHeaderText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeaderText"), extendConfig({}, controller.args[2], "lblHeaderText"));
        flxHeader.add(lblHeaderText);
        var flexShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "1dp",
            "id": "flexShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyCopyslFbox0cba12afa513f4c",
            "top": 1,
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flexShadow"), extendConfig({}, controller.args[1], "flexShadow"), extendConfig({}, controller.args[2], "flexShadow"));
        flexShadow.setDefaultUnit(kony.flex.DP);
        flexShadow.add();
        var flxBody = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxBody"), extendConfig({}, controller.args[1], "flxBody"), extendConfig({}, controller.args[2], "flxBody"));
        flxBody.setDefaultUnit(kony.flex.DP);
        var lblBody = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblBody",
            "isVisible": true,
            "left": "16dp",
            "skin": "CopyCopydefLabel0ac7da6dc76a642",
            "text": "Label",
            "textStyle": {},
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "lblBody"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBody"), extendConfig({}, controller.args[2], "lblBody"));
        flxBody.add(lblBody);
        var btnOk = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "centerX": "50%",
            "focusSkin": "CopybtnPressed4",
            "height": "54dp",
            "id": "btnOk",
            "isVisible": true,
            "skin": "CopybtnPressed4",
            "text": "OK",
            "top": "20%",
            "width": "90%",
            "zIndex": 10
        }, controller.args[0], "btnOk"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnOk"), extendConfig({}, controller.args[2], "btnOk"));
        alertFlex.add(flxHeader, flexShadow, flxBody, btnOk);
        customAlertWithoutContactCheckin.add(alertFlex);
        return customAlertWithoutContactCheckin;
    }
})
;
define('com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": ["dismissAlert"]
    }
});

define("com/konysa/emergencydetails/useremergencydetailsController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        setEmergencyDetails: function(dataObject) {
            kony.print("set Emergency Details " + dataObject["incident_type"]);
            this.view.lblEmergengyTypeVal.text = dataObject["incident_type"]; //journeydetailsObject
            // this.view.lblAsstRequiredVal.text=incidentDetails[""];
        }
    };
});
define("com/konysa/emergencydetails/emergencydetailsControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konysa/emergencydetails/emergencydetailsController", ["com/konysa/emergencydetails/useremergencydetailsController", "com/konysa/emergencydetails/emergencydetailsControllerActions"], function() {
    var controller = require("com/konysa/emergencydetails/useremergencydetailsController");
    var actions = require("com/konysa/emergencydetails/emergencydetailsControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_OnClickOfflxEmergencyAction_f2389263e0104acb843fa2c13dabfd82 = function() {
        if (this.OnClickOfflxEmergencyAction) {
            this.OnClickOfflxEmergencyAction.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/emergencydetails/emergencydetails',[],function() {
    return function(controller) {
        var emergencydetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "emergencydetails",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "emergencydetails"), extendConfig({}, controller.args[1], "emergencydetails"), extendConfig({}, controller.args[2], "emergencydetails"));
        emergencydetails.setDefaultUnit(kony.flex.DP);
        var flxEmergencyDetailRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxEmergencyDetailRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxEmergencyDetailRoot"), extendConfig({}, controller.args[1], "flxEmergencyDetailRoot"), extendConfig({}, controller.args[2], "flxEmergencyDetailRoot"));
        flxEmergencyDetailRoot.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label(extendConfig({
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont3d3d3dSize100TypeBold",
            "text": "Emergency Details",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblEmergencyTypeTitle = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblEmergencyTypeTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Nature of Emergency",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblEmergencyTypeTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblEmergencyTypeTitle"), extendConfig({}, controller.args[2], "lblEmergencyTypeTitle"));
        var lblEmergengyTypeVal = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblEmergengyTypeVal",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100TypeMedium",
            "text": "N/A",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblEmergengyTypeVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblEmergengyTypeVal"), extendConfig({}, controller.args[2], "lblEmergengyTypeVal"));
        var lblDescriptionTitle = new kony.ui.Label(extendConfig({
            "id": "lblDescriptionTitle",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Emergency Description",
            "top": "9dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDescriptionTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDescriptionTitle"), extendConfig({}, controller.args[2], "lblDescriptionTitle"));
        var lblDesciptionVal = new kony.ui.Label(extendConfig({
            "id": "lblDesciptionVal",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100TypeMedium",
            "text": "After a long 4 hour ride, I stopped at the  Willare gas station and I found out that the tire is flat.",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDesciptionVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDesciptionVal"), extendConfig({}, controller.args[2], "lblDesciptionVal"));
        var lblAssistanceRequiredTitle = new kony.ui.Label(extendConfig({
            "id": "lblAssistanceRequiredTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Assistance Required Details",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblAssistanceRequiredTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblAssistanceRequiredTitle"), extendConfig({}, controller.args[2], "lblAssistanceRequiredTitle"));
        var lblAsstRequiredVal = new kony.ui.Label(extendConfig({
            "id": "lblAsstRequiredVal",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100TypeMedium",
            "text": "N/A",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblAsstRequiredVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblAsstRequiredVal"), extendConfig({}, controller.args[2], "lblAsstRequiredVal"));
        var flxEmergencyAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxEmergencyAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_OnClickOfflxEmergencyAction_f2389263e0104acb843fa2c13dabfd82,
            "skin": "sknFlxBG596822",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxEmergencyAction"), extendConfig({}, controller.args[1], "flxEmergencyAction"), extendConfig({}, controller.args[2], "flxEmergencyAction"));
        flxEmergencyAction.setDefaultUnit(kony.flex.DP);
        var lblActionTextVal = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "id": "lblActionTextVal",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhiteTypeRegular",
            "text": "Contact Supervisor",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblActionTextVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblActionTextVal"), extendConfig({}, controller.args[2], "lblActionTextVal"));
        flxEmergencyAction.add(lblActionTextVal);
        flxEmergencyDetailRoot.add(lblTitle, lblEmergencyTypeTitle, lblEmergengyTypeVal, lblDescriptionTitle, lblDesciptionVal, lblAssistanceRequiredTitle, lblAsstRequiredVal, flxEmergencyAction);
        emergencydetails.add(flxEmergencyDetailRoot);
        return emergencydetails;
    }
})
;
define('com/konysa/emergencydetails/emergencydetailsConfig',[],function() {
    return {
        "properties": [],
        "apis": ["setEmergencyDetails"],
        "events": ["OnClickOfflxEmergencyAction"]
    }
});

define("com/konysa/escalationpolicy/userescalationpolicyController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._hidePolicy = false;
            this._isYesSelected = false;
            this._isNoSelected = false;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        togglePolicyVisibility: function() {
            if (this._hidePolicy === true) {
                this.view.imgPolicyToggle.src = "chechbox_unselected.png";
                this._hidePolicy = false;
            } else if (this._hidePolicy === false) {
                this._hidePolicy = true;
                this.view.imgPolicyToggle.src = "checkbox_selected.png";
            }
        },
        onOptionYesSelection: function() {
            this.view.flxContactDriverAction.setVisibility(false);
            this.disableNoOption();
            this.enableYesOption();
        },
        onOptionNoSelection: function() {
            this.view.flxContactDriverAction.setVisibility(false);
            this.disableYesOption();
            this.enableNoOption();
        },
        enableYesOption: function() {
            this._isYesSelected = true;
            this.view.imgRadioYes.src = "radio_selected.png";
            this.view.flxOnYesSelection.setVisibility(true);
        },
        disableYesOption: function() {
            this._isYesSelected = false;
            this.view.imgRadioYes.src = "radio_unselected.png";
            this.view.flxOnYesSelection.setVisibility(false);
        },
        enableNoOption: function() {
            this._isNoSelected = true;
            this.view.imgRadioNo.src = "radio_selected.png";
            this.view.flxNoSelection.setVisibility(true);
        },
        disableNoOption: function() {
            this._isNoSelected = false;
            this.view.imgRadioNo.src = "radio_unselected.png";
            this.view.flxNoSelection.setVisibility(false);
        },
        cancelFromPolicy: function() {},
        continueFromPolicy: function() {
            try {
                this.view.flxContactDriverRoot.setVisibility(true);
                this.view.flxSCRootContainer.setVisibility(false);
            } catch (excp) {
                debugger;
            }
        },
        onPreshow: function() {
            this.disableYesOption();
            this.disableNoOption();
        },
        setDataToHeaderWidgets: function(title, subTitle, reportSubTitle, btnText) {
            this.view.lblContactDriverTitle.text = "Contact " + title;
            this.view.lblContactDriverSubTitle.text = subTitle;
            this.view.rchTextReportSubTitle.text = reportSubTitle;
            this.view.lblNoContinueText.text = btnText;
            this.view.lblRadioMsg.text = "Did you contact the " + title + "?";
        },
        getEscalationDesc: function() {
            return this.view.txtAreaYes.text;
        },
        launchPolicy: function() {
            try {
                this.view.flxContactDriverRoot.setVisibility(false);
                this.view.flxSCRootContainer.setVisibility(true);
            } catch (excp) {
                debugger;
            }
        },
        setDataToSegNotePoints: function(data) {
            this.view.segNotePoints.setData(data);
        }
    };
});
define("com/konysa/escalationpolicy/escalationpolicyControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxCheckUncheck **/
    AS_FlexContainer_iff1b279dbd041e98ff7c2668b9caced: function AS_FlexContainer_iff1b279dbd041e98ff7c2668b9caced(eventobject) {
        var self = this;
        this.togglePolicyVisibility();
    },
    /** onClick defined for flxContinue **/
    AS_FlexContainer_fdc72c3e30df43de8db5770bdf9b0070: function AS_FlexContainer_fdc72c3e30df43de8db5770bdf9b0070(eventobject) {
        var self = this;
        this.continueFromPolicy();
    },
    /** onClick defined for flxRadioYes **/
    AS_FlexContainer_i2f053ca8ef14fc69b91536efe2c12f5: function AS_FlexContainer_i2f053ca8ef14fc69b91536efe2c12f5(eventobject) {
        var self = this;
        this.onOptionYesSelection();
    },
    /** onClick defined for flxRadioNo **/
    AS_FlexContainer_aec3ba25e9a84c3ab094a185deea46ba: function AS_FlexContainer_aec3ba25e9a84c3ab094a185deea46ba(eventobject) {
        var self = this;
        this.onOptionNoSelection();
    },
    /** preShow defined for escalationpolicy **/
    AS_FlexContainer_f231fdf87e6c488f8681ad4b578fb838: function AS_FlexContainer_f231fdf87e6c488f8681ad4b578fb838(eventobject) {
        var self = this;
        this.onPreshow();
    }
});
define("com/konysa/escalationpolicy/escalationpolicyController", ["com/konysa/escalationpolicy/userescalationpolicyController", "com/konysa/escalationpolicy/escalationpolicyControllerActions"], function() {
    var controller = require("com/konysa/escalationpolicy/userescalationpolicyController");
    var actions = require("com/konysa/escalationpolicy/escalationpolicyControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickOfFlxCancel_daa087465cd14037aca11c80239226fb = function() {
        if (this.onClickOfFlxCancel) {
            this.onClickOfFlxCancel.apply(this, arguments);
        }
    }
    controller.AS_onClickOfYesCancelAction_e26eded5274a4876bb579ca0d66049a6 = function() {
        if (this.onClickOfYesCancelAction) {
            this.onClickOfYesCancelAction.apply(this, arguments);
        }
    }
    controller.AS_onClickofYesContinueAction_da7edcdcc7f44d58a3dc895fe528df18 = function() {
        if (this.onClickofYesContinueAction) {
            this.onClickofYesContinueAction.apply(this, arguments);
        }
    }
    controller.AS_onClickOfNoCancelAction_c5cec6f14b0848159e810f5d5193a3b5 = function() {
        if (this.onClickOfNoCancelAction) {
            this.onClickOfNoCancelAction.apply(this, arguments);
        }
    }
    controller.AS_onClickOfNoContinueAction_c61cf5a38aab4b74bfef7615a68ed93b = function() {
        if (this.onClickOfNoContinueAction) {
            this.onClickOfNoContinueAction.apply(this, arguments);
        }
    }
    controller.AS_onClickOfContactDriverCancel_adbbf621e89d490cb5052105700bba09 = function() {
        if (this.onClickOfContactDriverCancel) {
            this.onClickOfContactDriverCancel.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/escalationpolicy/escalationpolicy',[],function() {
    return function(controller) {
        var escalationpolicy = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "escalationpolicy",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_f231fdf87e6c488f8681ad4b578fb838(eventobject);
            },
            "skin": "sknFlxBGBlackOpacity20",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "escalationpolicy"), extendConfig({}, controller.args[1], "escalationpolicy"), extendConfig({}, controller.args[2], "escalationpolicy"));
        escalationpolicy.setDefaultUnit(kony.flex.DP);
        var flxRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "id": "flxRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBordere8e8e8Radius3",
            "width": "500dp",
            "zIndex": 1
        }, controller.args[0], "flxRoot"), extendConfig({}, controller.args[1], "flxRoot"), extendConfig({}, controller.args[2], "flxRoot"));
        flxRoot.setDefaultUnit(kony.flex.DP);
        var flxSCRootContainer = new kony.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bounces": true,
            "clipBounds": true,
            "enableScrolling": true,
            "height": "620dp",
            "horizontalScrollIndicator": true,
            "id": "flxSCRootContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "maxHeight": "620dp",
            "pagingEnabled": false,
            "right": "-16dp",
            "scrollDirection": kony.flex.SCROLL_VERTICAL,
            "skin": "slFSbox",
            "top": "0dp",
            "verticalScrollIndicator": true,
            "zIndex": 1
        }, controller.args[0], "flxSCRootContainer"), extendConfig({}, controller.args[1], "flxSCRootContainer"), extendConfig({}, controller.args[2], "flxSCRootContainer"));
        flxSCRootContainer.setDefaultUnit(kony.flex.DP);
        var flxInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxInfo",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "50dp",
            "isModalContainer": false,
            "right": "50dp",
            "skin": "slFbox",
            "top": "50dp",
            "zIndex": 1
        }, controller.args[0], "flxInfo"), extendConfig({}, controller.args[1], "flxInfo"), extendConfig({}, controller.args[2], "flxInfo"));
        flxInfo.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label(extendConfig({
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize125TypeSemiBold",
            "text": "Escalation report policy: ",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblSubTitle = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblSubTitle",
            "isVisible": true,
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "We have a specia procedure when a journey exceeds the Estimated Time of Arrival (ETA). There are three steps to follow during this procedure: ",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSubTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSubTitle"), extendConfig({}, controller.args[2], "lblSubTitle"));
        var flxSegContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxSegContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "22dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxSegContainer"), extendConfig({}, controller.args[1], "flxSegContainer"), extendConfig({}, controller.args[2], "flxSegContainer"));
        flxSegContainer.setDefaultUnit(kony.flex.DP);
        var segNotePoints = new kony.ui.SegmentedUI2(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "data": [{
                "lblDUmmey": "",
                "lblTitle": "",
                "lblWhiteShado": "",
                "rchTxtDesc": ""
            }],
            "groupCells": false,
            "id": "segNotePoints",
            "isVisible": true,
            "left": "0dp",
            "maxHeight": "300dp",
            "needPageIndicator": true,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "right": "-17dp",
            "rowFocusSkin": "seg2Focus",
            "rowSkin": "seg2Normal",
            "rowTemplate": "flxEscalationRoot",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
            "separatorColor": "aaaaaa00",
            "separatorRequired": true,
            "separatorThickness": 0,
            "showScrollbars": false,
            "top": "0dp",
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "flxBoxContainer": "flxBoxContainer",
                "flxDasshedLine": "flxDasshedLine",
                "flxEscalationRoot": "flxEscalationRoot",
                "flxLine": "flxLine",
                "flxNoteRoot": "flxNoteRoot",
                "lblDUmmey": "lblDUmmey",
                "lblTitle": "lblTitle",
                "lblWhiteShado": "lblWhiteShado",
                "rchTxtDesc": "rchTxtDesc"
            },
            "zIndex": 1
        }, controller.args[0], "segNotePoints"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segNotePoints"), extendConfig({}, controller.args[2], "segNotePoints"));
        flxSegContainer.add(segNotePoints);
        var flxOption = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxOption",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxOption"), extendConfig({}, controller.args[1], "flxOption"), extendConfig({}, controller.args[2], "flxOption"));
        flxOption.setDefaultUnit(kony.flex.DP);
        var flxCheckUncheck = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxCheckUncheck",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_iff1b279dbd041e98ff7c2668b9caced,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "4dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "flxCheckUncheck"), extendConfig({}, controller.args[1], "flxCheckUncheck"), extendConfig({}, controller.args[2], "flxCheckUncheck"));
        flxCheckUncheck.setDefaultUnit(kony.flex.DP);
        var imgPolicyToggle = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgPolicyToggle",
            "imageWhenFailed": "checkbox_selected.png",
            "isVisible": true,
            "skin": "slImage",
            "src": "chechbox_unselected.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgPolicyToggle"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgPolicyToggle"), extendConfig({}, controller.args[2], "imgPolicyToggle"));
        flxCheckUncheck.add(imgPolicyToggle);
        var lblOptionText = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblOptionText",
            "isVisible": true,
            "left": "34dp",
            "skin": "sknLblBGTransFont575ee7Size88",
            "text": "Do not show this again",
            "top": "11dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblOptionText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOptionText"), extendConfig({}, controller.args[2], "lblOptionText"));
        flxOption.add(flxCheckUncheck, lblOptionText);
        var flxAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "94dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxAction"), extendConfig({}, controller.args[1], "flxAction"), extendConfig({}, controller.args[2], "flxAction"));
        flxAction.setDefaultUnit(kony.flex.DP);
        var flxCancel = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxCancel",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfFlxCancel_daa087465cd14037aca11c80239226fb,
            "right": "173dp",
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxCancel"), extendConfig({}, controller.args[1], "flxCancel"), extendConfig({}, controller.args[2], "flxCancel"));
        flxCancel.setDefaultUnit(kony.flex.DP);
        var lblCancel = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblCancel",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Cancel",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblCancel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCancel"), extendConfig({}, controller.args[2], "lblCancel"));
        flxCancel.add(lblCancel);
        var flxContinue = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxContinue",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_fdc72c3e30df43de8db5770bdf9b0070,
            "right": "0dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxContinue"), extendConfig({}, controller.args[1], "flxContinue"), extendConfig({}, controller.args[2], "flxContinue"));
        flxContinue.setDefaultUnit(kony.flex.DP);
        var lblContinue = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblContinue",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhite",
            "text": "Continue",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblContinue"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContinue"), extendConfig({}, controller.args[2], "lblContinue"));
        flxContinue.add(lblContinue);
        flxAction.add(flxCancel, flxContinue);
        flxInfo.add(lblTitle, lblSubTitle, flxSegContainer, flxOption, flxAction);
        flxSCRootContainer.add(flxInfo);
        var flxContactDriverRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContactDriverRoot",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "50dp",
            "isModalContainer": false,
            "right": "50dp",
            "skin": "slFbox",
            "top": "50dp",
            "zIndex": 1
        }, controller.args[0], "flxContactDriverRoot"), extendConfig({}, controller.args[1], "flxContactDriverRoot"), extendConfig({}, controller.args[2], "flxContactDriverRoot"));
        flxContactDriverRoot.setDefaultUnit(kony.flex.DP);
        var lblContactDriverTitle = new kony.ui.Label(extendConfig({
            "id": "lblContactDriverTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize125TypeSemiBold",
            "text": "Contact Driver",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblContactDriverTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContactDriverTitle"), extendConfig({}, controller.args[2], "lblContactDriverTitle"));
        var lblContactDriverSubTitle = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblContactDriverSubTitle",
            "isVisible": false,
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Step 1 of Escalation reported policy. Contact the driver and provide status. If you are not able to acquire contact you will proceed to Step 2 contact the Supervisor.",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblContactDriverSubTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContactDriverSubTitle"), extendConfig({}, controller.args[2], "lblContactDriverSubTitle"));
        var rchTextReportSubTitle = new kony.ui.RichText(extendConfig({
            "id": "rchTextReportSubTitle",
            "isVisible": true,
            "left": "0dp",
            "linkSkin": "defRichTextLink",
            "skin": "sknRchTextBGTransFont30353fSize100",
            "text": "Step 1 of Escalation reported policy. Contact the driver and provide status. If you are not able to acquire contact you will proceed to Step 2<b> contact the Supervisor.</b>",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "rchTextReportSubTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "rchTextReportSubTitle"), extendConfig({}, controller.args[2], "rchTextReportSubTitle"));
        var flxContactDriverRadio = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContactDriverRadio",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxContactDriverRadio"), extendConfig({}, controller.args[1], "flxContactDriverRadio"), extendConfig({}, controller.args[2], "flxContactDriverRadio"));
        flxContactDriverRadio.setDefaultUnit(kony.flex.DP);
        var lblRadioMsg = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblRadioMsg",
            "isVisible": true,
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Did you contact the driver?",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblRadioMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRadioMsg"), extendConfig({}, controller.args[2], "lblRadioMsg"));
        var flxRadioOption = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxRadioOption",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxRadioOption"), extendConfig({}, controller.args[1], "flxRadioOption"), extendConfig({}, controller.args[2], "flxRadioOption"));
        flxRadioOption.setDefaultUnit(kony.flex.DP);
        var flxRadioYes = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxRadioYes",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_i2f053ca8ef14fc69b91536efe2c12f5,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "4dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "flxRadioYes"), extendConfig({}, controller.args[1], "flxRadioYes"), extendConfig({}, controller.args[2], "flxRadioYes"));
        flxRadioYes.setDefaultUnit(kony.flex.DP);
        var imgRadioYes = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgRadioYes",
            "imageWhenFailed": "checkbox_selected.png",
            "isVisible": true,
            "skin": "slImage",
            "src": "radio_unselected.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgRadioYes"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgRadioYes"), extendConfig({}, controller.args[2], "imgRadioYes"));
        flxRadioYes.add(imgRadioYes);
        var flxRadioNo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxRadioNo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "227dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_aec3ba25e9a84c3ab094a185deea46ba,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "4dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "flxRadioNo"), extendConfig({}, controller.args[1], "flxRadioNo"), extendConfig({}, controller.args[2], "flxRadioNo"));
        flxRadioNo.setDefaultUnit(kony.flex.DP);
        var imgRadioNo = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgRadioNo",
            "imageWhenFailed": "checkbox_selected.png",
            "isVisible": true,
            "skin": "slImage",
            "src": "radio_unselected.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgRadioNo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgRadioNo"), extendConfig({}, controller.args[2], "imgRadioNo"));
        flxRadioNo.add(imgRadioNo);
        var lblYes = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblYes",
            "isVisible": true,
            "left": "34dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Yes",
            "top": "11dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblYes"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblYes"), extendConfig({}, controller.args[2], "lblYes"));
        var lblNo = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblNo",
            "isVisible": true,
            "left": "261dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "No",
            "top": "11dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblNo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNo"), extendConfig({}, controller.args[2], "lblNo"));
        flxRadioOption.add(flxRadioYes, flxRadioNo, lblYes, lblNo);
        var lblDivider2 = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider2",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider2"), extendConfig({}, controller.args[2], "lblDivider2"));
        var flxOnYesSelection = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxOnYesSelection",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "22dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxOnYesSelection"), extendConfig({}, controller.args[1], "flxOnYesSelection"), extendConfig({}, controller.args[2], "flxOnYesSelection"));
        flxOnYesSelection.setDefaultUnit(kony.flex.DP);
        var lblYesOptionTitle = new kony.ui.Label(extendConfig({
            "id": "lblYesOptionTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Explanation",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblYesOptionTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblYesOptionTitle"), extendConfig({}, controller.args[2], "lblYesOptionTitle"));
        var txtAreaYes = new kony.ui.TextArea2(extendConfig({
            "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
            "focusSkin": "sknTextAreaNormalBGWhiteFont575ee7Size100",
            "height": "95dp",
            "id": "txtAreaYes",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "numberOfVisibleLines": 3,
            "placeholder": "You can provide additional information, to support the case.",
            "skin": "sknTextAreaNormalBGWhiteFont575ee7Size100",
            "text": "You can provide additional information, to support the case.",
            "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "txtAreaYes"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [2, 2, 2, 2],
            "paddingInPixel": false
        }, controller.args[1], "txtAreaYes"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTextAreaPlaceholder0cdb35793efc940"
        }, controller.args[2], "txtAreaYes"));
        var flxYesAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "94dp",
            "id": "flxYesAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxYesAction"), extendConfig({}, controller.args[1], "flxYesAction"), extendConfig({}, controller.args[2], "flxYesAction"));
        flxYesAction.setDefaultUnit(kony.flex.DP);
        var flxYesCancelAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxYesCancelAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfYesCancelAction_e26eded5274a4876bb579ca0d66049a6,
            "right": "173dp",
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxYesCancelAction"), extendConfig({}, controller.args[1], "flxYesCancelAction"), extendConfig({}, controller.args[2], "flxYesCancelAction"));
        flxYesCancelAction.setDefaultUnit(kony.flex.DP);
        var lblYesCancelText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblYesCancelText",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Cancel",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblYesCancelText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblYesCancelText"), extendConfig({}, controller.args[2], "lblYesCancelText"));
        flxYesCancelAction.add(lblYesCancelText);
        var flxYesContinueAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxYesContinueAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickofYesContinueAction_da7edcdcc7f44d58a3dc895fe528df18,
            "right": "0dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxYesContinueAction"), extendConfig({}, controller.args[1], "flxYesContinueAction"), extendConfig({}, controller.args[2], "flxYesContinueAction"));
        flxYesContinueAction.setDefaultUnit(kony.flex.DP);
        var lblYesActionContinueText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblYesActionContinueText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhiteTypeRegular",
            "text": "Close Escalation",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblYesActionContinueText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblYesActionContinueText"), extendConfig({}, controller.args[2], "lblYesActionContinueText"));
        flxYesContinueAction.add(lblYesActionContinueText);
        flxYesAction.add(flxYesCancelAction, flxYesContinueAction);
        flxOnYesSelection.add(lblYesOptionTitle, txtAreaYes, flxYesAction);
        var flxNoSelection = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxNoSelection",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxNoSelection"), extendConfig({}, controller.args[1], "flxNoSelection"), extendConfig({}, controller.args[2], "flxNoSelection"));
        flxNoSelection.setDefaultUnit(kony.flex.DP);
        var lstBoxOnNoSelected = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "40dp",
            "id": "lstBoxOnNoSelected",
            "isVisible": false,
            "left": "0dp",
            "masterData": [
                ["lb1", "Select Status"],
                ["lb2", "Placeholder Two"],
                ["lb3", "Placeholder Three"]
            ],
            "skin": "sknListBoxBGTransFont30353fBorderc9c9c9",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lstBoxOnNoSelected"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [2, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lstBoxOnNoSelected"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lstBoxOnNoSelected"));
        var blNoOptionTitle = new kony.ui.Label(extendConfig({
            "id": "blNoOptionTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Explanation",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "blNoOptionTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "blNoOptionTitle"), extendConfig({}, controller.args[2], "blNoOptionTitle"));
        var txtAreaNo = new kony.ui.TextArea2(extendConfig({
            "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
            "focusSkin": "sknTextAreaNormalBGWhiteFont575ee7Size100",
            "height": "95dp",
            "id": "txtAreaNo",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "numberOfVisibleLines": 3,
            "placeholder": "You can provide additional information, to support the case.",
            "skin": "sknTextAreaNormalBGWhiteFont575ee7Size100",
            "text": "You can provide additional information, to support the case.",
            "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "txtAreaNo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [2, 2, 2, 2],
            "paddingInPixel": false
        }, controller.args[1], "txtAreaNo"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTextAreaPlaceholder0cdb35793efc940"
        }, controller.args[2], "txtAreaNo"));
        var flxNoAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "94dp",
            "id": "flxNoAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxNoAction"), extendConfig({}, controller.args[1], "flxNoAction"), extendConfig({}, controller.args[2], "flxNoAction"));
        flxNoAction.setDefaultUnit(kony.flex.DP);
        var flxNoCancelAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxNoCancelAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfNoCancelAction_c5cec6f14b0848159e810f5d5193a3b5,
            "right": "173dp",
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxNoCancelAction"), extendConfig({}, controller.args[1], "flxNoCancelAction"), extendConfig({}, controller.args[2], "flxNoCancelAction"));
        flxNoCancelAction.setDefaultUnit(kony.flex.DP);
        var lblNoCancelText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblNoCancelText",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Cancel",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblNoCancelText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNoCancelText"), extendConfig({}, controller.args[2], "lblNoCancelText"));
        flxNoCancelAction.add(lblNoCancelText);
        var flxNoContinueAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxNoContinueAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfNoContinueAction_c61cf5a38aab4b74bfef7615a68ed93b,
            "right": "0dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxNoContinueAction"), extendConfig({}, controller.args[1], "flxNoContinueAction"), extendConfig({}, controller.args[2], "flxNoContinueAction"));
        flxNoContinueAction.setDefaultUnit(kony.flex.DP);
        var lblNoContinueText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblNoContinueText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhiteTypeRegular",
            "text": "Next",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblNoContinueText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNoContinueText"), extendConfig({}, controller.args[2], "lblNoContinueText"));
        flxNoContinueAction.add(lblNoContinueText);
        flxNoAction.add(flxNoCancelAction, flxNoContinueAction);
        flxNoSelection.add(lstBoxOnNoSelected, blNoOptionTitle, txtAreaNo, flxNoAction);
        flxContactDriverRadio.add(lblRadioMsg, flxRadioOption, lblDivider2, flxOnYesSelection, flxNoSelection);
        var flxContactDriverAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "94dp",
            "id": "flxContactDriverAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxContactDriverAction"), extendConfig({}, controller.args[1], "flxContactDriverAction"), extendConfig({}, controller.args[2], "flxContactDriverAction"));
        flxContactDriverAction.setDefaultUnit(kony.flex.DP);
        var flxContactDriverCancel = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxContactDriverCancel",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfContactDriverCancel_adbbf621e89d490cb5052105700bba09,
            "right": "173dp",
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxContactDriverCancel"), extendConfig({}, controller.args[1], "flxContactDriverCancel"), extendConfig({}, controller.args[2], "flxContactDriverCancel"));
        flxContactDriverCancel.setDefaultUnit(kony.flex.DP);
        var CopylblCancel0c9c035beda9d4a = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "CopylblCancel0c9c035beda9d4a",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Cancel",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "CopylblCancel0c9c035beda9d4a"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopylblCancel0c9c035beda9d4a"), extendConfig({}, controller.args[2], "CopylblCancel0c9c035beda9d4a"));
        flxContactDriverCancel.add(CopylblCancel0c9c035beda9d4a);
        var flxContactDriverContinue = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxContactDriverContinue",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknFlxBGf5f5f5",
            "top": "0dp",
            "width": "162dp",
            "zIndex": 1
        }, controller.args[0], "flxContactDriverContinue"), extendConfig({}, controller.args[1], "flxContactDriverContinue"), extendConfig({}, controller.args[2], "flxContactDriverContinue"));
        flxContactDriverContinue.setDefaultUnit(kony.flex.DP);
        var lblContactDriverContinue = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblContactDriverContinue",
            "isVisible": true,
            "skin": "sknLblBGTransFontc9c9c9",
            "text": "Continue",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblContactDriverContinue"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContactDriverContinue"), extendConfig({}, controller.args[2], "lblContactDriverContinue"));
        flxContactDriverContinue.add(lblContactDriverContinue);
        flxContactDriverAction.add(flxContactDriverCancel, flxContactDriverContinue);
        flxContactDriverRoot.add(lblContactDriverTitle, lblContactDriverSubTitle, rchTextReportSubTitle, flxContactDriverRadio, flxContactDriverAction);
        flxRoot.add(flxSCRootContainer, flxContactDriverRoot);
        escalationpolicy.add(flxRoot);
        return escalationpolicy;
    }
})
;
define('com/konysa/escalationpolicy/escalationpolicyConfig',[],function() {
    return {
        "properties": [],
        "apis": ["setDataToHeaderWidgets", "getEscalationDesc", "launchPolicy", "setDataToSegNotePoints"],
        "events": ["onClickOfNoContinueAction", "onClickofYesContinueAction", "onClickOfYesCancelAction", "onClickOfNoCancelAction", "onClickOfFlxCancel", "onClickOfContactDriverCancel"]
    }
});

define("com/konysa/ETAReporting/userETAReportingController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        initGettersSetters: function() {},
        dismissAlert: function() {},
        componentPreShow: function() {
            /*var MasterDataForListBox = [];
            var ResponseFromCheckInInterval = (GetResponseFromDatabaseWhereClause(CHECKIN_INTERVAL_MASTER_TBL_GLOBAL, null, null));
            if(ResponseFromCheckInInterval !== null && ResponseFromCheckInInterval!==undefined && ResponseFromCheckInInterval.length>0)
            {
              ResponseFromCheckInInterval.forEach(function(item){
                MasterDataForListBox.push({"mykey":parseInt(item.checkin_interval_row_id_pk),"myvalue":parseInt(item.checkin_interval_minutes),"accessibilityConfig":{}});
              });
              this.view.lstTimeCheckins.masterDataMap = [MasterDataForListBox,"mykey","myvalue"];
            }
            else
            {
              alert("No Data");
            }*/
        },
        getListBoxSelectedValue: function() {
            //var selectedKeyValue=1;
            var selectedKeyValue = this.view.lstTimeCheckins.selectedKeyValue;
            kony.print("selectedKeyValue ::" + selectedKeyValue[1]);
            return selectedKeyValue[1];
        }
    };
});
define("com/konysa/ETAReporting/ETAReportingControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for ETAReporting **/
    AS_FlexContainer_de4a2e36db7344149118d27fa588de8d: function AS_FlexContainer_de4a2e36db7344149118d27fa588de8d(eventobject) {
        var self = this;
        debugger;
        try {
            this.componentPreShow();
        } catch (err) {
            alert(err.message);
        }
    }
});
define("com/konysa/ETAReporting/ETAReportingController", ["com/konysa/ETAReporting/userETAReportingController", "com/konysa/ETAReporting/ETAReportingControllerActions"], function() {
    var controller = require("com/konysa/ETAReporting/userETAReportingController");
    var actions = require("com/konysa/ETAReporting/ETAReportingControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "ListBoxMasterData", function(val) {
            this.view.lstTimeCheckins.masterData = val;
        });
        defineGetter(this, "ListBoxMasterData", function() {
            return this.view.lstTimeCheckins.masterData;
        });
        defineSetter(this, "selectedKey", function(val) {
            this.view.lstTimeCheckins.selectedKey = val;
        });
        defineGetter(this, "selectedKey", function() {
            return this.view.lstTimeCheckins.selectedKey;
        });
        defineSetter(this, "selectedKeys", function(val) {
            this.view.lstTimeCheckins.selectedKeys = val;
        });
        defineGetter(this, "selectedKeys", function() {
            return this.view.lstTimeCheckins.selectedKeys;
        });
        defineSetter(this, "HeaderText", function(val) {
            this.view.lblHeaderText.text = val;
        });
        defineGetter(this, "HeaderText", function() {
            return this.view.lblHeaderText.text;
        });
        defineSetter(this, "DescriptionText", function(val) {
            this.view.lblBody.text = val;
        });
        defineGetter(this, "DescriptionText", function() {
            return this.view.lblBody.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickOfUpdateETA_c5e4fe4590734da8a69c8af1d8559499 = function() {
        if (this.onClickOfUpdateETA) {
            this.onClickOfUpdateETA.apply(this, arguments);
        }
    }
    controller.AS_onClickOfUpdateETACancel_a06c849f10a046c798966d9091ad8d69 = function() {
        if (this.onClickOfUpdateETACancel) {
            this.onClickOfUpdateETACancel.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/ETAReporting/ETAReporting',[],function() {
    return function(controller) {
        var ETAReporting = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "ETAReporting",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_de4a2e36db7344149118d27fa588de8d(eventobject);
            },
            "skin": "CopyCopyflxBackgroundAlertSkn1",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "ETAReporting"), extendConfig({}, controller.args[1], "ETAReporting"), extendConfig({}, controller.args[2], "ETAReporting"));
        ETAReporting.setDefaultUnit(kony.flex.DP);
        var alertFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "332px",
            "id": "alertFlex",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "isModalContainer": false,
            "skin": "CopyCopyalertSkin1",
            "width": "530px",
            "zIndex": 1
        }, controller.args[0], "alertFlex"), extendConfig({}, controller.args[1], "alertFlex"), extendConfig({}, controller.args[2], "alertFlex"));
        alertFlex.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "60dp",
            "width": "230px",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var lblHeaderText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblHeaderText",
            "isVisible": true,
            "skin": "CopyCopyCopydefLabel0e25d88b557834f",
            "text": "Update ETA",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblHeaderText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeaderText"), extendConfig({}, controller.args[2], "lblHeaderText"));
        flxHeader.add(lblHeaderText);
        var flexShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "1dp",
            "id": "flexShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyCopyCopyslFbox0h072b0f654cd4b",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flexShadow"), extendConfig({}, controller.args[1], "flexShadow"), extendConfig({}, controller.args[2], "flexShadow"));
        flexShadow.setDefaultUnit(kony.flex.DP);
        flexShadow.add();
        var flxBody = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100dp",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "380dp",
            "zIndex": 1
        }, controller.args[0], "flxBody"), extendConfig({}, controller.args[1], "flxBody"), extendConfig({}, controller.args[2], "flxBody"));
        flxBody.setDefaultUnit(kony.flex.DP);
        var lblBody = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblBody",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopyCopydefLabel0cef3a211bdb545",
            "text": "Select time you want to add to the original ETA",
            "textStyle": {},
            "top": 0,
            "width": "350px",
            "zIndex": 1
        }, controller.args[0], "lblBody"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBody"), extendConfig({}, controller.args[2], "lblBody"));
        var FlexGroup0d4e6fb0f6a9c4d = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "48dp",
            "id": "FlexGroup0d4e6fb0f6a9c4d",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "410px"
        }, controller.args[0], "FlexGroup0d4e6fb0f6a9c4d"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "FlexGroup0d4e6fb0f6a9c4d"), extendConfig({}, controller.args[2], "FlexGroup0d4e6fb0f6a9c4d"));
        FlexGroup0d4e6fb0f6a9c4d.setDefaultUnit(kony.flex.DP);
        var lstTimeCheckins = new kony.ui.ListBox(extendConfig({
            "focusSkin": "CopydefListBoxFocus0dfafe9aa5c7e49",
            "height": "100%",
            "id": "lstTimeCheckins",
            "isVisible": true,
            "left": 0,
            "masterData": [
                ["1", "Time Checkins "],
                ["2", "30"],
                ["3", "45"],
                ["4", "60"]
            ],
            "selectedKey": "1",
            "selectedKeyValue": ["1", "Time Checkins "],
            "skin": "sknCheckinType1",
            "top": "0dp",
            "width": "390px",
            "zIndex": 1
        }, controller.args[0], "lstTimeCheckins"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lstTimeCheckins"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lstTimeCheckins"));
        FlexGroup0d4e6fb0f6a9c4d.add(lstTimeCheckins);
        flxBody.add(lblBody, FlexGroup0d4e6fb0f6a9c4d);
        var FlexContainer0i95b4cdd491445 = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "height": "220dp",
            "id": "FlexContainer0i95b4cdd491445",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "380dp",
            "zIndex": 10
        }, controller.args[0], "FlexContainer0i95b4cdd491445"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "FlexContainer0i95b4cdd491445"), extendConfig({}, controller.args[2], "FlexContainer0i95b4cdd491445"));
        FlexContainer0i95b4cdd491445.setDefaultUnit(kony.flex.DP);
        var btnCheckIn = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "focusSkin": "CopyCopybtnPressed1",
            "height": "44dp",
            "id": "btnCheckIn",
            "isVisible": true,
            "left": "200px",
            "onClick": controller.AS_onClickOfUpdateETA_c5e4fe4590734da8a69c8af1d8559499,
            "skin": "CopyCopybtnPressed1",
            "text": "Conform",
            "top": "10dp",
            "width": "162px",
            "zIndex": 10
        }, controller.args[0], "btnCheckIn"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnCheckIn"), extendConfig({}, controller.args[2], "btnCheckIn"));
        var btnCancel = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "focusSkin": "CopyCopybtnPressed1",
            "height": "44dp",
            "id": "btnCancel",
            "isVisible": true,
            "left": "0px",
            "onClick": controller.AS_onClickOfUpdateETACancel_a06c849f10a046c798966d9091ad8d69,
            "skin": "CopyCopybtnPressed1",
            "text": "Cancel",
            "top": "10dp",
            "width": "162px",
            "zIndex": 10
        }, controller.args[0], "btnCancel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnCancel"), extendConfig({}, controller.args[2], "btnCancel"));
        FlexContainer0i95b4cdd491445.add(btnCheckIn, btnCancel);
        alertFlex.add(flxHeader, flexShadow, flxBody, FlexContainer0i95b4cdd491445);
        ETAReporting.add(alertFlex);
        return ETAReporting;
    }
})
;
define('com/konysa/ETAReporting/ETAReportingConfig',[],function() {
    return {
        "properties": [{
            "name": "ListBoxMasterData",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKey",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKeys",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "HeaderText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "DescriptionText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["getListBoxSelectedValue"],
        "events": ["onClickOfUpdateETA", "onClickOfUpdateETACancel", "dismissAlert", "componentPreShow"]
    }
});

define("com/konysa/journeymap/userjourneymapController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._mapKey = "";
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            debugger;
            defineGetter(this, "mapKey", function() {
                return this._mapKey;
            });
            defineSetter(this, "mapKey", function(val) {
                this._mapKey = val;
            });
        },
        onPreShow: function() {
            kony.print("in MAP pre Show");
            if (typeof this._mapKey == 'string' && this._mapKey.length > 0) {
                this.view.mapJourney.mapKey = this._mapKey;
                this.view.mapJourney.mode = constants.MAP_VIEW_MODE_SATELLITE;
                //this.view.mapJourney.zoomLevel=6;
                // alert("map ::"+this.view.mapJourney.zoomLevel);
                this.view.mapJourney.showZoomControl = true;
                this.view.mapJourney.defaultPinImage = "";
                this.view.mapJourney.widgetDataMapForCallout = {
                    "lblDriverName": "driverName",
                    "lblLastKnownLocation": "LastKnownLocation",
                    "lblTime": "LastCheckPointTime",
                    "lblJourneyStatus": "journeyStatus",
                    "imgSelector": "imgSelector",
                    "lblLastKonwnLocationTitle": "lblLastKonwnLocationTitle",
                    "lblETA": "lblETA",
                    "lblJourneyId": "journey_id"
                };
                var pin1 = {
                    id: "id123", // id is mandatory for every pin
                    lat: "-21.592100",
                    lon: "121.523700",
                    name: "",
                    //image : "",
                    //focusImage:"",  //focus image will be shown while map pin selected
                    showCallout: false,
                    //zoomLevel :1
                    meta: {
                        color: "green",
                        label: "A"
                    }
                }
                this.setPin(pin1);
                //this.view.mapJourney.navigateToLocation(pin1, false, false);
            }
        },
        setPin: function(locationObj) {
            try {
                if (typeof locationObj == 'object' && locationObj !== null) {
                    this.view.mapJourney.addPin(locationObj);
                }
            } catch (excp) {
                debugger;
            }
        },
        //
        deleteAllPins: function(locationJsonArray) {
            try {
                if (locationJsonArray !== null && locationJsonArray.length != 0) {
                    this.view.mapJourney.removePins(locationJsonArray);
                }
            } catch (excp) {
                debugger;
            }
        },
        drawPolyline: function(polylineData) {
            kony.print("polylineData" + JSON.stringify(polylineData));
            //this.view.mapJourney.clear();
            this.view.mapJourney.navigateToLocation(polylineData["startLocation"], true, true);
            this.view.mapJourney.addPolyline(polylineData);
        },
        deletePolyline: function(polylineId) {
            kony.print("polyline id ::" + polylineId);
            this.view.mapJourney.removePolyline(polylineId);
        },
        setZoomLevelOnMap: function() {
            //this.view.mapJourney.zoomLevel=1;
        }
    };
});
define("com/konysa/journeymap/journeymapControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for mapJourney **/
    AS_Map_e3501eb1f0d3467dbe29e8937da1439a: function AS_Map_e3501eb1f0d3467dbe29e8937da1439a(eventobject, location) {
        var self = this;
        var locationData = {};
        this.view.mapJourney.dismissCallout(locationData);
    },
    /** preShow defined for journeymap **/
    AS_FlexContainer_ebdd640a1faf475dbac1627d7146759a: function AS_FlexContainer_ebdd640a1faf475dbac1627d7146759a(eventobject) {
        var self = this;
        this.onPreShow();
    }
});
define("com/konysa/journeymap/journeymapController", ["com/konysa/journeymap/userjourneymapController", "com/konysa/journeymap/journeymapControllerActions"], function() {
    var controller = require("com/konysa/journeymap/userjourneymapController");
    var actions = require("com/konysa/journeymap/journeymapControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/journeymap/journeymap',[],function() {
    return function(controller) {
        var journeymap = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "journeymap",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_ebdd640a1faf475dbac1627d7146759a(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "journeymap"), extendConfig({}, controller.args[1], "journeymap"), extendConfig({}, controller.args[2], "journeymap"));
        journeymap.setDefaultUnit(kony.flex.DP);
        var mapJourney = new kony.ui.Map(extendConfig({
            "calloutTemplate": "flxMapTemplate",
            "calloutWidth": 80,
            "defaultPinImage": "pinb.png",
            "height": "100%",
            "id": "mapJourney",
            "isVisible": true,
            "left": "0dp",
            "onClick": controller.AS_Map_e3501eb1f0d3467dbe29e8937da1439a,
            "provider": constants.MAP_PROVIDER_GOOGLE,
            "top": "0dp",
            "widgetDataMapForCallout": {
                "flxAction": "flxAction",
                "flxActionRoot": "flxActionRoot",
                "flxContainer1": "flxContainer1",
                "flxJourneyCardHeader": "flxJourneyCardHeader",
                "flxLocationTime": "flxLocationTime",
                "flxMapTemplate": "flxMapTemplate",
                "flxMenu": "flxMenu",
                "flxRoot1": "flxRoot1",
                "flxRootJourneyCard1": "flxRootJourneyCard1",
                "flxTitle": "flxTitle",
                "Label0h31fc0f2c2c547": "Label0h31fc0f2c2c547",
                "lblActionText": "lblActionText",
                "lblDriverName": "lblDriverName",
                "lblETA": "lblETA",
                "lblJourneyId": "lblJourneyId",
                "lblJourneyStatus": "lblJourneyStatus",
                "lblLastKnownLocation": "lblLastKnownLocation",
                "lblLastKonwnLocationTitle": "lblLastKonwnLocationTitle",
                "lblTime": "lblTime"
            },
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "mapJourney"), extendConfig({}, controller.args[1], "mapJourney"), extendConfig({}, controller.args[2], "mapJourney"));
        journeymap.add(mapJourney);
        return journeymap;
    }
})
;
define('com/konysa/journeymap/journeymapConfig',[],function() {
    return {
        "properties": [{
            "name": "mapKey",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setPin", "deleteAllPins", "drawPolyline", "deletePolyline", "setZoomLevelOnMap"],
        "events": []
    }
});

define("com/konysa/jrmgmtheader/userjrmgmtheaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        _onAddClick: function(param) {
            kony.print("---Entering OnAddClick -----");
            if (typeof this.onAddClick == 'function') {
                this.onAddClick(param);
            }
        },
        _onBellClick: function(eventobject, x, y) {
            if (typeof this.onBellClick == 'function') {
                this.onBellClick(eventobject, x, y)
            }
        },
        _onLogOutClick: function(param) {
            if (typeof this.onLogOutClick == 'function') {
                this.onLogOutClick(param);
            }
        },
        enableBellNotification: function(flag) {
            //alert("flag"+flag);
            if (flag == 1) this.view.lblBellNotification.isVisible = true;
            else this.view.lblBellNotification.isVisible = false;
        }
    };
});
define("com/konysa/jrmgmtheader/jrmgmtheaderControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchEnd defined for flxBellNotification **/
    AS_FlexContainer_e41a16566a6245ccbdc81be872ccd4ff: function AS_FlexContainer_e41a16566a6245ccbdc81be872ccd4ff(eventobject, x, y) {
        var self = this;
        this._onBellClick(eventobject, x, y);
    },
    /** onClick defined for flxAdd **/
    AS_FlexContainer_da1b3fe7ed034a2592bdd2e865d1a1a5: function AS_FlexContainer_da1b3fe7ed034a2592bdd2e865d1a1a5(eventobject) {
        var self = this;
        this._onAddClick(eventobject);
    }
});
define("com/konysa/jrmgmtheader/jrmgmtheaderController", ["com/konysa/jrmgmtheader/userjrmgmtheaderController", "com/konysa/jrmgmtheader/jrmgmtheaderControllerActions"], function() {
    var controller = require("com/konysa/jrmgmtheader/userjrmgmtheaderController");
    var actions = require("com/konysa/jrmgmtheader/jrmgmtheaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickOfLogOut_a51fbd78ed9541f78bf34a389eacaa20 = function() {
        if (this.onClickOfLogOut) {
            this.onClickOfLogOut.apply(this, arguments);
        }
    }
    controller.AS_onClickOfFlxRefresh_c81a594f21ac405ab1bbeec398bdedc3 = function() {
        if (this.onClickOfFlxRefresh) {
            this.onClickOfFlxRefresh.apply(this, arguments);
        }
    }
    controller.AS_onClickOfBtnRefresh_a9776c79a834428b8d47c25e3ea9aa7c = function() {
        if (this.onClickOfBtnRefresh) {
            this.onClickOfBtnRefresh.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/jrmgmtheader/jrmgmtheader',[],function() {
    return function(controller) {
        var jrmgmtheader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "50dp",
            "id": "jrmgmtheader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhite",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "jrmgmtheader"), extendConfig({}, controller.args[1], "jrmgmtheader"), extendConfig({}, controller.args[2], "jrmgmtheader"));
        jrmgmtheader.setDefaultUnit(kony.flex.DP);
        var flxLogo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "24dp",
            "id": "flxLogo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "10dp",
            "isModalContainer": false,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "flxLogo"), extendConfig({}, controller.args[1], "flxLogo"), extendConfig({
            "hoverSkin": "sknFlxBGTransCursorPointer"
        }, controller.args[2], "flxLogo"));
        flxLogo.setDefaultUnit(kony.flex.DP);
        var imgLogo = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgLogo",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "kony_logo.png",
            "top": "0dp",
            "width": "12.50%",
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        flxLogo.add(imgLogo);
        var flxLogOut = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "34dp",
            "id": "flxLogOut",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfLogOut_a51fbd78ed9541f78bf34a389eacaa20,
            "right": "14dp",
            "skin": "sknFlxBGTransCursorPointer",
            "width": "26dp",
            "zIndex": 1
        }, controller.args[0], "flxLogOut"), extendConfig({}, controller.args[1], "flxLogOut"), extendConfig({
            "hoverSkin": "sknFlxBGTransCursorPointer"
        }, controller.args[2], "flxLogOut"));
        flxLogOut.setDefaultUnit(kony.flex.DP);
        var imgInbox = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "imgInbox",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "inbox.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgInbox"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgInbox"), extendConfig({}, controller.args[2], "imgInbox"));
        var lblInboxNotification = new kony.ui.Label(extendConfig({
            "height": "12dp",
            "id": "lblInboxNotification",
            "isVisible": false,
            "right": "0dp",
            "skin": "sknLblBgC96866Border100",
            "top": "0dp",
            "width": "12dp",
            "zIndex": 1
        }, controller.args[0], "lblInboxNotification"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblInboxNotification"), extendConfig({}, controller.args[2], "lblInboxNotification"));
        flxLogOut.add(imgInbox, lblInboxNotification);
        var flxBellNotification = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "34dp",
            "id": "flxBellNotification",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onTouchEnd": controller.AS_FlexContainer_e41a16566a6245ccbdc81be872ccd4ff,
            "right": "51dp",
            "skin": "sknFlxBGTransCursorPointer",
            "width": "26dp",
            "zIndex": 1
        }, controller.args[0], "flxBellNotification"), extendConfig({}, controller.args[1], "flxBellNotification"), extendConfig({
            "hoverSkin": "sknFlxBGTransCursorPointer"
        }, controller.args[2], "flxBellNotification"));
        flxBellNotification.setDefaultUnit(kony.flex.DP);
        var imgBellNotification = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "imgBellNotification",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "bell.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgBellNotification"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBellNotification"), extendConfig({}, controller.args[2], "imgBellNotification"));
        var lblBellNotification = new kony.ui.Label(extendConfig({
            "height": "12dp",
            "id": "lblBellNotification",
            "isVisible": false,
            "right": "0dp",
            "skin": "sknLblBgC96866Border100",
            "top": "0dp",
            "width": "12dp",
            "zIndex": 1
        }, controller.args[0], "lblBellNotification"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBellNotification"), extendConfig({}, controller.args[2], "lblBellNotification"));
        flxBellNotification.add(imgBellNotification, lblBellNotification);
        var flxAdd = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "34dp",
            "id": "flxAdd",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_da1b3fe7ed034a2592bdd2e865d1a1a5,
            "right": "90dp",
            "skin": "sknFlxBGTransCursorPointer",
            "width": "26dp",
            "zIndex": 1
        }, controller.args[0], "flxAdd"), extendConfig({}, controller.args[1], "flxAdd"), extendConfig({
            "hoverSkin": "sknFlxBGTransCursorPointer"
        }, controller.args[2], "flxAdd"));
        flxAdd.setDefaultUnit(kony.flex.DP);
        var imgAddIcon = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "imgAddIcon",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "add.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgAddIcon"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgAddIcon"), extendConfig({}, controller.args[2], "imgAddIcon"));
        var lblAddNotification = new kony.ui.Label(extendConfig({
            "height": "12dp",
            "id": "lblAddNotification",
            "isVisible": false,
            "right": "0dp",
            "skin": "sknLblBgC96866Border100",
            "top": "0dp",
            "width": "12dp",
            "zIndex": 1
        }, controller.args[0], "lblAddNotification"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblAddNotification"), extendConfig({}, controller.args[2], "lblAddNotification"));
        flxAdd.add(imgAddIcon, lblAddNotification);
        var flxRefresh = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "28dp",
            "id": "flxRefresh",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfFlxRefresh_c81a594f21ac405ab1bbeec398bdedc3,
            "right": "120dp",
            "skin": "sknFlxBGTransCursorPointer",
            "top": "0dp",
            "width": "26px",
            "zIndex": 2
        }, controller.args[0], "flxRefresh"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "flxRefresh"), extendConfig({}, controller.args[2], "flxRefresh"));
        flxRefresh.setDefaultUnit(kony.flex.DP);
        var Button0i85adcefb26443 = new kony.ui.Button(extendConfig({
            "focusSkin": "defBtnFocus",
            "height": "27dp",
            "id": "Button0i85adcefb26443",
            "isVisible": false,
            "left": "0dp",
            "onClick": controller.AS_onClickOfBtnRefresh_a9776c79a834428b8d47c25e3ea9aa7c,
            "skin": "CopydefBtnNormal0c7361412bb1e4d",
            "text": "R",
            "top": "0dp",
            "width": "26dp",
            "zIndex": 1
        }, controller.args[0], "Button0i85adcefb26443"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Button0i85adcefb26443"), extendConfig({}, controller.args[2], "Button0i85adcefb26443"));
        var Image0gc257b217a4145 = new kony.ui.Image2(extendConfig({
            "height": "20dp",
            "id": "Image0gc257b217a4145",
            "isVisible": false,
            "left": "7dp",
            "skin": "slImage",
            "src": "refresh_icon.png",
            "top": "8dp",
            "width": "20dp",
            "zIndex": 2
        }, controller.args[0], "Image0gc257b217a4145"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0gc257b217a4145"), extendConfig({}, controller.args[2], "Image0gc257b217a4145"));
        var Refresh = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "26dp",
            "id": "Refresh",
            "isVisible": true,
            "left": "10dp",
            "skin": "CopyslFontAwesomeIcon0b1a5314a787045",
            "text": "",
            "width": "26dp",
            "zIndex": 1
        }, controller.args[0], "Refresh"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Refresh"), extendConfig({}, controller.args[2], "Refresh"));
        flxRefresh.add(Button0i85adcefb26443, Image0gc257b217a4145, Refresh);
        jrmgmtheader.add(flxLogo, flxLogOut, flxBellNotification, flxAdd, flxRefresh);
        return jrmgmtheader;
    }
})
;
define('com/konysa/jrmgmtheader/jrmgmtheaderConfig',[],function() {
    return {
        "properties": [],
        "apis": ["enableBellNotification"],
        "events": ["onClickOfFlxRefresh", "onClickOfBtnRefresh", "onClickOfLogOut", "onAddClick", "onBellClick", "onLogOutClick"]
    }
});

define("com/konysa/masktext/usermasktextController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._isTextBoxEnabled = false;
            this._inputText = null;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        test: function() {
            this.view.txtBox.secureTextEntry = false;
        },
        onTouchEnd: function() {
            this.view.txtBox.secureTextEntry = true;
        },
        maskText: function(isMask) {
            switch (isMask) {
                case true:
                    this.view.txtBox.secureTextEntry = true;
                    break;
                case false:
                    this.view.txtBox.secureTextEntry = false;
                    break;
                default:
                    this.view.txtBox.secureTextEntry = false;
            }
        },
        onTxtDone: function() {
            //alert(this.view.txtBox.text);
            var inputText = this.view.txtBox.text;
            if (typeof inputText == 'string') {
                inputText = inputText.trim();
                if (inputText.length > 0) {
                    this._inputText = inputText;
                } else {
                    this._inputText = null;
                    this.disableTextBox();
                }
            } else {
                this.disableTextBox();
            }
        },
        getText: function() {
            return this._inputText;
        },
        enableTextBox: function() {
            var self = this;
            if (self._isTextBoxEnabled === false) {
                var transformProp1 = kony.ui.makeAffineTransform();
                transformProp1.scale(1, 1);
                var transformProp2 = kony.ui.makeAffineTransform();
                transformProp2.scale(0.5, 0.4);
                var animDefinitionOne = {
                    0: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp1
                    },
                    100: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp2
                    }
                };
                var animDefinition = kony.ui.createAnimation(animDefinitionOne);
                this.view.flxInfo.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self._isTextBoxEnabled = true;
                        self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {}
                });
            }
        },
        disableTextBox: function() {
            var self = this;
            if (self._isTextBoxEnabled === true) {
                self.view.flxInfo.setFocus(true);
                var transformProp1 = kony.ui.makeAffineTransform();
                transformProp1.scale(0.5, 0.4);
                var transformProp2 = kony.ui.makeAffineTransform();
                transformProp2.scale(1, 1);
                var animDefinitionOne = {
                    0: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp1
                    },
                    100: {
                        "anchorPoint": {
                            "x": 0,
                            "y": 0
                        },
                        "transform": transformProp2
                    }
                };
                var animDefinition = kony.ui.createAnimation(animDefinitionOne);
                this.view.flxInfo.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self._isTextBoxEnabled = false;
                    },
                    "animationStart": function() {}
                });
            }
        }
    };
});
define("com/konysa/masktext/masktextControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDone defined for txtBox **/
    AS_TextField_d5771b34afd94040800969837e6bb6f6: function AS_TextField_d5771b34afd94040800969837e6bb6f6(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_ed4f71b8760c4941a474606acd111dff: function AS_TextField_ed4f71b8760c4941a474606acd111dff(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_c4a5dbf889364ddc959436164aeeb122: function AS_TextField_c4a5dbf889364ddc959436164aeeb122(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_gdcc31a259b14393b236b24ca9e16e4b: function AS_TextField_gdcc31a259b14393b236b24ca9e16e4b(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onEndEditing defined for txtBox **/
    AS_TextField_c09581571f9c4fc794cc46a3ab7c329c: function AS_TextField_c09581571f9c4fc794cc46a3ab7c329c(eventobject, changedtext) {
        var self = this;
        this.onTxtDone();
    },
    /** onTouchStart defined for flxUnmasker **/
    AS_FlexContainer_a22c46020a8c4c60a03958278ec80054: function AS_FlexContainer_a22c46020a8c4c60a03958278ec80054(eventobject, x, y) {
        var self = this;
        this.maskText(false);
    },
    /** onTouchEnd defined for flxUnmasker **/
    AS_FlexContainer_d2ee94948b9d492588d6e920cdff9b3c: function AS_FlexContainer_d2ee94948b9d492588d6e920cdff9b3c(eventobject, x, y) {
        var self = this;
        this.maskText(true);
    },
    /** onClick defined for flxInfo **/
    AS_FlexContainer_d024f4c7a3ca4ca0b4c1c277b8514688: function AS_FlexContainer_d024f4c7a3ca4ca0b4c1c277b8514688(eventobject) {
        var self = this;
        this.enableTextBox();
    }
});
define("com/konysa/masktext/masktextController", ["com/konysa/masktext/usermasktextController", "com/konysa/masktext/masktextControllerActions"], function() {
    var controller = require("com/konysa/masktext/usermasktextController");
    var actions = require("com/konysa/masktext/masktextControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "skin1", function(val) {
            this.view.lblDivider.skin = val;
        });
        defineGetter(this, "skin1", function() {
            return this.view.lblDivider.skin;
        });
        defineSetter(this, "skin2", function(val) {
            this.view.txtBox.skin = val;
        });
        defineGetter(this, "skin2", function() {
            return this.view.txtBox.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/masktext/masktext',[],function() {
    return function(controller) {
        var masktext = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "52dp",
            "id": "masktext",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknCMPMaskTextFlxWhiteBG",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "masktext"), extendConfig({}, controller.args[1], "masktext"), extendConfig({
            "hoverSkin": "sknCMPMaskTextFlxBGTransCursorPointer"
        }, controller.args[2], "masktext"));
        masktext.setDefaultUnit(kony.flex.DP);
        var txtBox = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "bottom": "2dp",
            "focusSkin": "sknCMPMaskTextTxtBoxFontBlackSize18",
            "id": "txtBox",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "onDone": controller.AS_TextField_d5771b34afd94040800969837e6bb6f6,
            "right": "15dp",
            "secureTextEntry": true,
            "skin": "sknCMPMaskTextTxtBoxFontBlackSize18",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "8dp",
            "zIndex": 1
        }, controller.args[0], "txtBox"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtBox"), extendConfig({
            "autoCorrect": false,
            "onEndEditing": controller.AS_TextField_c09581571f9c4fc794cc46a3ab7c329c,
            "placeholderSkin": "defTextBoxPlaceholder"
        }, controller.args[2], "txtBox"));
        var flxUnmasker = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "25dp",
            "id": "flxUnmasker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onTouchEnd": controller.AS_FlexContainer_d2ee94948b9d492588d6e920cdff9b3c,
            "onTouchStart": controller.AS_FlexContainer_a22c46020a8c4c60a03958278ec80054,
            "right": "0dp",
            "skin": "slFbox",
            "width": "15dp",
            "zIndex": 1
        }, controller.args[0], "flxUnmasker"), extendConfig({}, controller.args[1], "flxUnmasker"), extendConfig({}, controller.args[2], "flxUnmasker"));
        flxUnmasker.setDefaultUnit(kony.flex.DP);
        var imgUnmasker = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "13dp",
            "id": "imgUnmasker",
            "isVisible": true,
            "right": "0dp",
            "skin": "slImage",
            "src": "mask.png",
            "top": "8dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgUnmasker"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgUnmasker"), extendConfig({}, controller.args[2], "imgUnmasker"));
        flxUnmasker.add(imgUnmasker);
        var lblDivider = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider",
            "isVisible": true,
            "skin": "sknCMPMaskTextLblBGC6cbd4",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider"), extendConfig({}, controller.args[2], "lblDivider"));
        var flxInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "42dp",
            "id": "flxInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_d024f4c7a3ca4ca0b4c1c277b8514688,
            "skin": "slFbox",
            "top": "8dp",
            "width": "100%",
            "zIndex": 5
        }, controller.args[0], "flxInfo"), extendConfig({}, controller.args[1], "flxInfo"), extendConfig({
            "hoverSkin": "sknCMPMaskTextFlxBGTransCursorPointer"
        }, controller.args[2], "flxInfo"));
        flxInfo.setDefaultUnit(kony.flex.DP);
        var imgInfo = new kony.ui.Image2(extendConfig({
            "bottom": "5dp",
            "height": "60%",
            "id": "imgInfo",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "password.png",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgInfo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgInfo"), extendConfig({}, controller.args[2], "imgInfo"));
        flxInfo.add(imgInfo);
        masktext.add(txtBox, flxUnmasker, lblDivider, flxInfo);
        return masktext;
    }
})
;
define('com/konysa/masktext/masktextConfig',[],function() {
    return {
        "properties": [{
            "name": "skin1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "skin2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["getText"],
        "events": []
    }
});

define("com/konysa/pathinfo/userpathinfoController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        setWidgetDataMapTOSegment: function() {
            this.view.segPathList.widgetDataMap = {
                "lblLine0": "lblLine0",
                "lblLine1": "lblLine1",
                "lblLastKnownLocation": "lblLastKnownLocation",
                "imgPathIcon": "imgPathIcon",
                "lblLocation": "lblLocation",
                "lblTime": "lblTime",
                "imgClock": "imgClock",
                "lblDate": "lblDate",
                "imgVechile": "imgVechile"
            }
        },
        setCheckPointsDataToSegment: function(segCheckPointsDataForPath) {
            this.view.segPathList.setData(segCheckPointsDataForPath);
        },
        setFlxActionVisibility_pathInfo: function(journeyStatus) {
            if (journeyStatus == "Completed" || journeyStatus == "completed" || journeyStatus == "terminated" || journeyStatus == "Terminated") {
                this.view.flxAction.setVisibility(false);
            } else {
                this.view.flxAction.setVisibility(true);
            }
        }
    };
});
define("com/konysa/pathinfo/pathinfoControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konysa/pathinfo/pathinfoController", ["com/konysa/pathinfo/userpathinfoController", "com/konysa/pathinfo/pathinfoControllerActions"], function() {
    var controller = require("com/konysa/pathinfo/userpathinfoController");
    var actions = require("com/konysa/pathinfo/pathinfoControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickOfChangeETA_i6d31864e3ad4c98b5ea113aea0caf9b = function() {
        if (this.onClickOfChangeETA) {
            this.onClickOfChangeETA.apply(this, arguments);
        }
    }
    controller.AS_onClickOfCloseJourney_jbe1bef230104a41869361f2de7e15e1 = function() {
        if (this.onClickOfCloseJourney) {
            this.onClickOfCloseJourney.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/pathinfo/pathinfo',[],function() {
    return function(controller) {
        var pathinfo = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "pathinfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhite",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "pathinfo"), extendConfig({}, controller.args[1], "pathinfo"), extendConfig({}, controller.args[2], "pathinfo"));
        pathinfo.setDefaultUnit(kony.flex.DP);
        var flxRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxRoot"), extendConfig({}, controller.args[1], "flxRoot"), extendConfig({}, controller.args[2], "flxRoot"));
        flxRoot.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont3d3d3dSize100TypeBold",
            "text": "Destination Information",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var flxSegRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxSegRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxSegRoot"), extendConfig({}, controller.args[1], "flxSegRoot"), extendConfig({}, controller.args[2], "flxSegRoot"));
        flxSegRoot.setDefaultUnit(kony.flex.DP);
        var segPathList = new kony.ui.SegmentedUI2(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "data": [{
                "imgClock": "",
                "imgPathIcon": "",
                "imgVechile": "",
                "lblDate": "",
                "lblLastKnownLocation": "",
                "lblLine0": "",
                "lblLine1": "",
                "lblLocation": "",
                "lblTime": ""
            }],
            "groupCells": false,
            "id": "segPathList",
            "isVisible": true,
            "left": "0dp",
            "maxHeight": 250,
            "needPageIndicator": true,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "right": "-16dp",
            "rowFocusSkin": "seg2Focus",
            "rowSkin": "seg2Normal",
            "rowTemplate": "flxPathRoot",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
            "separatorColor": "ffffff00",
            "separatorRequired": true,
            "separatorThickness": 0,
            "showScrollbars": false,
            "top": "0dp",
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "flxLastKnownLocation": "flxLastKnownLocation",
                "flxPathContainer": "flxPathContainer",
                "flxPathIcon": "flxPathIcon",
                "flxPathRoot": "flxPathRoot",
                "imgClock": "imgClock",
                "imgPathIcon": "imgPathIcon",
                "imgVechile": "imgVechile",
                "lblDate": "lblDate",
                "lblLastKnownLocation": "lblLastKnownLocation",
                "lblLine0": "lblLine0",
                "lblLine1": "lblLine1",
                "lblLocation": "lblLocation",
                "lblTime": "lblTime"
            },
            "zIndex": 1
        }, controller.args[0], "segPathList"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segPathList"), extendConfig({}, controller.args[2], "segPathList"));
        flxSegRoot.add(segPathList);
        var flxAction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxAction"), extendConfig({}, controller.args[1], "flxAction"), extendConfig({}, controller.args[2], "flxAction"));
        flxAction.setDefaultUnit(kony.flex.DP);
        var flxChangeETA = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxChangeETA",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfChangeETA_i6d31864e3ad4c98b5ea113aea0caf9b,
            "skin": "sknFlxBG575ee7Border42",
            "top": "11dp",
            "width": "125dp",
            "zIndex": 1
        }, controller.args[0], "flxChangeETA"), extendConfig({}, controller.args[1], "flxChangeETA"), extendConfig({}, controller.args[2], "flxChangeETA"));
        flxChangeETA.setDefaultUnit(kony.flex.DP);
        var lblChangeEta = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "id": "lblChangeEta",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhiteTypeRegular",
            "text": "Change ETA",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblChangeEta"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblChangeEta"), extendConfig({}, controller.args[2], "lblChangeEta"));
        flxChangeETA.add(lblChangeEta);
        var flxCLoseJourney = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxCLoseJourney",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "140dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfCloseJourney_jbe1bef230104a41869361f2de7e15e1,
            "skin": "sknFlxBG575ee7Border42",
            "top": "11dp",
            "width": "130dp",
            "zIndex": 1
        }, controller.args[0], "flxCLoseJourney"), extendConfig({}, controller.args[1], "flxCLoseJourney"), extendConfig({}, controller.args[2], "flxCLoseJourney"));
        flxCLoseJourney.setDefaultUnit(kony.flex.DP);
        var lblCloseJourney = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "id": "lblCloseJourney",
            "isVisible": true,
            "left": "12dp",
            "skin": "sknLblBGTransFontWhiteTypeRegular",
            "text": "Close Journey",
            "top": "3dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCloseJourney"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCloseJourney"), extendConfig({}, controller.args[2], "lblCloseJourney"));
        flxCLoseJourney.add(lblCloseJourney);
        var flxMenu = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknFlxBGWhiteBoxShadow2",
            "width": "40dp",
            "zIndex": 1
        }, controller.args[0], "flxMenu"), extendConfig({}, controller.args[1], "flxMenu"), extendConfig({}, controller.args[2], "flxMenu"));
        flxMenu.setDefaultUnit(kony.flex.DP);
        var imgBlueMenu = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "22dp",
            "id": "imgBlueMenu",
            "isVisible": true,
            "left": "10dp",
            "skin": "slImage",
            "src": "menu_blue.png",
            "top": "1dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgBlueMenu"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBlueMenu"), extendConfig({}, controller.args[2], "imgBlueMenu"));
        flxMenu.add(imgBlueMenu);
        flxAction.add(flxChangeETA, flxCLoseJourney, flxMenu);
        flxRoot.add(lblTitle, flxSegRoot, flxAction);
        pathinfo.add(flxRoot);
        return pathinfo;
    }
})
;
define('com/konysa/pathinfo/pathinfoConfig',[],function() {
    return {
        "properties": [],
        "apis": ["setWidgetDataMapTOSegment", "setCheckPointsDataToSegment", "setFlxActionVisibility_pathInfo"],
        "events": ["onClickOfChangeETA", "onClickOfCloseJourney"]
    }
});

define("com/konysa/processstatus/userprocessstatusController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        setProcessList: function(processList) {},
        setProcessStatus: function(index) {},
        getProcessStatus: function() {},
    };
});
define("com/konysa/processstatus/processstatusControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konysa/processstatus/processstatusController", ["com/konysa/processstatus/userprocessstatusController", "com/konysa/processstatus/processstatusControllerActions"], function() {
    var controller = require("com/konysa/processstatus/userprocessstatusController");
    var actions = require("com/konysa/processstatus/processstatusControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/processstatus/processstatus',[],function() {
    return function(controller) {
        var processstatus = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "processstatus",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "processstatus"), extendConfig({}, controller.args[1], "processstatus"), extendConfig({}, controller.args[2], "processstatus"));
        processstatus.setDefaultUnit(kony.flex.DP);
        var segStatus = new kony.ui.SegmentedUI2(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "data": [{
                "lblDown": "",
                "lblIndex": "1",
                "lblProcess": "Traveler Details",
                "lblUp": ""
            }, {
                "lblDown": "",
                "lblIndex": "2",
                "lblProcess": "Route Details",
                "lblUp": ""
            }, {
                "lblDown": "",
                "lblIndex": "3",
                "lblProcess": "Tracking Details",
                "lblUp": ""
            }, {
                "lblDown": "",
                "lblIndex": "4",
                "lblProcess": "Vehicle Details",
                "lblUp": ""
            }, {
                "lblDown": "",
                "lblIndex": "5",
                "lblProcess": "Review & Verifcation",
                "lblUp": ""
            }],
            "groupCells": false,
            "height": "100%",
            "id": "segStatus",
            "isVisible": true,
            "needPageIndicator": true,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "rowFocusSkin": "seg2Focus",
            "rowSkin": "seg2Normal",
            "rowTemplate": "flxRootProcessStatusDW",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
            "separatorColor": "aaaaaa00",
            "separatorRequired": false,
            "separatorThickness": 1,
            "showScrollbars": false,
            "top": "0dp",
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "flxRootProcessStatusDW": "flxRootProcessStatusDW",
                "flxTracker": "flxTracker",
                "lblDown": "lblDown",
                "lblIndex": "lblIndex",
                "lblProcess": "lblProcess",
                "lblUp": "lblUp"
            },
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "segStatus"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segStatus"), extendConfig({}, controller.args[2], "segStatus"));
        processstatus.add(segStatus);
        return processstatus;
    }
})
;
define('com/konysa/processstatus/processstatusConfig',[],function() {
    return {
        "properties": [],
        "apis": ["setProcessList", "setProcessStatus", "getProcessStatus"],
        "events": []
    }
});

define("com/konysa/searchnfilter/usersearchnfilterController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._isSearchBoxVisible = false;
            this._isFilterBoxVisible = false;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, "selectedIndices", function() {
                return this.view.segTrackingPoint.selectedIndices;
            });
        },
        showSearchBox: function() {
            var self = this;
            this.view.flxSearchRoot.setVisibility(true);
            this.view.forceLayout();
            return;
            var transformProp1 = kony.ui.makeAffineTransform();
            transformProp1.scale(0, 0);
            var transformProp2 = kony.ui.makeAffineTransform();
            transformProp2.scale(1, 1);
            var animDefinitionOne = {
                0: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp1
                },
                100: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp2
                }
            };
            var animDefinition = kony.ui.createAnimation(animDefinitionOne);
            try {
                this.view.flxSearchRoot.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        //self._isTextBoxEnabled=true;
                        //self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {
                        self.view.flxSearchRoot.setVisibility(true);
                        self.view.forceLayout();
                    }
                });
            } catch (excp) {
                debugger;
            }
        },
        hideSearchBox: function() {
            this.view.flxSearchRoot.setVisibility(false);
            this.view.forceLayout();
            return;
            var self = this;
            var transformProp1 = kony.ui.makeAffineTransform();
            transformProp1.scale(1, 1);
            var transformProp2 = kony.ui.makeAffineTransform();
            transformProp2.scale(0, 0);
            var animDefinitionOne = {
                0: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp1
                },
                100: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp2
                }
            };
            var animDefinition = kony.ui.createAnimation(animDefinitionOne);
            try {
                this.view.flxSearchRoot.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self.view.flxSearchRoot.setVisibility(false);
                        self.view.forceLayout();
                        //self._isTextBoxEnabled=true;
                        //self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {
                        //self.view.flxSearchRoot.setVisibility(true);
                        //self.view.forceLayout();
                    }
                });
            } catch (excp) {
                debugger;
            }
        },
        showFilterBox: function() {
            var self = this;
            this.view.flxFilterRoot.setVisibility(true);
            this.view.forceLayout();
            return;
            var transformProp1 = kony.ui.makeAffineTransform();
            transformProp1.scale(0, 0);
            var transformProp2 = kony.ui.makeAffineTransform();
            transformProp2.scale(1, 1);
            var animDefinitionOne = {
                0: {
                    "anchorPoint": {
                        "x": 0.5,
                        "y": 0.5
                    },
                    "transform": transformProp1
                },
                100: {
                    "anchorPoint": {
                        "x": 0.5,
                        "y": 0.5
                    },
                    "transform": transformProp2
                }
            };
            var animDefinition = kony.ui.createAnimation(animDefinitionOne);
            try {
                this.view.flxFilterRoot.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        //self._isTextBoxEnabled=true;
                        //self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {
                        self.view.flxFilterRoot.setVisibility(true);
                        self.view.forceLayout();
                    }
                });
            } catch (excp) {
                debugger;
            }
        },
        hideFilterBox: function() {
            this.view.flxFilterRoot.setVisibility(false);
            this.view.forceLayout();
            return;
            var self = this;
            var transformProp1 = kony.ui.makeAffineTransform();
            transformProp1.scale(1, 1);
            var transformProp2 = kony.ui.makeAffineTransform();
            transformProp2.scale(0, 0);
            var animDefinitionOne = {
                0: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp1
                },
                100: {
                    "anchorPoint": {
                        "x": 0,
                        "y": 0
                    },
                    "transform": transformProp2
                }
            };
            var animDefinition = kony.ui.createAnimation(animDefinitionOne);
            try {
                this.view.flxFilterRoot.animate(animDefinition, {
                    "duration": 0.1,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    "animationEnd": function() {
                        self.view.flxSearchRoot.setVisibility(false);
                        self.view.forceLayout();
                        //self._isTextBoxEnabled=true;
                        //self.view.txtBox.setFocus(true);
                    },
                    "animationStart": function() {
                        //self.view.flxSearchRoot.setVisibility(true);
                        //self.view.forceLayout();
                    }
                });
            } catch (excp) {
                debugger;
            }
        },
        /* onRowClickOfSegment : function()
    {
    kony.print("in onRowClickOfSegment");
     var data1=this.view.segTrackingPoint.data;
     var rowIndex=this.view.segTrackingPoint.selectedIndices;
      kony.print("data1 ::"+JSON.stringify(data1));
      kony.print("rowIndex"+ rowIndex);
      //data1[rowIndex]["imgSelection"]="enteredcheckpoint.png";
      //this.view.segTrackingPoint.setData(data1);
    
  }*/
    };
});
define("com/konysa/searchnfilter/searchnfilterControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxSearchTitle **/
    AS_FlexContainer_a13a63d8bf234bbfae73929b2a05c17c: function AS_FlexContainer_a13a63d8bf234bbfae73929b2a05c17c(eventobject) {
        var self = this;
        this.showSearchBox();
    },
    /** onClick defined for flxFilterTitle **/
    AS_FlexContainer_j87bebbe7b3f440cb3ca3bb2d7dcbd52: function AS_FlexContainer_j87bebbe7b3f440cb3ca3bb2d7dcbd52(eventobject) {
        var self = this;
        return self.showFilterBox.call(this);
    }
});
define("com/konysa/searchnfilter/searchnfilterController", ["com/konysa/searchnfilter/usersearchnfilterController", "com/konysa/searchnfilter/searchnfilterControllerActions"], function() {
    var controller = require("com/konysa/searchnfilter/usersearchnfilterController");
    var actions = require("com/konysa/searchnfilter/searchnfilterControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "trackingPointsMasterData", function(val) {
            this.view.lstBoxTrackingPoint.masterData = val;
        });
        defineGetter(this, "trackingPointsMasterData", function() {
            return this.view.lstBoxTrackingPoint.masterData;
        });
        defineSetter(this, "selectedKey1", function(val) {
            this.view.lstBoxTrackingPoint.selectedKey = val;
        });
        defineGetter(this, "selectedKey1", function() {
            return this.view.lstBoxTrackingPoint.selectedKey;
        });
        defineSetter(this, "selectedKeys1", function(val) {
            this.view.lstBoxTrackingPoint.selectedKeys = val;
        });
        defineGetter(this, "selectedKeys1", function() {
            return this.view.lstBoxTrackingPoint.selectedKeys;
        });
        defineSetter(this, "supervisorsMasterData", function(val) {
            this.view.lstBoxSupervisor.masterData = val;
        });
        defineGetter(this, "supervisorsMasterData", function() {
            return this.view.lstBoxSupervisor.masterData;
        });
        defineSetter(this, "selectedKey", function(val) {
            this.view.lstBoxSupervisor.selectedKey = val;
        });
        defineGetter(this, "selectedKey", function() {
            return this.view.lstBoxSupervisor.selectedKey;
        });
        defineSetter(this, "selectedKeys", function(val) {
            this.view.lstBoxSupervisor.selectedKeys = val;
        });
        defineGetter(this, "selectedKeys", function() {
            return this.view.lstBoxSupervisor.selectedKeys;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.setTrackingPointsData = function() {
        var wModel = this.view.segTrackingPoint;
        return wModel.setData.apply(wModel, arguments);
    };
    controller.AS_closeSearch_b1935074f7eb425385c659e741aa2c41 = function() {
        if (this.closeSearch) {
            this.closeSearch.apply(this, arguments);
        }
    }
    controller.AS_onDoneOfTxtBoxUser_h30809cd31aa4c48a21c181397937170 = function() {
        if (this.onDoneOfTxtBoxUser) {
            this.onDoneOfTxtBoxUser.apply(this, arguments);
        }
    }
    controller.AS_closeFilter_b8269a64b6bd4739ac957c02cf00d487 = function() {
        if (this.closeFilter) {
            this.closeFilter.apply(this, arguments);
        }
    }
    controller.AS_onSelectionOfTrackingPoints_bd1fdb6318bd4e55abd955e3405367dd = function() {
        if (this.onSelectionOfTrackingPoints) {
            this.onSelectionOfTrackingPoints.apply(this, arguments);
        }
    }
    controller.AS_onSelectionOfTrackingPointsSegment_g6a768f8fc364f6fbffc2d40d52d6446 = function() {
        if (this.onSelectionOfTrackingPointsSegment) {
            this.onSelectionOfTrackingPointsSegment.apply(this, arguments);
        }
    }
    controller.AS_onSelectionCallBack_f65bd1bede1e409ab54a03fe101d13b4 = function() {
        if (this.onSelectionCallBack) {
            this.onSelectionCallBack.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/searchnfilter/searchnfilter',[],function() {
    return function(controller) {
        var searchnfilter = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "searchnfilter",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "searchnfilter"), extendConfig({}, controller.args[1], "searchnfilter"), extendConfig({}, controller.args[2], "searchnfilter"));
        searchnfilter.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var flxSearchTitle = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxSearchTitle",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_a13a63d8bf234bbfae73929b2a05c17c,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "2dp",
            "width": "100dp",
            "zIndex": 1
        }, controller.args[0], "flxSearchTitle"), extendConfig({}, controller.args[1], "flxSearchTitle"), extendConfig({}, controller.args[2], "flxSearchTitle"));
        flxSearchTitle.setDefaultUnit(kony.flex.DP);
        var imgSearchIcon = new kony.ui.Image2(extendConfig({
            "centerY": "55%",
            "height": "75%",
            "id": "imgSearchIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "search.png",
            "width": "23%",
            "zIndex": 1
        }, controller.args[0], "imgSearchIcon"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgSearchIcon"), extendConfig({}, controller.args[2], "imgSearchIcon"));
        var lblSearch = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblSearch",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Search",
            "textStyle": {},
            "width": "55%",
            "zIndex": 1
        }, controller.args[0], "lblSearch"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSearch"), extendConfig({}, controller.args[2], "lblSearch"));
        flxSearchTitle.add(imgSearchIcon, lblSearch);
        var flxFilterTitle = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxFilterTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_j87bebbe7b3f440cb3ca3bb2d7dcbd52,
            "right": "0dp",
            "skin": "sknFlxBGTransCursorPointer",
            "width": "70dp",
            "zIndex": 1
        }, controller.args[0], "flxFilterTitle"), extendConfig({}, controller.args[1], "flxFilterTitle"), extendConfig({}, controller.args[2], "flxFilterTitle"));
        flxFilterTitle.setDefaultUnit(kony.flex.DP);
        var imgFIlter = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "20dp",
            "id": "imgFIlter",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "filter.png",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgFIlter"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgFIlter"), extendConfig({}, controller.args[2], "imgFIlter"));
        var lblFilter = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblFilter",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Filters",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblFilter"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblFilter"), extendConfig({}, controller.args[2], "lblFilter"));
        flxFilterTitle.add(imgFIlter, lblFilter);
        flxHeader.add(flxSearchTitle, flxFilterTitle);
        var flxItemContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxItemContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "40dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxItemContainer"), extendConfig({}, controller.args[1], "flxItemContainer"), extendConfig({}, controller.args[2], "flxItemContainer"));
        flxItemContainer.setDefaultUnit(kony.flex.DP);
        var flxSearchRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "174dp",
            "id": "flxSearchRoot",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxSearchRoot"), extendConfig({}, controller.args[1], "flxSearchRoot"), extendConfig({}, controller.args[2], "flxSearchRoot"));
        flxSearchRoot.setDefaultUnit(kony.flex.DP);
        var flxSearchLbl = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxSearchLbl",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "30dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "30dp",
            "width": "100dp",
            "zIndex": 1
        }, controller.args[0], "flxSearchLbl"), extendConfig({}, controller.args[1], "flxSearchLbl"), extendConfig({}, controller.args[2], "flxSearchLbl"));
        flxSearchLbl.setDefaultUnit(kony.flex.DP);
        var lblSearchTitle = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblSearchTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont545963Size113",
            "text": "Search",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblSearchTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 1, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSearchTitle"), extendConfig({}, controller.args[2], "lblSearchTitle"));
        flxSearchLbl.add(lblSearchTitle);
        var flxCloseSearch = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxCloseSearch",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_closeSearch_b1935074f7eb425385c659e741aa2c41,
            "right": "30dp",
            "skin": "sknFlxBGTransCursorPointer",
            "top": "30dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "flxCloseSearch"), extendConfig({}, controller.args[1], "flxCloseSearch"), extendConfig({}, controller.args[2], "flxCloseSearch"));
        flxCloseSearch.setDefaultUnit(kony.flex.DP);
        var imgCloseSearch = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgCloseSearch",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "close_search.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgCloseSearch"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgCloseSearch"), extendConfig({}, controller.args[2], "imgCloseSearch"));
        flxCloseSearch.add(imgCloseSearch);
        var lblSearchMsg = new kony.ui.Label(extendConfig({
            "id": "lblSearchMsg",
            "isVisible": true,
            "left": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88TypeBold",
            "text": "Search based on ID or Username",
            "top": "74dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblSearchMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSearchMsg"), extendConfig({}, controller.args[2], "lblSearchMsg"));
        var txtBoxUser = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "sknTxtBoxBGWhiteFont3d3d3dSize88Border",
            "height": "50dp",
            "id": "txtBoxUser",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "30dp",
            "onDone": controller.AS_onDoneOfTxtBoxUser_h30809cd31aa4c48a21c181397937170,
            "placeholder": "Enter  JourneyID or Username or userId",
            "right": "30dp",
            "secureTextEntry": false,
            "skin": "sknTxtBoxBGWhiteFont3d3d3dSize88Border",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "94dp",
            "zIndex": 1
        }, controller.args[0], "txtBoxUser"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtBoxUser"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTxtBoxBGWhiteFont3d3d3dSize88"
        }, controller.args[2], "txtBoxUser"));
        flxSearchRoot.add(flxSearchLbl, flxCloseSearch, lblSearchMsg, txtBoxUser);
        var flxFilterRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "350dp",
            "id": "flxFilterRoot",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxFilterRoot"), extendConfig({}, controller.args[1], "flxFilterRoot"), extendConfig({}, controller.args[2], "flxFilterRoot"));
        flxFilterRoot.setDefaultUnit(kony.flex.DP);
        var flxFilter = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxFilter",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "30dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0b3e9f47f7cf24b",
            "top": "30dp",
            "width": "100dp",
            "zIndex": 1
        }, controller.args[0], "flxFilter"), extendConfig({}, controller.args[1], "flxFilter"), extendConfig({}, controller.args[2], "flxFilter"));
        flxFilter.setDefaultUnit(kony.flex.DP);
        var lblFIlterTItle = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblFIlterTItle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont545963Size113",
            "text": "Filters",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblFIlterTItle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 1, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblFIlterTItle"), extendConfig({}, controller.args[2], "lblFIlterTItle"));
        flxFilter.add(lblFIlterTItle);
        var flxCloseFIlter = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxCloseFIlter",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_closeFilter_b8269a64b6bd4739ac957c02cf00d487,
            "right": "30dp",
            "skin": "sknFlxBGTransCursorPointer",
            "top": "30dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "flxCloseFIlter"), extendConfig({}, controller.args[1], "flxCloseFIlter"), extendConfig({}, controller.args[2], "flxCloseFIlter"));
        flxCloseFIlter.setDefaultUnit(kony.flex.DP);
        var imgCLose = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgCLose",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "close_search.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgCLose"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgCLose"), extendConfig({}, controller.args[2], "imgCLose"));
        flxCloseFIlter.add(imgCLose);
        var lblLocationTitle = new kony.ui.Label(extendConfig({
            "id": "lblLocationTitle",
            "isVisible": false,
            "left": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88TypeBold",
            "text": "Location",
            "top": "74dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblLocationTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLocationTitle"), extendConfig({}, controller.args[2], "lblLocationTitle"));
        var txtBoxLocation = new kony.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "sknTxtBoxBGWhiteFont3d3d3dSize88Border",
            "height": "50dp",
            "id": "txtBoxLocation",
            "isVisible": false,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "30dp",
            "placeholder": "Enter a location",
            "right": "30dp",
            "secureTextEntry": false,
            "skin": "sknTxtBoxBGWhiteFont3d3d3dSize88Border",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "94dp",
            "zIndex": 1
        }, controller.args[0], "txtBoxLocation"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtBoxLocation"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTxtBoxBGWhiteFont3d3d3dSize88"
        }, controller.args[2], "txtBoxLocation"));
        var lblSupervisorTitle = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblSupervisorTitle",
            "isVisible": true,
            "left": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88TypeBold",
            "text": "Supervisor",
            "top": "75dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblSupervisorTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSupervisorTitle"), extendConfig({}, controller.args[2], "lblSupervisorTitle"));
        var lstBoxSupervisor2 = new kony.ui.ListBox(extendConfig({
            "centerX": "50%",
            "focusSkin": "defListBoxFocus",
            "height": "40dp",
            "id": "lstBoxSupervisor2",
            "isVisible": false,
            "left": "30dp",
            "right": "30dp",
            "skin": "sknListBoxBGWhiteFont3d3d3dSize88Border9a9a9a",
            "top": "155dp",
            "zIndex": 1
        }, controller.args[0], "lstBoxSupervisor2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lstBoxSupervisor2"), extendConfig({
            "multiSelect": false,
            "multiSelectRows": 2
        }, controller.args[2], "lstBoxSupervisor2"));
        var lblTrackingPoint = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblTrackingPoint",
            "isVisible": true,
            "left": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88TypeBold",
            "text": "Nominated Tracking Point",
            "top": "166dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTrackingPoint"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTrackingPoint"), extendConfig({}, controller.args[2], "lblTrackingPoint"));
        var lstBoxTrackingPoint = new kony.ui.ListBox(extendConfig({
            "focusSkin": "defListBoxFocus",
            "height": "50dp",
            "id": "lstBoxTrackingPoint",
            "isVisible": false,
            "left": "30dp",
            "onSelection": controller.AS_onSelectionOfTrackingPoints_bd1fdb6318bd4e55abd955e3405367dd,
            "right": "30dp",
            "skin": "sknListBoxBGWhiteFont3d3d3dSize88Border9a9a9a",
            "top": "196dp",
            "zIndex": 1
        }, controller.args[0], "lstBoxTrackingPoint"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lstBoxTrackingPoint"), extendConfig({
            "multiSelect": true,
            "multiSelectRows": 2
        }, controller.args[2], "lstBoxTrackingPoint"));
        var segTrackingPoint = new kony.ui.SegmentedUI2(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "data": [{
                "imgSelection": "",
                "lblTrackingPoint": ""
            }],
            "groupCells": false,
            "height": "80dp",
            "id": "segTrackingPoint",
            "isVisible": true,
            "left": "30dp",
            "needPageIndicator": true,
            "onRowClick": controller.AS_onSelectionOfTrackingPointsSegment_g6a768f8fc364f6fbffc2d40d52d6446,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "right": 30,
            "rowFocusSkin": "seg2Focus",
            "rowSkin": "Copyseg0abe691180e3044",
            "rowTemplate": "Flex0ab488ced76e94b",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_MULTI_SELECT_BEHAVIOR,
            "selectionBehaviorConfig": {
                "imageIdentifier": "imgSelection",
                "selectedStateImage": "checkbox_selected.png",
                "unselectedStateImage": "chechbox_unselected.png"
            },
            "separatorColor": "aaaaaa00",
            "separatorRequired": false,
            "separatorThickness": 1,
            "showScrollbars": true,
            "top": "195dp",
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "Flex0ab488ced76e94b": "Flex0ab488ced76e94b",
                "imgSelection": "imgSelection",
                "lblTrackingPoint": "lblTrackingPoint"
            },
            "zIndex": 1
        }, controller.args[0], "segTrackingPoint"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segTrackingPoint"), extendConfig({}, controller.args[2], "segTrackingPoint"));
        var lstBoxSupervisor = new kony.ui.ListBox(extendConfig({
            "centerX": "50%",
            "focusSkin": "defListBoxFocus",
            "height": "40dp",
            "id": "lstBoxSupervisor",
            "isVisible": true,
            "left": "30dp",
            "onSelection": controller.AS_onSelectionCallBack_f65bd1bede1e409ab54a03fe101d13b4,
            "right": 30,
            "skin": "CopydefListBoxNormal0d6ecb493aad64a",
            "top": "110dp",
            "zIndex": 1
        }, controller.args[0], "lstBoxSupervisor"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lstBoxSupervisor"), extendConfig({
            "multiSelect": false
        }, controller.args[2], "lstBoxSupervisor"));
        flxFilterRoot.add(flxFilter, flxCloseFIlter, lblLocationTitle, txtBoxLocation, lblSupervisorTitle, lstBoxSupervisor2, lblTrackingPoint, lstBoxTrackingPoint, segTrackingPoint, lstBoxSupervisor);
        flxItemContainer.add(flxSearchRoot, flxFilterRoot);
        searchnfilter.add(flxHeader, flxItemContainer);
        return searchnfilter;
    }
})
;
define('com/konysa/searchnfilter/searchnfilterConfig',[],function() {
    return {
        "properties": [{
            "name": "trackingPointsMasterData",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKey1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKeys1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "supervisorsMasterData",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKey",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedKeys",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selectedIndices",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setTrackingPointsData", "hideFilterBox", "hideSearchBox"],
        "events": ["onSelectionOfTrackingPoints", "onDoneOfTxtBoxUser", "onSelectionCallBack", "onSelectionOfTrackingPointsSegment", "closeFilter", "closeSearch"]
    }
});

define("com/konysa/tabpane/usertabpaneController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        setSkinForSelectedTab: function(selectedTab) {
            // this.view.flxTab0.skin=
            this.view.flxTab0.skin = sknFlxBGWhite;
            this.view.flxTab3.skin = sknFlxBGWhite;
            this.view.flxTab1.skin = sknFlxBGWhite;
            this.view.flxTab2.skin = sknFlxBGWhite;
            this.view.lblTitle1.skin = sknLblBGTransFont575ee7Size100;
            this.view.lblTitle2.skin = sknLblBGTransFont575ee7Size100;
            this.view.lblTitle3.skin = sknLblBGTransFont575ee7Size100;
            this.view.lblTitle0.skin = sknLblBGTransFont575ee7Size100;
            kony.print("in setSkinForSelectedTab" + selectedTab);
            if (selectedTab == "Live") {
                kony.print("on Live Tap");
                this.view.flxTab1.skin = sknFlxBgBlue;
                this.view.lblTitle1.skin = sknLblWhite100;
            }
            if (selectedTab == "Incident") {
                this.view.flxTab2.skin = sknFlxBgBlue;
                this.view.lblTitle2.skin = sknLblWhite100;
            }
            if (selectedTab == "Delay") {
                this.view.flxTab3.skin = sknFlxBgBlue;
                this.view.lblTitle3.skin = sknLblWhite100;
            }
            if (selectedTab == "All") {
                this.view.flxTab0.skin = sknFlxBgBlue;
                this.view.lblTitle0.skin = sknLblWhite100;
            }
            // kony.print("hi..")
            // this.view.flxTab3.skin=
        }
    };
});
define("com/konysa/tabpane/tabpaneControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/konysa/tabpane/tabpaneController", ["com/konysa/tabpane/usertabpaneController", "com/konysa/tabpane/tabpaneControllerActions"], function() {
    var controller = require("com/konysa/tabpane/usertabpaneController");
    var actions = require("com/konysa/tabpane/tabpaneControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "skin1", function(val) {
            this.view.flxTab1.skin = val;
        });
        defineGetter(this, "skin1", function() {
            return this.view.flxTab1.skin;
        });
        defineSetter(this, "skin2", function(val) {
            this.view.flxTab2.skin = val;
        });
        defineGetter(this, "skin2", function() {
            return this.view.flxTab2.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_allTabOnClick_e8e0671bac0c49349cfd9f6c0f57c516 = function() {
        if (this.allTabOnClick) {
            this.allTabOnClick.apply(this, arguments);
        }
    }
    controller.AS_liveTabOnClick_f685eff09ef44976a4c4259f6d8fa9ad = function() {
        if (this.liveTabOnClick) {
            this.liveTabOnClick.apply(this, arguments);
        }
    }
    controller.AS_incidentTabOnClick_f9468c8115ce4897a19e140f363cdd2c = function() {
        if (this.incidentTabOnClick) {
            this.incidentTabOnClick.apply(this, arguments);
        }
    }
    controller.AS_delayTabOnClick_d1335aff64804c12a908053a605f69c6 = function() {
        if (this.delayTabOnClick) {
            this.delayTabOnClick.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/tabpane/tabpane',[],function() {
    return function(controller) {
        var tabpane = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "tabpane",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBgWhiteBorder575ee7",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "tabpane"), extendConfig({}, controller.args[1], "tabpane"), extendConfig({}, controller.args[2], "tabpane"));
        tabpane.setDefaultUnit(kony.flex.DP);
        var flxTab0 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "12.50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTab0",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_allTabOnClick_e8e0671bac0c49349cfd9f6c0f57c516,
            "skin": "sknFlxBG575ee7LeftBorder",
            "width": "25%",
            "zIndex": 1
        }, controller.args[0], "flxTab0"), extendConfig({}, controller.args[1], "flxTab0"), extendConfig({}, controller.args[2], "flxTab0"));
        flxTab0.setDefaultUnit(kony.flex.DP);
        var lblTitle0 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblTitle0",
            "isVisible": true,
            "skin": "sknLblWhite100",
            "text": "All",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle0"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle0"), extendConfig({}, controller.args[2], "lblTitle0"));
        flxTab0.add(lblTitle0);
        var lblSeparator0 = new kony.ui.Label(extendConfig({
            "centerX": "25%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblSeparator0",
            "isVisible": true,
            "left": 1,
            "skin": "sknLblBG575ee7",
            "width": "1dp",
            "zIndex": 3
        }, controller.args[0], "lblSeparator0"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSeparator0"), extendConfig({}, controller.args[2], "lblSeparator0"));
        var flxTab1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "37.50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTab1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_liveTabOnClick_f685eff09ef44976a4c4259f6d8fa9ad,
            "skin": "CopyslFbox0caa2ab09086647",
            "width": "25%",
            "zIndex": 1
        }, controller.args[0], "flxTab1"), extendConfig({}, controller.args[1], "flxTab1"), extendConfig({}, controller.args[2], "flxTab1"));
        flxTab1.setDefaultUnit(kony.flex.DP);
        var lblTitle1 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblTitle1",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknLblBGTransFont575ee7Size100",
            "text": "Live",
            "textStyle": {},
            "top": "540dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle1"), extendConfig({}, controller.args[2], "lblTitle1"));
        flxTab1.add(lblTitle1);
        var lblSeparator1 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblSeparator1",
            "isVisible": true,
            "left": 1,
            "skin": "sknLblBG575ee7",
            "width": "1dp",
            "zIndex": 3
        }, controller.args[0], "lblSeparator1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSeparator1"), extendConfig({}, controller.args[2], "lblSeparator1"));
        var flxTab2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTab2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "50%",
            "isModalContainer": false,
            "onClick": controller.AS_incidentTabOnClick_f9468c8115ce4897a19e140f363cdd2c,
            "skin": "CopyslFbox0h3725d816f5a41",
            "width": "25%",
            "zIndex": 1
        }, controller.args[0], "flxTab2"), extendConfig({}, controller.args[1], "flxTab2"), extendConfig({}, controller.args[2], "flxTab2"));
        flxTab2.setDefaultUnit(kony.flex.DP);
        var lblTitle2 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblTitle2",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknLblBGTransFont575ee7Size100",
            "text": "Incidents",
            "textStyle": {},
            "top": "540dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle2"), extendConfig({}, controller.args[2], "lblTitle2"));
        flxTab2.add(lblTitle2);
        var flxTab3 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTab3",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "75%",
            "isModalContainer": false,
            "onClick": controller.AS_delayTabOnClick_d1335aff64804c12a908053a605f69c6,
            "skin": "sknFlxBG575ee7RightBorder",
            "width": "25%",
            "zIndex": 1
        }, controller.args[0], "flxTab3"), extendConfig({}, controller.args[1], "flxTab3"), extendConfig({}, controller.args[2], "flxTab3"));
        flxTab3.setDefaultUnit(kony.flex.DP);
        var lblTitle3 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblTitle3",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknLblBGTransFont575ee7Size100",
            "text": "Delays",
            "textStyle": {},
            "top": "540dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle3"), extendConfig({}, controller.args[2], "lblTitle3"));
        flxTab3.add(lblTitle3);
        var lblSeparator2 = new kony.ui.Label(extendConfig({
            "centerX": "75%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblSeparator2",
            "isVisible": true,
            "skin": "sknLblBG575ee7",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "lblSeparator2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSeparator2"), extendConfig({}, controller.args[2], "lblSeparator2"));
        tabpane.add(flxTab0, lblSeparator0, flxTab1, lblSeparator1, flxTab2, flxTab3, lblSeparator2);
        return tabpane;
    }
})
;
define('com/konysa/tabpane/tabpaneConfig',[],function() {
    return {
        "properties": [{
            "name": "skin1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "skin2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setSkinForSelectedTab"],
        "events": ["allTabOnClick", "liveTabOnClick", "incidentTabOnClick", "delayTabOnClick"]
    }
});

define("com/konysa/terminateJourney/userterminateJourneyController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        initGettersSetters: function() {},
        dismissAlert: function() {},
        componentPreShow: function() {
            /*var MasterDataForListBox = [];
            var ResponseFromCheckInInterval = (GetResponseFromDatabaseWhereClause(CHECKIN_INTERVAL_MASTER_TBL_GLOBAL, null, null));
            if(ResponseFromCheckInInterval !== null && ResponseFromCheckInInterval!==undefined && ResponseFromCheckInInterval.length>0)
            {
              ResponseFromCheckInInterval.forEach(function(item){
                MasterDataForListBox.push({"mykey":parseInt(item.checkin_interval_row_id_pk),"myvalue":parseInt(item.checkin_interval_minutes),"accessibilityConfig":{}});
              });
              this.view.lstTimeCheckins.masterDataMap = [MasterDataForListBox,"mykey","myvalue"];
            }
            else
            {
              alert("No Data");
            }*/
        }
    };
});
define("com/konysa/terminateJourney/terminateJourneyControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for terminateJourney **/
    AS_FlexContainer_a1d0ec87ac1d4127bb530f44b92a52c1: function AS_FlexContainer_a1d0ec87ac1d4127bb530f44b92a52c1(eventobject) {
        var self = this;
        debugger;
        try {
            this.componentPreShow();
        } catch (err) {
            alert(err.message);
        }
    }
});
define("com/konysa/terminateJourney/terminateJourneyController", ["com/konysa/terminateJourney/userterminateJourneyController", "com/konysa/terminateJourney/terminateJourneyControllerActions"], function() {
    var controller = require("com/konysa/terminateJourney/userterminateJourneyController");
    var actions = require("com/konysa/terminateJourney/terminateJourneyControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "HeaderText", function(val) {
            this.view.lblHeaderText.text = val;
        });
        defineGetter(this, "HeaderText", function() {
            return this.view.lblHeaderText.text;
        });
        defineSetter(this, "DescriptionText", function(val) {
            this.view.lblBody.text = val;
        });
        defineGetter(this, "DescriptionText", function() {
            return this.view.lblBody.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_OnClickOfTerminateJourneyConform_gb447be90b5844299bc0a8ec4e295a97 = function() {
        if (this.OnClickOfTerminateJourneyConform) {
            this.OnClickOfTerminateJourneyConform.apply(this, arguments);
        }
    }
    controller.AS_onClickOfTerminateJourneyCancel_g3ad4ade08ea492f9a8f4b468c8f6ef6 = function() {
        if (this.onClickOfTerminateJourneyCancel) {
            this.onClickOfTerminateJourneyCancel.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/terminateJourney/terminateJourney',[],function() {
    return function(controller) {
        var terminateJourney = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "terminateJourney",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_a1d0ec87ac1d4127bb530f44b92a52c1(eventobject);
            },
            "skin": "CopyCopyflxBackgroundAlertSkn1",
            "top": "0%",
            "width": "100%"
        }, controller.args[0], "terminateJourney"), extendConfig({}, controller.args[1], "terminateJourney"), extendConfig({}, controller.args[2], "terminateJourney"));
        terminateJourney.setDefaultUnit(kony.flex.DP);
        var alertFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "332px",
            "id": "alertFlex",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "isModalContainer": false,
            "skin": "CopyCopyalertSkin1",
            "width": "530px",
            "zIndex": 1
        }, controller.args[0], "alertFlex"), extendConfig({}, controller.args[1], "alertFlex"), extendConfig({}, controller.args[2], "alertFlex"));
        alertFlex.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "60dp",
            "width": "230px",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var lblHeaderText = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblHeaderText",
            "isVisible": true,
            "skin": "CopyCopyCopydefLabel0e25d88b557834f",
            "text": "Close Journey?",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblHeaderText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHeaderText"), extendConfig({}, controller.args[2], "lblHeaderText"));
        flxHeader.add(lblHeaderText);
        var flexShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "1dp",
            "id": "flexShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyCopyCopyslFbox0h072b0f654cd4b",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flexShadow"), extendConfig({}, controller.args[1], "flexShadow"), extendConfig({}, controller.args[2], "flexShadow"));
        flexShadow.setDefaultUnit(kony.flex.DP);
        flexShadow.add();
        var flxBody = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100dp",
            "id": "flxBody",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "380dp",
            "zIndex": 1
        }, controller.args[0], "flxBody"), extendConfig({}, controller.args[1], "flxBody"), extendConfig({}, controller.args[2], "flxBody"));
        flxBody.setDefaultUnit(kony.flex.DP);
        var lblBody = new kony.ui.Label(extendConfig({
            "height": "60dp",
            "id": "lblBody",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopyCopydefLabel0cef3a211bdb545",
            "text": "Closing the journey will change it’s status to Completed and you will no longer see it on the map.",
            "textStyle": {},
            "top": 0,
            "width": "410px",
            "zIndex": 1
        }, controller.args[0], "lblBody"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBody"), extendConfig({}, controller.args[2], "lblBody"));
        flxBody.add(lblBody);
        var FlexContainer0hffade4a9c214a = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "FlexContainer0hffade4a9c214a",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "60dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "380dp",
            "zIndex": 1
        }, controller.args[0], "FlexContainer0hffade4a9c214a"), extendConfig({
            "retainFlowHorizontalAlignment": false
        }, controller.args[1], "FlexContainer0hffade4a9c214a"), extendConfig({}, controller.args[2], "FlexContainer0hffade4a9c214a"));
        FlexContainer0hffade4a9c214a.setDefaultUnit(kony.flex.DP);
        var btnCheckIn = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "focusSkin": "CopyCopybtnPressed1",
            "height": "44dp",
            "id": "btnCheckIn",
            "isVisible": true,
            "left": "220px",
            "onClick": controller.AS_OnClickOfTerminateJourneyConform_gb447be90b5844299bc0a8ec4e295a97,
            "skin": "CopyCopybtnPressed1",
            "text": "Confirm",
            "top": "10%",
            "width": "162px",
            "zIndex": 10
        }, controller.args[0], "btnCheckIn"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnCheckIn"), extendConfig({}, controller.args[2], "btnCheckIn"));
        var btnCancel = new kony.ui.Button(extendConfig({
            "bottom": "5%",
            "focusSkin": "CopyCopybtnPressed1",
            "height": "44dp",
            "id": "btnCancel",
            "isVisible": true,
            "left": "0px",
            "onClick": controller.AS_onClickOfTerminateJourneyCancel_g3ad4ade08ea492f9a8f4b468c8f6ef6,
            "skin": "CopyCopybtnPressed1",
            "text": "Cancel",
            "top": "10%",
            "width": "162px",
            "zIndex": 10
        }, controller.args[0], "btnCancel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnCancel"), extendConfig({}, controller.args[2], "btnCancel"));
        FlexContainer0hffade4a9c214a.add(btnCheckIn, btnCancel);
        alertFlex.add(flxHeader, flexShadow, flxBody, FlexContainer0hffade4a9c214a);
        terminateJourney.add(alertFlex);
        return terminateJourney;
    }
})
;
define('com/konysa/terminateJourney/terminateJourneyConfig',[],function() {
    return {
        "properties": [{
            "name": "HeaderText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "DescriptionText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["OnClickOfTerminateJourneyConform", "onClickOfTerminateJourneyCancel", "dismissAlert", "componentPreShow"]
    }
});

define("com/konymp/Passenger/userPassengerController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/konymp/Passenger/PassengerControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/konymp/Passenger/PassengerController", ["com/konymp/Passenger/userPassengerController", "com/konymp/Passenger/PassengerControllerActions"], function() {
    var controller = require("com/konymp/Passenger/userPassengerController");
    var actions = require("com/konymp/Passenger/PassengerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "headertext", function(val) {
            this.view.PassengerName.headertext = val;
        });
        defineGetter(this, "headertext", function() {
            return this.view.PassengerName.headertext;
        });
        defineSetter(this, "text", function(val) {
            this.view.PassengerName.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.PassengerName.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onTouchEndImageClose_hd07846acf074989b64aeb7535e1016e = function() {
        if (this.onTouchEndImageClose) {
            this.onTouchEndImageClose.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konymp/Passenger/Passenger',[],function() {
    return function(controller) {
        var Passenger = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "240dp",
            "id": "Passenger",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "Passenger"), extendConfig({}, controller.args[1], "Passenger"), extendConfig({}, controller.args[2], "Passenger"));
        Passenger.setDefaultUnit(kony.flex.DP);
        var CopyflxHorizontalLineAccount0cf0cf55ca3c54c = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "2dp",
            "id": "CopyflxHorizontalLineAccount0cf0cf55ca3c54c",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0e40c0ab8c83441",
            "top": 24,
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "CopyflxHorizontalLineAccount0cf0cf55ca3c54c"), extendConfig({}, controller.args[1], "CopyflxHorizontalLineAccount0cf0cf55ca3c54c"), extendConfig({}, controller.args[2], "CopyflxHorizontalLineAccount0cf0cf55ca3c54c"));
        CopyflxHorizontalLineAccount0cf0cf55ca3c54c.setDefaultUnit(kony.flex.DP);
        var Image0h1efb044dd5f44 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "Image0h1efb044dd5f44",
            "isVisible": true,
            "skin": "slImage",
            "src": "separator.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "Image0h1efb044dd5f44"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0h1efb044dd5f44"), extendConfig({}, controller.args[2], "Image0h1efb044dd5f44"));
        CopyflxHorizontalLineAccount0cf0cf55ca3c54c.add(Image0h1efb044dd5f44);
        var FlexGroup0c013172d84a546 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "FlexGroup0c013172d84a546",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": kony.flex.USE_PREFFERED_SIZE
        }, controller.args[0], "FlexGroup0c013172d84a546"), extendConfig({}, controller.args[1], "FlexGroup0c013172d84a546"), extendConfig({}, controller.args[2], "FlexGroup0c013172d84a546"));
        FlexGroup0c013172d84a546.setDefaultUnit(kony.flex.DP);
        var CopyLabel0gfb5fd3ede4a43 = new kony.ui.Label(extendConfig({
            "bottom": "10dp",
            "id": "CopyLabel0gfb5fd3ede4a43",
            "isVisible": true,
            "left": "9dp",
            "skin": "CopydefLabel0a584c56e90da4b",
            "text": "Passenger",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "CopyLabel0gfb5fd3ede4a43"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyLabel0gfb5fd3ede4a43"), extendConfig({}, controller.args[2], "CopyLabel0gfb5fd3ede4a43"));
        var imgClose = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "imgClose",
            "isVisible": true,
            "left": "250dp",
            "onTouchEnd": controller.AS_onTouchEndImageClose_hd07846acf074989b64aeb7535e1016e,
            "skin": "slImage",
            "src": "crossimageblue.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgClose"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgClose"), extendConfig({}, controller.args[2], "imgClose"));
        var CopyImage0a44b9d92d77647 = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "CopyImage0a44b9d92d77647",
            "isVisible": true,
            "left": "250dp",
            "skin": "slImage",
            "src": "crossimageblue.png",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "CopyImage0a44b9d92d77647"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "CopyImage0a44b9d92d77647"), extendConfig({}, controller.args[2], "CopyImage0a44b9d92d77647"));
        FlexGroup0c013172d84a546.add(CopyLabel0gfb5fd3ede4a43, imgClose, CopyImage0a44b9d92d77647);
        var PassengerName = new com.konymp.HeaderEntry(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "PassengerName",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "100%",
            "overrides": {
                "Label0c042960debc142": {
                    "text": "Name"
                },
                "HeaderEntry": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "PassengerName"), extendConfig({
            "overrides": {}
        }, controller.args[1], "PassengerName"), extendConfig({
            "overrides": {}
        }, controller.args[2], "PassengerName"));
        PassengerName.onTouchEnd = controller.AS_onTouchEndImageClose_hd07846acf074989b64aeb7535e1016e;
        var PassengerPhone = new com.konymp.HeaderEntry(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "PassengerPhone",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0",
            "width": "100%",
            "overrides": {
                "Label0c042960debc142": {
                    "text": "Mobile"
                },
                "HeaderEntry": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "PassengerPhone"), extendConfig({
            "overrides": {}
        }, controller.args[1], "PassengerPhone"), extendConfig({
            "overrides": {}
        }, controller.args[2], "PassengerPhone"));
        PassengerPhone.onTouchEnd = controller.AS_onTouchEndImageClose_hd07846acf074989b64aeb7535e1016e;
        Passenger.add(CopyflxHorizontalLineAccount0cf0cf55ca3c54c, FlexGroup0c013172d84a546, PassengerName, PassengerPhone);
        return Passenger;
    }
})
;
define('com/konymp/Passenger/PassengerConfig',[],function() {
    return {
        "properties": [{
            "name": "headertext",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onTouchEndImageClose"]
    }
});

define("com/konysa/journeydetail/userjourneydetailController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        /*  onPreShowOfJourneyDetails : function()
          {
            
           // this.view.pathinfo.setWidgetDataMapTOSegment();
            
          },*/
        onJourneyBack: function() {
            debugger;
            if (typeof this.onBackClick == 'function') {
                var param = {};
                this.onBackClick(param);
            }
        },
        setDataToWidgets: function(dataObject, segCheckPointsDataForPath, vehicleDetails, passengerdetails, incidentDetails) {
            kony.print("in setDataToWidgets ::" + JSON.stringify(segCheckPointsDataForPath));
            if (dataObject !== null && dataObject.length !== 0) {
                this.view.lblJourneyId.text = dataObject["journeyId"];
                this.view.lblDriver.text = dataObject["driverName"];
                this.view.lblDriverName.text = dataObject["driverName"];
                this.view.lblStatus.text = dataObject["journeyStatus"]["text"];
                this.view.lblStatus.skin = dataObject["journeyStatus"]["skin"];
                this.view.lblTrackingPointName.text = dataObject["journeyTrackingpointName"];
                this.view.lblSupervisorNameVal.text = dataObject["superviserName"];
                if (dataObject["journeyStatus"]["text"] == "incident Reported") {
                    this.view.emergencydetails.setEmergencyDetails(dataObject);
                    this.view.emergencydetails.isVisible = true;
                    this.view.lblDivider0.isVisible = true;
                } else {
                    this.view.emergencydetails.isVisible = false;
                    this.view.lblDivider0.isVisible = false;
                }
            }
            //  segCheckPointsDataForPath=[];
            debugger;
            this.view.pathinfo.setCheckPointsDataToSegment(segCheckPointsDataForPath);
            if (vehicleDetails == null || vehicleDetails == "" || vehicleDetails == undefined) {
                this.view.lblVechileColorNameVal.text = "";
                this.view.lblVechilePlateNumberVal.text = "";
                this.view.lblVechileNameList.text = "";
            } else {
                this.view.lblVechileColorNameVal.text = vehicleDetails["vehicle_color"];
                this.view.lblVechilePlateNumberVal.text = vehicleDetails["vehicle_reg_num"];
                this.view.lblVechileNameList.text = vehicleDetails["vehicle_make"] + "," + vehicleDetails["vehicle_model"];
            }
            kony.print("passengerdetails.length " + passengerdetails.length);
            if (passengerdetails.length != 0) this.view.lblPassengerName.text = passengerdetails[0]["passenger_name"];
            else this.view.lblPassengerName.text = "";
        },
        onClickOfChangeETA: function() {
            kony.print("onClickOfChangeETA ");
            var param = {};
            this.actionOfChangeETABtn(param);
        },
        onClickOfCloseJourney: function() {
            kony.print("onClickOfCloseJourney ");
            var param = {};
            this.actionOfCloseJourneyBtn(param);
        },
        updateJourneyStatusOnJourneyDetailsUI: function(journeyStatus) {
            this.view.lblStatus.text = journeyStatus;
        },
        setVisibilityOfActionFlex: function(journeyStatus) {
            if (journeyStatus == "Completed" || journeyStatus == "completed" || journeyStatus == "Not Started" || journeyStatus == "terminated" || journeyStatus == "Terminated") {
                this.view.flxNormalRoot.setVisibility(false);
            } else {
                this.view.flxNormalRoot.setVisibility(true);
            }
            this.view.pathinfo.setFlxActionVisibility_pathInfo(journeyStatus);
        },
        OnClickOfflxEmergencyActionBtn: function() {
            kony.print("on click of OnClickOfflxEmergencyActionBtn");
            var param = {};
            this.actionOfEmergencyBtn(param);
        }
    };
});
define("com/konysa/journeydetail/journeydetailControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxBack **/
    AS_FlexContainer_d2797097496a40b9ba02b89a5c285d8b: function AS_FlexContainer_d2797097496a40b9ba02b89a5c285d8b(eventobject) {
        var self = this;
        return self.onJourneyBack.call(this);
    }
});
define("com/konysa/journeydetail/journeydetailController", ["com/konysa/journeydetail/userjourneydetailController", "com/konysa/journeydetail/journeydetailControllerActions"], function() {
    var controller = require("com/konysa/journeydetail/userjourneydetailController");
    var actions = require("com/konysa/journeydetail/journeydetailControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickOfCreateCheckInBtn_be8d6740b04646a6b4e378afdaa9a9d7 = function() {
        if (this.onClickOfCreateCheckInBtn) {
            this.onClickOfCreateCheckInBtn.apply(this, arguments);
        }
    }
    return controller;
});

define('com/konysa/journeydetail/journeydetail',[],function() {
    return function(controller) {
        var journeydetail = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "journeydetail",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "journeydetail"), extendConfig({}, controller.args[1], "journeydetail"), extendConfig({}, controller.args[2], "journeydetail"));
        journeydetail.setDefaultUnit(kony.flex.DP);
        var flxDetailsRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "blur": {
                "enabled": false,
                "value": 0
            },
            "centerX": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxDetailsRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxDetailsRoot"), extendConfig({}, controller.args[1], "flxDetailsRoot"), extendConfig({}, controller.args[2], "flxDetailsRoot"));
        flxDetailsRoot.setDefaultUnit(kony.flex.DP);
        var flxTitle = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "20dp",
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": 0,
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxTitle"), extendConfig({}, controller.args[1], "flxTitle"), extendConfig({}, controller.args[2], "flxTitle"));
        flxTitle.setDefaultUnit(kony.flex.DP);
        var flxBack = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxBack",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_d2797097496a40b9ba02b89a5c285d8b,
            "skin": "sknFlxBGTransCursorPointer",
            "top": "0dp",
            "width": "130dp",
            "zIndex": 1
        }, controller.args[0], "flxBack"), extendConfig({}, controller.args[1], "flxBack"), extendConfig({
            "hoverSkin": "sknFlxBGTransCursorPointer"
        }, controller.args[2], "flxBack"));
        flxBack.setDefaultUnit(kony.flex.DP);
        var imgBack = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "15dp",
            "id": "imgBack",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "left_arrow.png",
            "top": "5dp",
            "width": "15dp",
            "zIndex": 1
        }, controller.args[0], "imgBack"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBack"), extendConfig({}, controller.args[2], "imgBack"));
        var lblTitleVal = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblTitleVal",
            "isVisible": true,
            "left": "23dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Back to Journeys",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitleVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitleVal"), extendConfig({}, controller.args[2], "lblTitleVal"));
        flxBack.add(imgBack, lblTitleVal);
        flxTitle.add(flxBack);
        var flxNameNStatus = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "22dp",
            "id": "flxNameNStatus",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "30dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxNameNStatus"), extendConfig({}, controller.args[1], "flxNameNStatus"), extendConfig({}, controller.args[2], "flxNameNStatus"));
        flxNameNStatus.setDefaultUnit(kony.flex.DP);
        var lblDriver = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblDriver",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont545963Size113",
            "text": "John Doe",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDriver"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDriver"), extendConfig({}, controller.args[2], "lblDriver"));
        var lblStatus = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblStatus",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknLblBGC96866FontWhiteSize75Border6",
            "text": "Incident Reported",
            "top": "-1dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblStatus"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 3, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblStatus"), extendConfig({}, controller.args[2], "lblStatus"));
        flxNameNStatus.add(lblDriver, lblStatus);
        var flxScDetailRoot = new kony.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bottom": "10dp",
            "bounces": true,
            "clipBounds": true,
            "enableScrolling": true,
            "horizontalScrollIndicator": true,
            "id": "flxScDetailRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "pagingEnabled": false,
            "right": "-17dp",
            "scrollDirection": kony.flex.SCROLL_VERTICAL,
            "skin": "slFSbox",
            "top": "67dp",
            "verticalScrollIndicator": true,
            "zIndex": 1
        }, controller.args[0], "flxScDetailRoot"), extendConfig({}, controller.args[1], "flxScDetailRoot"), extendConfig({}, controller.args[2], "flxScDetailRoot"));
        flxScDetailRoot.setDefaultUnit(kony.flex.DP);
        var flxNormalRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "59dp",
            "id": "flxNormalRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxNormalRoot"), extendConfig({}, controller.args[1], "flxNormalRoot"), extendConfig({}, controller.args[2], "flxNormalRoot"));
        flxNormalRoot.setDefaultUnit(kony.flex.DP);
        var flxSendNotification = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxSendNotification",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickOfCreateCheckInBtn_be8d6740b04646a6b4e378afdaa9a9d7,
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "154dp",
            "zIndex": 1
        }, controller.args[0], "flxSendNotification"), extendConfig({}, controller.args[1], "flxSendNotification"), extendConfig({}, controller.args[2], "flxSendNotification"));
        flxSendNotification.setDefaultUnit(kony.flex.DP);
        var lblSendNotification = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblSendNotification",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Manual Check-In",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSendNotification"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSendNotification"), extendConfig({}, controller.args[2], "lblSendNotification"));
        flxSendNotification.add(lblSendNotification);
        var flxContactDriver = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxContactDriver",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknFlxBGTransCursorPointerBorder5769ea",
            "top": "0dp",
            "width": "154dp",
            "zIndex": 1
        }, controller.args[0], "flxContactDriver"), extendConfig({}, controller.args[1], "flxContactDriver"), extendConfig({}, controller.args[2], "flxContactDriver"));
        flxContactDriver.setDefaultUnit(kony.flex.DP);
        var lblContactDriver = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblContactDriver",
            "isVisible": true,
            "skin": "sknLblBGTransFont575ee7Size100TypeRegular",
            "text": "Contact Driver",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblContactDriver"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContactDriver"), extendConfig({}, controller.args[2], "lblContactDriver"));
        flxContactDriver.add(lblContactDriver);
        var lblDivider2 = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider2",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider2"), extendConfig({}, controller.args[2], "lblDivider2"));
        flxNormalRoot.add(flxSendNotification, flxContactDriver, lblDivider2);
        var lblJourneyId = new kony.ui.Label(extendConfig({
            "id": "lblJourneyId",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont545963Size113",
            "text": "100-FR-EM-0048_19",
            "top": "18dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblJourneyId"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblJourneyId"), extendConfig({}, controller.args[2], "lblJourneyId"));
        var flxEmergencyRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxEmergencyRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxEmergencyRoot"), extendConfig({}, controller.args[1], "flxEmergencyRoot"), extendConfig({}, controller.args[2], "flxEmergencyRoot"));
        flxEmergencyRoot.setDefaultUnit(kony.flex.DP);
        var lblDivider0 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider0",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider0"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider0"), extendConfig({}, controller.args[2], "lblDivider0"));
        var emergencydetails = new com.konysa.emergencydetails(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "emergencydetails",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "right": "16dp",
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "overrides": {
                "emergencydetails": {
                    "bottom": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "emergencydetails"), extendConfig({
            "overrides": {}
        }, controller.args[1], "emergencydetails"), extendConfig({
            "overrides": {}
        }, controller.args[2], "emergencydetails"));
        emergencydetails.OnClickOfflxEmergencyAction = controller.AS_UWI_i780bdde6bca4dd8933ef927644758f4;
        emergencydetails.onClick = controller.AS_onClickOfCreateCheckInBtn_be8d6740b04646a6b4e378afdaa9a9d7;
        var lblDivider1 = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider1",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider1"), extendConfig({}, controller.args[2], "lblDivider1"));
        flxEmergencyRoot.add(lblDivider0, emergencydetails, lblDivider1);
        var flxPathInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxPathInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxPathInfo"), extendConfig({}, controller.args[1], "flxPathInfo"), extendConfig({}, controller.args[2], "flxPathInfo"));
        flxPathInfo.setDefaultUnit(kony.flex.DP);
        var pathinfo = new com.konysa.pathinfo(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "pathinfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "right": "20dp",
            "skin": "slFbox",
            "top": "0dp",
            "overrides": {
                "pathinfo": {
                    "bottom": "viz.val_cleared",
                    "width": "viz.val_cleared",
                    "height": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "pathinfo"), extendConfig({
            "overrides": {}
        }, controller.args[1], "pathinfo"), extendConfig({
            "overrides": {}
        }, controller.args[2], "pathinfo"));
        pathinfo.onClickOfChangeETA = controller.AS_UWI_bd315931426b4cc398c626ceaf08bfce;
        pathinfo.onClickOfCloseJourney = controller.AS_UWI_da097b7343a348a6ab201b739e5790d9;
        pathinfo.onClick = controller.AS_onClickOfCreateCheckInBtn_be8d6740b04646a6b4e378afdaa9a9d7;
        flxPathInfo.add(pathinfo);
        var lblDivider3 = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider3",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "24dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider3"), extendConfig({}, controller.args[2], "lblDivider3"));
        var flxDriverPassengerDetail = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxDriverPassengerDetail",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxDriverPassengerDetail"), extendConfig({}, controller.args[1], "flxDriverPassengerDetail"), extendConfig({}, controller.args[2], "flxDriverPassengerDetail"));
        flxDriverPassengerDetail.setDefaultUnit(kony.flex.DP);
        var lblPassengersInfo = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblPassengersInfo",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont3d3d3dSize100TypeBold",
            "text": "Passengers Information",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPassengersInfo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPassengersInfo"), extendConfig({}, controller.args[2], "lblPassengersInfo"));
        var lblDriverNameTitle = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblDriverNameTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Driver",
            "top": "49dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDriverNameTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDriverNameTitle"), extendConfig({}, controller.args[2], "lblDriverNameTitle"));
        var lblDriverName = new kony.ui.Label(extendConfig({
            "id": "lblDriverName",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "John Green",
            "top": "69dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDriverName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDriverName"), extendConfig({}, controller.args[2], "lblDriverName"));
        var lblPassengerNameTitle = new kony.ui.Label(extendConfig({
            "id": "lblPassengerNameTitle",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Passenger",
            "top": "49dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblPassengerNameTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPassengerNameTitle"), extendConfig({}, controller.args[2], "lblPassengerNameTitle"));
        var lblPassengerName = new kony.ui.Label(extendConfig({
            "id": "lblPassengerName",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "James Ford",
            "top": "69dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblPassengerName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPassengerName"), extendConfig({}, controller.args[2], "lblPassengerName"));
        flxDriverPassengerDetail.add(lblPassengersInfo, lblDriverNameTitle, lblDriverName, lblPassengerNameTitle, lblPassengerName);
        var lblDivider4 = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider4",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider4"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider4"), extendConfig({}, controller.args[2], "lblDivider4"));
        var flxTrackingInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxTrackingInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxTrackingInfo"), extendConfig({}, controller.args[1], "flxTrackingInfo"), extendConfig({}, controller.args[2], "flxTrackingInfo"));
        flxTrackingInfo.setDefaultUnit(kony.flex.DP);
        var lblTrackingInfoTitle = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblTrackingInfoTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont3d3d3dSize100TypeBold",
            "text": "Tracking Information",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTrackingInfoTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTrackingInfoTitle"), extendConfig({}, controller.args[2], "lblTrackingInfoTitle"));
        var lblTrackingPointTitle = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblTrackingPointTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Tracking Point",
            "top": "49dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTrackingPointTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTrackingPointTitle"), extendConfig({}, controller.args[2], "lblTrackingPointTitle"));
        var lblTrackingPointName = new kony.ui.Label(extendConfig({
            "id": "lblTrackingPointName",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Exploration",
            "top": "69dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTrackingPointName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTrackingPointName"), extendConfig({}, controller.args[2], "lblTrackingPointName"));
        var lblSupervisorNameTitle = new kony.ui.Label(extendConfig({
            "id": "lblSupervisorNameTitle",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Supervisor",
            "top": "49dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblSupervisorNameTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSupervisorNameTitle"), extendConfig({}, controller.args[2], "lblSupervisorNameTitle"));
        var lblSupervisorNameVal = new kony.ui.Label(extendConfig({
            "id": "lblSupervisorNameVal",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Alex Davis",
            "top": "69dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblSupervisorNameVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSupervisorNameVal"), extendConfig({}, controller.args[2], "lblSupervisorNameVal"));
        flxTrackingInfo.add(lblTrackingInfoTitle, lblTrackingPointTitle, lblTrackingPointName, lblSupervisorNameTitle, lblSupervisorNameVal);
        var lblDivider5 = new kony.ui.Label(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "1dp",
            "id": "lblDivider5",
            "isVisible": true,
            "skin": "tmp",
            "text": "Label",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDivider5"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDivider5"), extendConfig({}, controller.args[2], "lblDivider5"));
        var flxVechileInfo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "180dp",
            "id": "flxVechileInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxVechileInfo"), extendConfig({}, controller.args[1], "flxVechileInfo"), extendConfig({}, controller.args[2], "flxVechileInfo"));
        flxVechileInfo.setDefaultUnit(kony.flex.DP);
        var lblVechileInfo = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblVechileInfo",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBgTransFont3d3d3dSize100TypeBold",
            "text": "Vehicle Information",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVechileInfo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechileInfo"), extendConfig({}, controller.args[2], "lblVechileInfo"));
        var lblVechileTitle = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblVechileTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Vehicle",
            "top": "49dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVechileTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechileTitle"), extendConfig({}, controller.args[2], "lblVechileTitle"));
        var lblVechileNameList = new kony.ui.Label(extendConfig({
            "id": "lblVechileNameList",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Ford, Focus",
            "top": "69dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVechileNameList"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechileNameList"), extendConfig({}, controller.args[2], "lblVechileNameList"));
        var lblVechilePlateNumber = new kony.ui.Label(extendConfig({
            "id": "lblVechilePlateNumber",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Plate Number",
            "top": "49dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblVechilePlateNumber"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechilePlateNumber"), extendConfig({}, controller.args[2], "lblVechilePlateNumber"));
        var lblVechilePlateNumberVal = new kony.ui.Label(extendConfig({
            "id": "lblVechilePlateNumberVal",
            "isVisible": true,
            "right": "40dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "345226",
            "top": "69dp",
            "width": "105dp",
            "zIndex": 1
        }, controller.args[0], "lblVechilePlateNumberVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechilePlateNumberVal"), extendConfig({}, controller.args[2], "lblVechilePlateNumberVal"));
        var lblVechileColorTitle = new kony.ui.Label(extendConfig({
            "height": "16dp",
            "id": "lblVechileColorTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont6a6a6aSize88",
            "text": "Vehicle Color",
            "top": "108dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVechileColorTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechileColorTitle"), extendConfig({}, controller.args[2], "lblVechileColorTitle"));
        var lblVechileColorNameVal = new kony.ui.Label(extendConfig({
            "id": "lblVechileColorNameVal",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize100",
            "text": "Brown",
            "top": "128dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVechileColorNameVal"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVechileColorNameVal"), extendConfig({}, controller.args[2], "lblVechileColorNameVal"));
        flxVechileInfo.add(lblVechileInfo, lblVechileTitle, lblVechileNameList, lblVechilePlateNumber, lblVechilePlateNumberVal, lblVechileColorTitle, lblVechileColorNameVal);
        flxScDetailRoot.add(flxNormalRoot, lblJourneyId, flxEmergencyRoot, flxPathInfo, lblDivider3, flxDriverPassengerDetail, lblDivider4, flxTrackingInfo, lblDivider5, flxVechileInfo);
        flxDetailsRoot.add(flxTitle, flxNameNStatus, flxScDetailRoot);
        journeydetail.add(flxDetailsRoot);
        return journeydetail;
    }
})
;
define('com/konysa/journeydetail/journeydetailConfig',[],function() {
    return {
        "properties": [],
        "apis": ["setDataToWidgets", "updateJourneyStatusOnJourneyDetailsUI", "setVisibilityOfActionFlex"],
        "events": ["onClickOfCreateCheckInBtn", "onBackClick", "actionOfChangeETABtn", "actionOfCloseJourneyBtn"]
    }
});

define("com/konysa/journeyTracker/userjourneyTrackerController", [],function() {
    return {
        /**
         * @function
         *
         * @param baseConfig 
         * @param layoutConfig 
         * @param pspConfig 
         */
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this._watchId = null;
            this._enableHighAccuracy = null;
            this._enableLocationSimulation = null;
            this._timeOut = null;
            this._maximumCachedAge = null;
            this._minimumDistance = null;
            this._minimumTime = null;
            this._proximity = 0.003;
            this._apiKey = "AIzaSyBxz_lS49jNEpML6LiwXTbKQRPsTSS8HZM";
            this._checkPointDetails = {};
            this._phoneNumber = null;
            this._name = null;
            this._placesData = [];
            this._destLat = null;
            this._destLon = null;
            this._destination = {
                "lattitude": "29.858389",
                "longitude": "-95.378321"
            };
            this._source = {
                "lat": "29.856866",
                "lon": "-95.122587"
            };
            this._wayPoints = [];
            this._checkPointData = [];
            this._checkPoints = [];
            this._globalPlaceDataIndex = null;
            this._selectedWayPoint = 0;
            this._placesDataLength = null;
            this._globalTimer = false;
            this._currentTimerID = null;
            this._gestureType = null;
            this._journeyDetails = {};
            this._checkPointDetails = {};
            this._checkPointIndex = 0;
            this._gestureType = {
                pressDuration: 2
            };
            this._enteredCheckPoint1 = false;
            this._enteredCheckPoint2 = false;
            this._enteredCheckPoint3 = false;
            this._enteredCheckPoints = [];
            this._reachedDestination = false;
            this._count = 0;
            this._filteredWayPoints = [];
            this._isEtaEnabled = true;
            this._totalJourneyDuration = 0;
            this._totalJourneyDistance = 0;
            this._currentCheckPoint = "";
            this._checkPointIndices = [];
            try {
                this.view.flxInnerDetails.setGestureRecognizer(constants.GESTURE_TYPE_LONGPRESS, this._gestureType, this.formGesture.bind(this));
            } catch (err) {
                alert(err);
            }
        },
        formGesture: function(myWidget, gestureInfo) {
            this.view.removeGestureRecognizer(this._gestureType);
            this.startJourneyMocking(this._source, this._destination);
        },
        //Logic for getters/setters of custom properties
        /**
         * @function
         *
         */
        initGettersSetters: function() {
            defineSetter(this, "enableHighAccuracy", function(val) {
                if (typeof val == 'boolean') {
                    this._enableHighAccuracy = val;
                } else {
                    this._enableHighAccuracy = true;
                }
            });
            defineGetter(this, "enableHighAccuracy", function() {
                return this._enableHighAccuracy;
            });
            defineSetter(this, "timeOut", function(val) {
                if (typeof val == 'number') {
                    this._timeOut = val;
                } else {
                    this._timeOut = 15000;
                }
            });
            defineGetter(this, "timeOut", function() {
                return this._timeOut;
            });
            defineSetter(this, "maximumCachedAge", function(val) {
                if (typeof val == 'number') {
                    this._maximumCachedAge = val;
                } else {
                    this._maximumCachedAge = 300000;
                }
            });
            defineGetter(this, "maximumCachedAge", function() {
                return this._maximumCachedAge;
            });
            defineSetter(this, "minimumDistance", function(val) {
                if (typeof val == 'number') {
                    this._minimumDistance = val;
                } else {
                    this._minimumDistance = 10;
                }
            });
            defineGetter(this, "minimumDistance", function() {
                return this._minimumDistance;
            });
            defineSetter(this, "minimumTime", function(val) {
                if (typeof val == 'number') {
                    this._minimumTime = val;
                } else {
                    this._minimumTime = 60000;
                }
            });
            defineGetter(this, "minimumTime", function() {
                return this._minimumTime;
            });
            defineSetter(this, "apiKey", function(val) {
                if (typeof val == 'string') {
                    this._apiKey = val;
                } else {}
            });
            defineGetter(this, "apiKey", function() {
                return this._apiKey;
            });
            defineSetter(this, "enableLocationSimulation", function(val) {
                if (typeof val == 'boolean') {
                    this._enableLocationSimulation = val;
                } else {
                    this._enableLocationSimulation = false;
                }
            });
            defineGetter(this, "enableLocationSimulation", function() {
                return this._enableHighAccuracy;
            });
            defineSetter(this, "proximity", function(val) {
                //         if(typeof val=='boolean'){
                //           this._enableLocationSimulation=val;
                //         }else{
                //           debugger;
                //           this._enableLocationSimulation=false;
                //         }
            });
            defineGetter(this, "proximity", function() {
                return "";
            });
        },
        month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        /**
         * @function
         *
         * @param phNumber 
         */
        setphoneNumber: function(phNumber) {
            if (typeof phNumber == 'string') {
                this._phoneNumber = phNumber;
            } else {
                this._phoneNumber = null;
            }
        },
        /**
         * @function
         *
         */
        setName: function(name) {
            if (typeof name == 'string') {
                this.view.lblSiteRepresentativeValue.text = name;
                this._name = name;
            } else {
                this.view.lblSiteRepresentativeValue.text = "NA";
            }
        },
        /**
         * @function
         *
         * @param destination 
         */
        setDestination: function(destination) {
            if (typeof destination == 'object' && destination !== null) {
                if (!isNaN(destination["lattitude"]) && !isNaN(destination["longitude"])) {
                    //this.view.mapNavigator.clear();
                    try {
                        this.view.getdirection.destinationPlace = destination["lattitude"] + "," + destination["longitude"];
                        this.resetComponent();
                        this._destination = destination;
                        this.drawCircle(destination);
                        if (!this._enableLocationSimulation) {
                            this.trackLocation();
                        }
                    } catch (excp) {}
                }
            } else {
                alert("Destination not available");
            }
        },
        /**
         * @function
         *
         */
        trrigerCheckInCallback: function() {
            if (typeof this.checkInCallback == 'function') {
                this.clearWatch();
                var currentdate = new Date();
                var datetime = "Date " + currentdate.getDate() + "/" + (currentdate.getMonth() + 1) + "/" + currentdate.getFullYear() + " Time " + currentdate.getHours() + ":" + currentdate.getMinutes() + ":" + currentdate.getSeconds();
                this.checkInCallback(datetime);
                //this.view.btnCheckin.onClick=this.checkinCallback;
            }
        },
        /**
         * @function
         *
         * @param res 
         */
        trackLocationSuccessCB: function(res) {
            //alert("res:"+JSON.stringify(res));
            if (typeof res == 'object' && res !== null) {
                var coords = res["coords"];
                if (typeof coords == 'object' && coords !== null) {
                    var sourceLoc = {
                        lat: coords["latitude"],
                        lon: coords["longitude"],
                        name: "Current Location",
                        desc: "",
                        image: "myself.png"
                    };
                    try {
                        //alert("hello");
                        this.view.getdirection.originPlace = coords["latitude"] + "," + coords["longitude"];
                        var dateObj = new Date();
                        var currentDate = dateObj.getDate();
                        if (currentDate < 10) currentDate = "0" + currentDate;
                        var currentMonth = this.month[dateObj.getMonth() + 1];
                        //var currentMonth=dateObj.toLocaleString("en-us", { month: "short" });
                        var currentHour = dateObj.getHours();
                        if (currentHour < 10) {
                            currentHour = "0" + currentHour;
                        }
                        var currentMinute = dateObj.getMinutes();
                        if (currentMinute < 10) {
                            currentMinute = "0" + currentMinute;
                        }
                        var datetime = currentDate + " " + currentMonth + " " + currentHour + ":" + currentMinute + " Hrs";
                        this.view.lblCheckinnTimestamp.text = datetime;
                        if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY) === true) {
                            this.searchRoute(sourceLoc, this._destination);
                        } else {
                            // show map pins.
                            this.view.mapNavigator.clear();
                            this.view.mapNavigator.locationData = [this._destination, sourceLoc];
                        }
                    } catch (excp) {}
                }
            }
        },
        /**
         * @function
         *
         * @param err 
         */
        trackLocationFailureCB: function(err) {
            //             alert(err);
        },
        resetComponent: function() {
            //             alert(err);
        },
        clearWatch: function() {
            //             alert(err);
        },
        mockLocation: function() {
            //             alert(err);
        },
        displayAlert2: function() {
            //             alert(err);
        },
        /**
         * @function
         *
         */
        onPostShow: function() {
            this.resetComponent();
            this.view.forceLayout();
            var locationData = {};
            this.getGeoPosition();
        },
        /**
         * @function
         *
         * @param sourceLocation 
         * @param destinationLocation 
         */
        searchRoute: function(sourceLocation, destinationLocation) {
            if (typeof sourceLocation === 'object' && sourceLocation !== null && typeof destinationLocation === 'object' && destinationLocation !== null) {
                var dest = {};
                var source = {};
                dest["lat"] = Number(destinationLocation["lattitude"]);
                dest["lon"] = Number(destinationLocation["longitude"]);
                dest["address"] = "";
                source["lat"] = sourceLocation["lat"];
                source["lon"] = sourceLocation["lon"];
                source["address"] = "";
                var searchCriteriaObj = {};
                searchCriteriaObj["alternatives"] = true;
                searchCriteriaObj["directionServiceUrl"] = "https://maps.googleapis.com/maps/api/directions/json";
                searchCriteriaObj["destination"] = dest;
                searchCriteriaObj["origin"] = source;
                searchCriteriaObj["transportMode"] = "driving";
                searchCriteriaObj["apiKey"] = this._apiKey;
                try {
                    //alert("searchCriteriaObj: "+JSON.stringify(searchCriteriaObj));
                    kony.map.searchRoutes(searchCriteriaObj, this.searchRouteSuccesCallback.bind(this), this.searchRoutesErrorCallback);
                } catch (excp) {
                    alert("Excp in search routes:" + JSON.stringify(excp));
                    debugger;
                }
            }
        },
        /**
         * @function
         *
         * @param routes 
         */
        searchRouteSuccesCallback: function(routes) {
            if (routes.length != 0 && this._reachedDestination == false) {
                this.displySearchRoutes(routes);
            } else {
                alert("no route exists");
            }
        },
        /**
         * @function
         *
         * @param errorCode 
         * @param errorMessage 
         */
        searchRoutesErrorCallback: function(errorCode, errorMessage) {
            //alert("Error in search route");
            debugger;
            //alert(errorCode+"   "+errorMessage);
        },
        /**
         * @function
         *
         * @param searchedRoutes 
         */
        displySearchRoutes: function(searchedRoutes) {
            // alert("Searched routes: "+searchedRoutes.length);
            var routeColors = ["0000FFFF", "FF00FFFF", "FF0000FF", "FFFF00FF", "0x000000FF"];
            if (Array.isArray(searchedRoutes) && searchedRoutes.length > 0) {
                if (this._count == 0) {
                    this._wayPoints = searchedRoutes[0].polylinePoints;
                    this._wayPoints.splice(this._wayPoints.length, 3);
                    this._count++;
                }
                var finalDestination = {
                    "lat": this._destination["lattitude"],
                    "lon": this._destination["longitude"]
                };
                this.drawRoute("route" + 0, searchedRoutes[0].polylinePoints, routeColors[0], this._checkPoints);
            } else {
                debugger;
            }
        },
        /**
         * @function
         *
         * @param routeid 
         * @param polyPoints 
         * @param color 
         */
        drawRoute: function(routeid, polyPoints, color, checkpointsData) {
            //alert("draw route:");
            var steps = polyPoints;
            kony.print("################The polyline points");
            kony.print(steps);
            var ei = steps.length - 1;
            var startLoc = {
                lat: steps[0].lat,
                lon: steps[0].lon,
                image: {
                    source: "sourcemodified.png",
                    anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                }
            };
            var endLoc = {
                lat: steps[ei].lat,
                lon: steps[ei].lon,
                image: {
                    source: "arrivalfinal.png",
                    anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                }
            };
            var polylineData = {
                id: routeid,
                locations: steps,
                startLocation: startLoc,
                endLocation: endLoc,
                polylineConfig: {
                    lineWidth: 5,
                    lineColor: color
                }
            };
            try {
                this.view.mapNavigator.clear();
                this.view.mapNavigator.addPolyline(polylineData);
                this.view.mapNavigator.navigateTo(0);
                if (this._selectedWayPoint === 1) {
                    this.setCheckPoints(this._wayPoints, this.view.mapNavigator);
                } else if (this._selectedWayPoint > 1) {
                    if (this._enteredCheckPoint1 == false) {
                        this.view.mapNavigator.addPin(this._checkPoints[0]);
                    } else {
                        this.view.mapNavigator.addPin(this._enteredCheckPoints[0]);
                    }
                    if (this._enteredCheckPoint2 == false) {
                        this.view.mapNavigator.addPin(this._checkPoints[1]);
                    } else {
                        this.view.mapNavigator.addPin(this._enteredCheckPoints[1]);
                    }
                    if (this._enteredCheckPoint3 == false) {
                        this.view.mapNavigator.addPin(this._checkPoints[2]);
                    } else {
                        this.view.mapNavigator.addPin(this._enteredCheckPoints[2]);
                    }
                }
                var alertObj = this.view.customAlertWithoutContactCheckin;
                var mapObj = this.view.mapNavigator;
                this.trackCheckPoints(startLoc, endLoc, checkpointsData, alertObj, mapObj);
            } catch (excp) {
                alert("Excp in adding polyline:" + excp);
                debugger;
            }
        },
        /**
         * @function
         *
         */
        clearWatch: function() {
            try {
                kony.location.clearWatch(this._watchId);
            } catch (excp) {
                debugger;
            }
        },
        /**
         * @function
         *
         */
        resetComponent: function() {
            this.view.mapNavigator.clear();
            try {
                kony.location.clearWatch(this._watchId);
            } catch (excp) {
                debugger;
            }
        },
        dialSupervisor: function() {
            try {
                this._phoneNumber = "8686186516";
                var phoneNumber = this._phoneNumber;
                if (phoneNumber !== undefined || phoneNumber !== "") {
                    kony.phone.dial(phoneNumber);
                } else {
                    alert("provide valid number");
                }
            } catch (err) {
                debugger;
                alert("error in dial:: " + err);
            }
        },
        dialTrackingPoint: function() {
            try {
                this._phoneNumber = "8686186516";
                var phoneNumber = this._phoneNumber;
                if (phoneNumber !== undefined || phoneNumber !== "") {
                    kony.phone.dial(phoneNumber);
                } else {
                    alert("provide valid number");
                }
            } catch (err) {
                debugger;
                alert("error in dial:: " + err);
            }
        },
        changeButtonSkin: function() {
            var config = {};
            var self = this;
            config.statusChange = function(isOnLine) {
                if (isOnLine) {
                    this.view.btnNetStatus.text = "YOU ARE ONLINE";
                    this.view.btnNetStatus.skin = "sknNetworkOnline";
                } else {
                    self.view.btnNetStatus.skin = "sknNetworkOffLine";
                    self.view.btnNetStatus.text = "YOU ARE OFFLINE, CHECK YOUR CONNECTION";
                }
            };
            kony.net.setNetworkCallbacks(config);
            var isOnLine = kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
        },
        startJourneyMocking: function(srcLocation, destLocation) {
            this.clearWatch();
            if (this._selectedWayPoint == 0) {
                this.searchRoute(this._source, this._destination);
                this._selectedWayPoint++;
            } else if (this._wayPoints[this._selectedWayPoint] != null) {
                this.searchRoute(this._wayPoints[this._selectedWayPoint], this._destination);
                this._selectedWayPoint++;
            } else {
                kony.timer.cancel("mytimer1");
            }
        },
        getETAforDestination: function(src, dest, checkPoints) {
            try {
                var serviceName = "getETASForLoc";
                var integrationObj = KNYMobileFabric.getIntegrationService(serviceName);
                var operationName = "getEta";
                var query = checkPoints[0].lat + "," + checkPoints[0].lon + "|" + checkPoints[1].lat + "," + checkPoints[1].lon + "|" + checkPoints[2].lat + "," + checkPoints[2].lon;
                var data = {
                    "srcLat": src.lat,
                    "srcLon": src.lon,
                    "destLat": dest.lattitude,
                    "destLon": dest.longitude,
                    "waypoints": query,
                    "key": "AIzaSyBxz_lS49jNEpML6LiwXTbKQRPsTSS8HZM"
                };
                var headers = {};
                integrationObj.invokeOperation(operationName, headers, data, this.operationSuccess.bind(this), this.operationFailure.bind(this));
            } catch (exception) {
                alert(exception.message);
            }
        },
        operationSuccess: function(response) {
            var checkPointDetails = {};
            var legsLength = response.routes[0].legs.length;
            for (i = 0; i < legsLength; i++) {
                var checkPointName = "checkPoint" + i;
                checkPointDetails[checkPointName] = {};
                checkPointDetails[checkPointName]["address"] = response.routes[0].legs[i].end_address.trim(",", 1);
                checkPointDetails[checkPointName]["duration"] = response.routes[0].legs[i].duration.value;
                checkPointDetails[checkPointName]["distance"] = response.routes[0].legs[i].distance.value;
            }
            var totalDuration = 0;
            var totalDistance = 0;
            for (i = 0; i < legsLength; i++) {
                var checkPointName = "checkPoint" + i;
                totalDuration += checkPointDetails[checkPointName]["duration"]
                totalDistance += checkPointDetails[checkPointName]["distance"]
            }
            totalDuration = Math.ceil(totalDuration / 60);
            totalDistance = Math.ceil(totalDistance * 0.000621371192);
            checkPointDetails["totalJourneyDuration"] = totalDuration;
            checkPointDetails["totalJourneyDistance"] = totalDistance;
            var lastIndex = legsLength - 1;
            checkPointDetails["destination"] = checkPointDetails["checkPoint" + lastIndex].address;
            this._checkPointDetails = checkPointDetails;
            this._currentCheckPoint = checkPointDetails["checkPoint" + 0].address;
            kony.timer.schedule("mytimer1", this.startJourneyMocking.bind(this), 0.5, true);
        },
        operationFailure: function(err) {
            alert(JSON.stringify(err.message));
        },
        setNetworkStatus: function() {
            try {
                var config = {};
                var self = this;
                config.statusChange = function(isOnLine) {
                    if (isOnLine) {
                        self.view.btnNetStatus.skin = "sknNetworkOnline";
                        self.view.btnNetStatus.text = "YOU ARE ONLINE";
                    } else {
                        self.view.btnNetStatus.skin = "sknNetworkOffLine";
                        self.view.btnNetStatus.text = "YOU ARE OFFLINE, CHECK YOUR CONNECTION";
                    }
                };
                kony.net.setNetworkCallbacks(config);
                var isOnLine = kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
            } catch (err) {
                alert(err.message);
            }
        },
        setCheckPoints: function(wayPoints, mapObj) {
            this._checkPointIndex = Math.round(wayPoints.length / 3) - 1;
            this._checkPointIndices.push(this._checkPointIndex);
            this._checkPointData[0] = this._wayPoints[this._checkPointIndex];
            this._checkPointData[1] = this._wayPoints[2 * this._checkPointIndex];
            var index;
            if (3 * this._checkPointIndex < wayPoints.length) {
                index = Math.round((2 * this._checkPointIndex + 3 * this._checkPointIndex) / 2);
                this._checkPointData[2] = this._wayPoints[index];
                this._checkPointIndices.push(index);
            } else {
                index = wayPoints.length - 15;
                this._checkPointData[2] = this._wayPoints[index];
            }
            if (this._isEtaEnabled == true) {
                this.getETAforDestination(this._source, this._destination, this._checkPointData);
                this._isEtaEnabled = false;
            }
            var checkPoint1 = {
                lat: this._checkPointData[0].lat,
                lon: this._checkPointData[0].lon,
                image: {
                    source: "checkpoint1.png",
                    anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                }
            };
            var checkPoint2 = {
                lat: this._checkPointData[1].lat,
                lon: this._checkPointData[1].lon,
                image: {
                    source: "checkpoint2.png",
                    anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                }
            };
            var checkPoint3 = {
                lat: this._checkPointData[2].lat,
                lon: this._checkPointData[2].lon,
                image: {
                    source: "checkpoint3.png",
                    anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                }
            };
            this._checkPoints[0] = checkPoint1;
            this._checkPoints[1] = checkPoint2;
            this._checkPoints[2] = checkPoint3;
            this.get
            mapObj.addPin(checkPoint1);
            mapObj.addPin(checkPoint2);
            mapObj.addPin(checkPoint3);
            mapObj.zoomLevel = 5;
        },
        trackCheckPoints: function(startLoc, endLoc, checkpointsData, alertObj, mapObj) {
            var distance = this.findDistanceInMiles(startLoc, checkpointsData[0]);
            if (distance < this._proximity) {
                this._enteredCheckPoint1 = true
                var checkPoint1 = {
                    lat: this._checkPointData[0].lat,
                    lon: this._checkPointData[0].lon,
                    image: {
                        source: "enteredcheckpoint.png",
                        anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                    }
                };
                this._enteredCheckPoints[0] = checkPoint1;
                mapObj.addPin(checkPoint1);
                alertObj.setVisibility(true);
                alertObj.text = "Regular Check-In";
                alertObj.text1 = "It's time for your 1st Check-In.";
                alertObj.text2 = "Check-In";
            }
            distance = this.findDistanceInMiles(startLoc, checkpointsData[1]);
            if (distance < this._proximity) {
                this._enteredCheckPoint2 = true
                var checkPoint2 = {
                    lat: this._checkPointData[1].lat,
                    lon: this._checkPointData[1].lon,
                    image: {
                        source: "enteredcheckpoint.png",
                        anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                    }
                };
                this._enteredCheckPoints[1] = checkPoint2;
                mapObj.addPin(checkPoint2);
                alertObj.setVisibility(true);
                alertObj.text = "Regular Check-In";
                alertObj.text1 = "It's time for your 2nd Check-In.";
                alertObj.text2 = "Check-In";
            }
            distance = this.findDistanceInMiles(startLoc, checkpointsData[2]);
            if (distance < this._proximity) {
                this._enteredCheckPoint3 = true;
                var checkPoint3 = {
                    lat: this._checkPointData[2].lat,
                    lon: this._checkPointData[2].lon,
                    image: {
                        source: "enteredcheckpoint.png",
                        anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                    }
                };
                this._enteredCheckPoints[2] = checkPoint3;
                mapObj.addPin(checkPoint3);
                alertObj.setVisibility(true);
                alertObj.text = "Regular Check-In";
                alertObj.text1 = "It's time for your 3rd Check-In.";
                alertObj.text2 = "Check-In";
            }
            distance = this.findDistanceInMiles(startLoc, endLoc);
            if (distance < this._proximity) {
                this._enteredCheckPoint3 = true;
                var checkPoint3 = {
                    lat: this._checkPointData[2].lat,
                    lon: this._checkPointData[2].lon,
                    image: {
                        source: "departurepoint.png",
                        anchor: kony.map.PIN_IMG_ANCHOR_CENTER
                    }
                };
                mapObj.addPin(checkPoint3);
                alertObj.setVisibility(true);
                this._reachedDestination = true;
                alertObj.text = "Regular Check-In";
                alertObj.text1 = "You've reached your destination.\n Check-In now.";
                alertObj.text2 = "Check-In";
                kony.timer.cancel("mytimer1");
            }
        },
        findDistanceInMiles: function(sourceLocation, destinationLocation) {
            var distance = null;
            if (typeof sourceLocation == 'object' && sourceLocation !== null && typeof destinationLocation == 'object' && destinationLocation !== null) {
                var lat1 = Number(sourceLocation["lat"]);
                var lon1 = Number(sourceLocation["lon"]);
                var lat2 = Number(destinationLocation["lat"]);
                var lon2 = Number(destinationLocation["lon"]);
                var Radius = 6371;
                var radConst = (Math.PI / 180);
                try {
                    var dLat = (lat2 - lat1) * radConst;
                    var dLon = (lon2 - lon1) * radConst;
                    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos((lat1 * radConst)) * Math.cos(lat2 * radConst) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
                    var centralAngle = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                    distance = Radius * centralAngle * 0.6237;
                } catch (excp) {
                    debugger;
                    distance = null;
                }
            }
            return distance;
        },
        displayAlert2: function() {
            this.view.customAlertWithImage.setVisibility(true);
            this.view.customAlertWithImage.text = "Emergency Request Sent.";
            this.view.customAlertWithImage.text1 = "Help is on it's way.";
        },
        navigateTo: function(formName) {
            var ntf = new kony.mvc.Navigation("frmJourneyCompleted");
            ntf.navigate();
        }
    };
});
define("com/konysa/journeyTracker/journeyTrackerControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for flxImage **/
    AS_FlexContainer_ad8b1bff9a7a45df84e898e7f9b201c5: function AS_FlexContainer_ad8b1bff9a7a45df84e898e7f9b201c5(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmEmergencyRequest");
        ntf.navigate();
    },
    /** onClick defined for flxSupervisor **/
    AS_FlexContainer_c0b3c4099c234713b1455ae9909bf16a: function AS_FlexContainer_c0b3c4099c234713b1455ae9909bf16a(eventobject) {
        var self = this;
        return self.dialSupervisor.call(this);
    },
    /** onClick defined for flxTrackingPoint **/
    AS_FlexContainer_f394252cb2dd4180afab9e2f7585d425: function AS_FlexContainer_f394252cb2dd4180afab9e2f7585d425(eventobject) {
        var self = this;
        return self.dialTrackingPoint.call(this);
    },
    /** postShow defined for journeyTracker **/
    AS_FlexContainer_h5d3b7fa804547dd8e8e340e8a1307eb: function AS_FlexContainer_h5d3b7fa804547dd8e8e340e8a1307eb(eventobject) {
        var self = this;
        return self.setNetworkStatus.call(this);
    },
    /** onDestroy defined for journeyTracker **/
    AS_FlexContainer_j9f62e0a77d441938ef418b42516bcaa: function AS_FlexContainer_j9f62e0a77d441938ef418b42516bcaa(eventobject) {
        var self = this;
        this.clearWatch();
    },
    /** onHide defined for journeyTracker **/
    AS_FlexContainer_b4e83feab808489dbf2e40a410926e3b: function AS_FlexContainer_b4e83feab808489dbf2e40a410926e3b(eventobject) {
        var self = this;
        this.clearWatch();
    }
});
define("com/konysa/journeyTracker/journeyTrackerController", ["com/konysa/journeyTracker/userjourneyTrackerController", "com/konysa/journeyTracker/journeyTrackerControllerActions"], function() {
    var controller = require("com/konysa/journeyTracker/userjourneyTrackerController");
    var actions = require("com/konysa/journeyTracker/journeyTrackerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "btnText", function(val) {
            this.view.btnNetStatus.text = val;
        });
        defineGetter(this, "btnText", function() {
            return this.view.btnNetStatus.text;
        });
        defineSetter(this, "netBtnSkn", function(val) {
            this.view.btnNetStatus.skin = val;
        });
        defineGetter(this, "netBtnSkn", function() {
            return this.view.btnNetStatus.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/journeyTracker/journeyTracker',[],function() {
    return function(controller) {
        var journeyTracker = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "journeyTracker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onDestroy": controller.AS_FlexContainer_j9f62e0a77d441938ef418b42516bcaa,
            "onHide": controller.AS_FlexContainer_b4e83feab808489dbf2e40a410926e3b,
            "postShow": controller.AS_FlexContainer_h5d3b7fa804547dd8e8e340e8a1307eb,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "journeyTracker"), extendConfig({}, controller.args[1], "journeyTracker"), extendConfig({}, controller.args[2], "journeyTracker"));
        journeyTracker.setDefaultUnit(kony.flex.DP);
        var flxMapRoot = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxMapRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "30dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxMapRoot"), extendConfig({}, controller.args[1], "flxMapRoot"), extendConfig({}, controller.args[2], "flxMapRoot"));
        flxMapRoot.setDefaultUnit(kony.flex.DP);
        var mapNavigator = new kony.ui.Map(extendConfig({
            "bottom": "205dp",
            "calloutWidth": 80,
            "centerX": "50%",
            "defaultPinImage": "pinb.png",
            "height": "65%",
            "id": "mapNavigator",
            "isVisible": true,
            "provider": constants.MAP_PROVIDER_GOOGLE,
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "mapNavigator"), extendConfig({}, controller.args[1], "mapNavigator"), extendConfig({}, controller.args[2], "mapNavigator"));
        var lblUserInfo = new kony.ui.Label(extendConfig({
            "height": "45dp",
            "id": "lblUserInfo",
            "isVisible": false,
            "left": 21,
            "right": "21dp",
            "skin": "sknLblBgffffffFont6a6a6aBorder7px",
            "text": "Move close to the location to check in",
            "textStyle": {},
            "top": "16dp",
            "zIndex": 5
        }, controller.args[0], "lblUserInfo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUserInfo"), extendConfig({}, controller.args[2], "lblUserInfo"));
        var flxSOSContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "8%",
            "id": "flxSOSContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "57%",
            "isModalContainer": false,
            "skin": "CopyslFbox0g7951db46b0f4e",
            "top": "55%",
            "width": "40%"
        }, controller.args[0], "flxSOSContainer"), extendConfig({}, controller.args[1], "flxSOSContainer"), extendConfig({}, controller.args[2], "flxSOSContainer"));
        flxSOSContainer.setDefaultUnit(kony.flex.DP);
        var flxLogoutContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "40%",
            "centerY": "50.00%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxLogoutContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0%",
            "skin": "CopyslFbox0db1068aa5d7c42",
            "width": "33%",
            "zIndex": 1
        }, controller.args[0], "flxLogoutContainer"), extendConfig({}, controller.args[1], "flxLogoutContainer"), extendConfig({}, controller.args[2], "flxLogoutContainer"));
        flxLogoutContainer.setDefaultUnit(kony.flex.DP);
        var imgLogout = new kony.ui.Image2(extendConfig({
            "centerX": "50.02%",
            "centerY": "49.95%",
            "height": "24dp",
            "id": "imgLogout",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "logout.png",
            "top": "0dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgLogout"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogout"), extendConfig({}, controller.args[2], "imgLogout"));
        flxLogoutContainer.add(imgLogout);
        var flxVerticalLine2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "95%",
            "id": "flxVerticalLine2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0d0a6c84f5dbd4c",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxVerticalLine2"), extendConfig({}, controller.args[1], "flxVerticalLine2"), extendConfig({}, controller.args[2], "flxVerticalLine2"));
        flxVerticalLine2.setDefaultUnit(kony.flex.DP);
        flxVerticalLine2.add();
        var flxImage = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "25dp",
            "id": "flxImage",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onTouchStart": controller.AS_FlexContainer_ad8b1bff9a7a45df84e898e7f9b201c5,
            "skin": "CopyslFbox0i5bad6421f5f48",
            "width": "33%",
            "zIndex": 1
        }, controller.args[0], "flxImage"), extendConfig({}, controller.args[1], "flxImage"), extendConfig({}, controller.args[2], "flxImage"));
        flxImage.setDefaultUnit(kony.flex.DP);
        var imgProfile = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "imgProfile",
            "isVisible": true,
            "left": "5dp",
            "skin": "slImage",
            "src": "sosbtn.png",
            "top": "0dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgProfile"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgProfile"), extendConfig({}, controller.args[2], "imgProfile"));
        flxImage.add(imgProfile);
        var flxVerticalLine1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "95%",
            "id": "flxVerticalLine1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0d0a6c84f5dbd4c",
            "top": "19dp",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxVerticalLine1"), extendConfig({}, controller.args[1], "flxVerticalLine1"), extendConfig({}, controller.args[2], "flxVerticalLine1"));
        flxVerticalLine1.setDefaultUnit(kony.flex.DP);
        flxVerticalLine1.add();
        var flxGoogleMapsContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "40%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxGoogleMapsContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "1dp",
            "isModalContainer": false,
            "right": "3%",
            "skin": "CopyslFbox0db1068aa5d7c42",
            "width": "33%",
            "zIndex": 1
        }, controller.args[0], "flxGoogleMapsContainer"), extendConfig({}, controller.args[1], "flxGoogleMapsContainer"), extendConfig({}, controller.args[2], "flxGoogleMapsContainer"));
        flxGoogleMapsContainer.setDefaultUnit(kony.flex.DP);
        var imgGoogleMaps = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "24dp",
            "id": "imgGoogleMaps",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "directions.png",
            "top": "0dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "imgGoogleMaps"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgGoogleMaps"), extendConfig({}, controller.args[2], "imgGoogleMaps"));
        flxGoogleMapsContainer.add(imgGoogleMaps);
        flxSOSContainer.add(flxLogoutContainer, flxVerticalLine2, flxImage, flxVerticalLine1, flxGoogleMapsContainer);
        flxMapRoot.add(mapNavigator, lblUserInfo, flxSOSContainer);
        var mainFlex = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "mainFlex",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "mainFlex"), extendConfig({}, controller.args[1], "mainFlex"), extendConfig({}, controller.args[2], "mainFlex"));
        mainFlex.setDefaultUnit(kony.flex.DP);
        var flxJourneyDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0%",
            "clipBounds": true,
            "height": "245dp",
            "id": "flxJourneyDetails",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "65%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "flxJourneyDetails"), extendConfig({}, controller.args[1], "flxJourneyDetails"), extendConfig({}, controller.args[2], "flxJourneyDetails"));
        flxJourneyDetails.setDefaultUnit(kony.flex.DP);
        var btnNetStatus = new kony.ui.Button(extendConfig({
            "focusSkin": "sknNetworkOnline",
            "height": "28dp",
            "id": "btnNetStatus",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknNetworkOnline",
            "text": "YOU ARE ONLINE",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "btnNetStatus"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnNetStatus"), extendConfig({}, controller.args[2], "btnNetStatus"));
        var flxInnerDetails = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxInnerDetails",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "right": "16dp",
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxInnerDetails"), extendConfig({}, controller.args[1], "flxInnerDetails"), extendConfig({}, controller.args[2], "flxInnerDetails"));
        flxInnerDetails.setDefaultUnit(kony.flex.DP);
        var btnCheckinData = new kony.ui.Button(extendConfig({
            "height": "22dp",
            "id": "btnCheckinData",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefBtnNormal0a996d7be30fc40",
            "text": "check in data",
            "top": "5dp",
            "width": "160dp",
            "zIndex": 1
        }, controller.args[0], "btnCheckinData"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnCheckinData"), extendConfig({}, controller.args[2], "btnCheckinData"));
        var lblArrival = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblArrival",
            "isVisible": true,
            "left": "210dp",
            "skin": "CopydefLabel0c434540a1b5641",
            "text": "Arriving At",
            "textStyle": {},
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblArrival"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblArrival"), extendConfig({}, controller.args[2], "lblArrival"));
        var lblArrivalTime = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblArrivalTime",
            "isVisible": true,
            "left": "270dp",
            "right": "16dp",
            "skin": "CopydefLabel0j067fb59288a4e",
            "text": "5:10 PM",
            "textStyle": {},
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblArrivalTime"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblArrivalTime"), extendConfig({}, controller.args[2], "lblArrivalTime"));
        var lblCheckinTime = new kony.ui.Label(extendConfig({
            "height": "21dp",
            "id": "lblCheckinTime",
            "isVisible": true,
            "left": "3dp",
            "skin": "CopydefLabel0f2b85562eb264c",
            "text": "5 Min",
            "textStyle": {},
            "top": "30dp",
            "width": "46dp",
            "zIndex": 1
        }, controller.args[0], "lblCheckinTime"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCheckinTime"), extendConfig({}, controller.args[2], "lblCheckinTime"));
        var lblArrivalTimeData = new kony.ui.Label(extendConfig({
            "height": "21dp",
            "id": "lblArrivalTimeData",
            "isVisible": true,
            "left": "210dp",
            "skin": "CopydefLabel0f2b85562eb264c",
            "text": "10 Miles Away",
            "textStyle": {},
            "top": "30dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblArrivalTimeData"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblArrivalTimeData"), extendConfig({}, controller.args[2], "lblArrivalTimeData"));
        flxInnerDetails.add(btnCheckinData, lblArrival, lblArrivalTime, lblCheckinTime, lblArrivalTimeData);
        var flxShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "1dp",
            "id": "flxShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0h2286111bee749",
            "top": "2dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxShadow"), extendConfig({}, controller.args[1], "flxShadow"), extendConfig({}, controller.args[2], "flxShadow"));
        flxShadow.setDefaultUnit(kony.flex.DP);
        flxShadow.add();
        var flxInnerDetails2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "131dp",
            "id": "flxInnerDetails2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "16dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "5dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxInnerDetails2"), extendConfig({}, controller.args[1], "flxInnerDetails2"), extendConfig({}, controller.args[2], "flxInnerDetails2"));
        flxInnerDetails2.setDefaultUnit(kony.flex.DP);
        var btnDestinationData = new kony.ui.Button(extendConfig({
            "height": "22dp",
            "id": "btnDestinationData",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefBtnNormal0a996d7be30fc40",
            "text": "check in data",
            "top": "5dp",
            "width": "160dp",
            "zIndex": 1
        }, controller.args[0], "btnDestinationData"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnDestinationData"), extendConfig({}, controller.args[2], "btnDestinationData"));
        var lblArrivingAt = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblArrivingAt",
            "isVisible": true,
            "left": "210dp",
            "skin": "CopydefLabel0c434540a1b5641",
            "text": "Arriving At",
            "textStyle": {},
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblArrivingAt"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblArrivingAt"), extendConfig({}, controller.args[2], "lblArrivingAt"));
        var lblDestArrivalTime = new kony.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblDestArrivalTime",
            "isVisible": true,
            "left": "270dp",
            "right": "16dp",
            "skin": "CopydefLabel0j067fb59288a4e",
            "text": "5:10 PM",
            "textStyle": {},
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDestArrivalTime"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDestArrivalTime"), extendConfig({}, controller.args[2], "lblDestArrivalTime"));
        var lblDestEstTime = new kony.ui.Label(extendConfig({
            "height": "21dp",
            "id": "lblDestEstTime",
            "isVisible": true,
            "left": "3dp",
            "skin": "CopydefLabel0f2b85562eb264c",
            "text": "2H",
            "textStyle": {},
            "top": "32dp",
            "width": "46dp",
            "zIndex": 1
        }, controller.args[0], "lblDestEstTime"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDestEstTime"), extendConfig({}, controller.args[2], "lblDestEstTime"));
        var lblDestDistance = new kony.ui.Label(extendConfig({
            "id": "lblDestDistance",
            "isVisible": true,
            "left": "210dp",
            "skin": "CopydefLabel0f2b85562eb264c",
            "text": "350 Miles Away",
            "textStyle": {},
            "top": "32dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblDestDistance"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDestDistance"), extendConfig({}, controller.args[2], "lblDestDistance"));
        var flxSupervisor = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSupervisor",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_c0b3c4099c234713b1455ae9909bf16a,
            "skin": "CopyslFbox0c3282b0afe0244",
            "top": "70dp",
            "width": "45%",
            "zIndex": 1
        }, controller.args[0], "flxSupervisor"), extendConfig({}, controller.args[1], "flxSupervisor"), extendConfig({}, controller.args[2], "flxSupervisor"));
        flxSupervisor.setDefaultUnit(kony.flex.DP);
        var Call = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "Call",
            "isVisible": true,
            "left": "15dp",
            "skin": "CopyslFontAwesomeIcon0f5787d731bcc47",
            "text": "",
            "textStyle": {},
            "top": "4dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "Call"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Call"), extendConfig({}, controller.args[2], "Call"));
        var flxInnerShadowPhn = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "75%",
            "id": "flxInnerShadowPhn",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "40dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0j4cdcdf77f6a43",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxInnerShadowPhn"), extendConfig({}, controller.args[1], "flxInnerShadowPhn"), extendConfig({}, controller.args[2], "flxInnerShadowPhn"));
        flxInnerShadowPhn.setDefaultUnit(kony.flex.DP);
        flxInnerShadowPhn.add();
        var lblSupervisor = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblSupervisor",
            "isVisible": true,
            "left": "40dp",
            "skin": "CopydefLabel0ief041775aef4e",
            "text": "Supervisor",
            "textStyle": {},
            "top": "0dp",
            "width": "120dp",
            "zIndex": 1
        }, controller.args[0], "lblSupervisor"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSupervisor"), extendConfig({}, controller.args[2], "lblSupervisor"));
        flxSupervisor.add(Call, flxInnerShadowPhn, lblSupervisor);
        var flxTrackingPoint = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxTrackingPoint",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_f394252cb2dd4180afab9e2f7585d425,
            "right": "5dp",
            "skin": "CopyslFbox0c3282b0afe0244",
            "top": "70dp",
            "width": "45%",
            "zIndex": 1
        }, controller.args[0], "flxTrackingPoint"), extendConfig({}, controller.args[1], "flxTrackingPoint"), extendConfig({}, controller.args[2], "flxTrackingPoint"));
        flxTrackingPoint.setDefaultUnit(kony.flex.DP);
        var callTrackingPoint = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "24dp",
            "id": "callTrackingPoint",
            "isVisible": true,
            "left": "15dp",
            "skin": "CopyslFontAwesomeIcon0f5787d731bcc47",
            "text": "",
            "textStyle": {},
            "top": "4dp",
            "width": "24dp",
            "zIndex": 1
        }, controller.args[0], "callTrackingPoint"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "callTrackingPoint"), extendConfig({}, controller.args[2], "callTrackingPoint"));
        var flxInnerShadow2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "75%",
            "id": "flxInnerShadow2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "39dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0j4cdcdf77f6a43",
            "top": "6dp",
            "width": "1dp",
            "zIndex": 1
        }, controller.args[0], "flxInnerShadow2"), extendConfig({}, controller.args[1], "flxInnerShadow2"), extendConfig({}, controller.args[2], "flxInnerShadow2"));
        flxInnerShadow2.setDefaultUnit(kony.flex.DP);
        flxInnerShadow2.add();
        var lblTrackingPoint = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblTrackingPoint",
            "isVisible": true,
            "left": "40dp",
            "skin": "CopydefLabel0ief041775aef4e",
            "text": "Tracking Point",
            "textStyle": {},
            "top": "0dp",
            "width": "100dp",
            "zIndex": 1
        }, controller.args[0], "lblTrackingPoint"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTrackingPoint"), extendConfig({}, controller.args[2], "lblTrackingPoint"));
        flxTrackingPoint.add(callTrackingPoint, flxInnerShadow2, lblTrackingPoint);
        var FlxInnerShadow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0dp",
            "clipBounds": true,
            "height": "5dp",
            "id": "FlxInnerShadow",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "100dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0f3c6409f0de14a",
            "top": "150dp",
            "width": "40%",
            "zIndex": 1
        }, controller.args[0], "FlxInnerShadow"), extendConfig({}, controller.args[1], "FlxInnerShadow"), extendConfig({}, controller.args[2], "FlxInnerShadow"));
        FlxInnerShadow.setDefaultUnit(kony.flex.DP);
        FlxInnerShadow.add();
        flxInnerDetails2.add(btnDestinationData, lblArrivingAt, lblDestArrivalTime, lblDestEstTime, lblDestDistance, flxSupervisor, flxTrackingPoint, FlxInnerShadow);
        var customAlertWithImage = new com.konysa.customAlertWithImage(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "customAlertWithImage",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0%",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "CopyflxBackgroundAlertSkn2",
            "top": "0%",
            "width": "100%",
            "overrides": {
                "customAlertWithImage": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "customAlertWithImage"), extendConfig({
            "overrides": {}
        }, controller.args[1], "customAlertWithImage"), extendConfig({
            "overrides": {}
        }, controller.args[2], "customAlertWithImage"));
        var customAlertWithoutContactCheckin = new com.konysa.customAlertWithoutContactCheckin(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "customAlertWithoutContactCheckin",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "CopyflxBackgroundAlertSkn3",
            "top": "0%",
            "width": "100%",
            "overrides": {
                "customAlertWithoutContactCheckin": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "customAlertWithoutContactCheckin"), extendConfig({
            "overrides": {}
        }, controller.args[1], "customAlertWithoutContactCheckin"), extendConfig({
            "overrides": {}
        }, controller.args[2], "customAlertWithoutContactCheckin"));
        flxJourneyDetails.add(btnNetStatus, flxInnerDetails, flxShadow, flxInnerDetails2, customAlertWithImage, customAlertWithoutContactCheckin);
        mainFlex.add(flxJourneyDetails);
        var customAlertWithContactcheckin = new com.konysa.customAlertWithContactcheckin(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "customAlertWithContactcheckin",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "1dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "CopyCopyflxBackgroundAlertSkn",
            "top": "0%",
            "width": "100%",
            "overrides": {
                "customAlertWithContactcheckin": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "customAlertWithContactcheckin"), extendConfig({
            "overrides": {}
        }, controller.args[1], "customAlertWithContactcheckin"), extendConfig({
            "overrides": {}
        }, controller.args[2], "customAlertWithContactcheckin"));
        journeyTracker.add(flxMapRoot, mainFlex, customAlertWithContactcheckin);
        return journeyTracker;
    }
})
;
define('com/konysa/journeyTracker/journeyTrackerConfig',[],function() {
    return {
        "properties": [{
            "name": "btnText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "netBtnSkn",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "enableHighAccuracy",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "timeOut",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "maximumCachedAge",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "minimumDistance",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "minimumTime",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "proximity",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "apiKey",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "enableLocationSimulation",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setDestination", "resetComponent", "setName", "setphoneNumber", "clearWatch", "mockLocation", "displayAlert2"],
        "events": ["checkInCallback", "forcedCheckInCallback"]
    }
});

define("com/konysa/normallogin/usernormalloginController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        doLogin: function() {
            this.onLoginSuccess();
        },
        onLoginSuccess: function() {
            if (typeof this.loginSuccess == 'function') {
                var param = {};
                this.loginSuccess(param);
            }
        },
        onLoginFailure: function() {}
    };
});
define("com/konysa/normallogin/normalloginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxSignIn **/
    AS_FlexContainer_a38522ae64df4585b14933f8f30278a8: function AS_FlexContainer_a38522ae64df4585b14933f8f30278a8(eventobject) {
        var self = this;
        this.doLogin();
    }
});
define("com/konysa/normallogin/normalloginController", ["com/konysa/normallogin/usernormalloginController", "com/konysa/normallogin/normalloginControllerActions"], function() {
    var controller = require("com/konysa/normallogin/usernormalloginController");
    var actions = require("com/konysa/normallogin/normalloginControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konysa/normallogin/normallogin',[],function() {
    return function(controller) {
        var normallogin = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "normallogin",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "minWidth": "327dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "normallogin"), extendConfig({}, controller.args[1], "normallogin"), extendConfig({}, controller.args[2], "normallogin"));
        normallogin.setDefaultUnit(kony.flex.DP);
        var lblLoginSubTitle = new kony.ui.Label(extendConfig({
            "id": "lblLoginSubTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknCMPLoginLblTitleBgTransFont030303",
            "text": "Sign in to continue",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblLoginSubTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLoginSubTitle"), extendConfig({}, controller.args[2], "lblLoginSubTitle"));
        var flxUserId = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "46dp",
            "id": "flxUserId",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "25dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxUserId"), extendConfig({}, controller.args[1], "flxUserId"), extendConfig({}, controller.args[2], "flxUserId"));
        flxUserId.setDefaultUnit(kony.flex.DP);
        var animatedtext = new com.konysa.animatedtext(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "animatedtext",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknCMPMaskTextFlxWhiteBG",
            "width": "100%",
            "overrides": {
                "animatedtext": {
                    "right": "viz.val_cleared",
                    "top": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared"
                }
            }
        }, controller.args[0], "animatedtext"), extendConfig({
            "overrides": {}
        }, controller.args[1], "animatedtext"), extendConfig({
            "overrides": {}
        }, controller.args[2], "animatedtext"));
        flxUserId.add(animatedtext);
        var flxPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "46dp",
            "id": "flxPassword",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "24dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxPassword"), extendConfig({}, controller.args[1], "flxPassword"), extendConfig({}, controller.args[2], "flxPassword"));
        flxPassword.setDefaultUnit(kony.flex.DP);
        var masktext = new com.konysa.masktext(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "masktext",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknCMPMaskTextFlxWhiteBG",
            "width": "100%",
            "overrides": {
                "masktext": {
                    "right": "viz.val_cleared",
                    "top": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared"
                }
            }
        }, controller.args[0], "masktext"), extendConfig({
            "overrides": {}
        }, controller.args[1], "masktext"), extendConfig({
            "overrides": {}
        }, controller.args[2], "masktext"));
        flxPassword.add(masktext);
        var flxForgotPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxForgotPassword",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "sknCMPMaskTextFlxBGTransCursorPointer",
            "top": "10dp",
            "width": "130dp",
            "zIndex": 1
        }, controller.args[0], "flxForgotPassword"), extendConfig({}, controller.args[1], "flxForgotPassword"), extendConfig({}, controller.args[2], "flxForgotPassword"));
        flxForgotPassword.setDefaultUnit(kony.flex.DP);
        var lblForgotPassword = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblForgotPassword",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknCMPLoginLblBGTransFont5968eeSize100",
            "text": "Forgot password?",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblForgotPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblForgotPassword"), extendConfig({}, controller.args[2], "lblForgotPassword"));
        flxForgotPassword.add(lblForgotPassword);
        var flxSignIn = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "42dp",
            "id": "flxSignIn",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_a38522ae64df4585b14933f8f30278a8,
            "skin": "FlexBG575ee7BorderRadius4",
            "top": "15dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxSignIn"), extendConfig({}, controller.args[1], "flxSignIn"), extendConfig({
            "hoverSkin": "FlexBG575ee7BorderRadius4"
        }, controller.args[2], "flxSignIn"));
        flxSignIn.setDefaultUnit(kony.flex.DP);
        var lblSignIn = new kony.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "id": "lblSignIn",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknCMPLoginLblBGTransFontWhite",
            "text": "Sign In",
            "top": "12dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblSignIn"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSignIn"), extendConfig({}, controller.args[2], "lblSignIn"));
        flxSignIn.add(lblSignIn);
        normallogin.add(lblLoginSubTitle, flxUserId, flxPassword, flxForgotPassword, flxSignIn);
        return normallogin;
    }
})
;
define('com/konysa/normallogin/normalloginConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": ["loginSuccess", "loginFailure", "errorCallback"]
    }
});

define("CopyflxMain0f0004db7fa7f48", [],function() {
    return function(controller) {
        var CopyflxMain0f0004db7fa7f48 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70dp",
            "id": "CopyflxMain0f0004db7fa7f48",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyCopyslFbox0e60a31ccbacb42",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        CopyflxMain0f0004db7fa7f48.setDefaultUnit(kony.flex.DP);
        var flxSubContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "80%",
            "id": "flxSubContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "40dp",
            "isModalContainer": false,
            "skin": "CopyCopyslFbox0jf9c7733368948",
            "top": "14dp",
            "width": "92%",
            "zIndex": 1
        }, {}, {});
        flxSubContainer.setDefaultUnit(kony.flex.DP);
        var Image0b6f7aa5bda1145 = new kony.ui.Image2({
            "centerY": "50%",
            "height": "24dp",
            "id": "Image0b6f7aa5bda1145",
            "isVisible": true,
            "left": "16dp",
            "skin": "slImage",
            "src": "trackerblue_1.png",
            "width": "24dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDeparturePoints = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblDeparturePoints",
            "isVisible": true,
            "left": "16dp",
            "skin": "CopylblCarName",
            "text": "Label",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSubContainer.add(Image0b6f7aa5bda1145, lblDeparturePoints);
        var FlexContainer0g94eb4bcc7804f = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "1dp",
            "id": "FlexContainer0g94eb4bcc7804f",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyCopyslFbox0j720c1e2271a4e",
            "top": "0",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        FlexContainer0g94eb4bcc7804f.setDefaultUnit(kony.flex.DP);
        FlexContainer0g94eb4bcc7804f.add();
        CopyflxMain0f0004db7fa7f48.add(flxSubContainer, FlexContainer0g94eb4bcc7804f);
        return CopyflxMain0f0004db7fa7f48;
    }
})
;
define("flxParent", [],function() {
    return function(controller) {
        var flxParent = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxParent",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "flxTempSkn",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {
            "hoverSkin": "hoverSkin"
        });
        flxParent.setDefaultUnit(kony.flex.DP);
        var lblPlaceData = new kony.ui.Label({
            "bottom": "2dp",
            "centerX": "42.50%",
            "id": "lblPlaceData",
            "isVisible": true,
            "left": "4%",
            "skin": "templateLblSkn",
            "text": "Label",
            "top": "2dp",
            "width": "80%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxParent.add(lblPlaceData);
        return flxParent;
    }
})
;
define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate"
        }, {}, {});
        flxSampleRowTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new kony.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new kony.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate"
        }, {}, {});
        flxSectionHeaderTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("flxRootJourneyCard", [],function() {
    return function(controller) {
        var flxRootJourneyCard = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRootJourneyCard",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "segTempSkin",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxRootJourneyCard.setDefaultUnit(kony.flex.DP);
        var flxContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "1dp",
            "isModalContainer": false,
            "right": "30dp",
            "skin": "backgroundColorSkn",
            "top": "10dp",
            "width": "99.50%",
            "zIndex": 1
        }, {}, {});
        flxContainer.setDefaultUnit(kony.flex.DP);
        var flxRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "1dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "1dp",
            "width": "99.70%",
            "zIndex": 1
        }, {}, {
            "hoverSkin": "listHoverSkn"
        });
        flxRoot.setDefaultUnit(kony.flex.DP);
        var flxCheckIn = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxCheckIn",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "5.47%",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_d0f504e5e048407486c97ecdf231eb96,
            "skin": "slFbox",
            "top": "15dp",
            "width": "36dp",
            "zIndex": 5
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxCheckIn.setDefaultUnit(kony.flex.DP);
        var imgCheckIn = new kony.ui.Image2({
            "height": "100%",
            "id": "imgCheckIn",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "chechbox_unselected.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxCheckIn.add(imgCheckIn);
        var flxJourneyCardHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "35dp",
            "id": "flxJourneyCardHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "7%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "95%",
            "zIndex": 1
        }, {}, {});
        flxJourneyCardHeader.setDefaultUnit(kony.flex.DP);
        var lblDriverName = new kony.ui.Label({
            "id": "lblDriverName",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "text": "Peter Oliver",
            "top": "8dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxMenu = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "20dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "24dp",
            "zIndex": 1
        }, {}, {});
        flxMenu.setDefaultUnit(kony.flex.DP);
        var imgMenu = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgMenu",
            "isVisible": true,
            "skin": "slImage",
            "src": "menu_icon.png",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxMenu.add(imgMenu);
        var lblJourneyStatus = new kony.ui.Label({
            "height": "24dp",
            "id": "lblJourneyStatus",
            "isVisible": true,
            "left": "65%",
            "text": "Normal",
            "top": "5dp",
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [2, 0, 2, 0],
            "paddingInPixel": false
        }, {});
        flxJourneyCardHeader.add(lblDriverName, flxMenu, lblJourneyStatus);
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "7%",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "55dp",
            "width": "95%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblLastKonwnLocationTitle = new kony.ui.Label({
            "id": "lblLastKonwnLocationTitle",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "Last Known Location",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblETA = new kony.ui.Label({
            "id": "lblETA",
            "isVisible": true,
            "left": "65%",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "ETA",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTitle.add(lblLastKonwnLocationTitle, lblETA);
        var flxLocationTime = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxLocationTime",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "7%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "75dp",
            "width": "95%",
            "zIndex": 1
        }, {}, {});
        flxLocationTime.setDefaultUnit(kony.flex.DP);
        var lblLastKnownLocation = new kony.ui.Label({
            "id": "lblLastKnownLocation",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "10 Georgetown Street",
            "top": "0dp",
            "width": "52.50%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "left": "65%",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "28 Jun, 16:10 PM",
            "top": "0dp",
            "width": "30%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxLocationTime.add(lblLastKnownLocation, lblTime);
        var flxActionRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxActionRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "160dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxActionRoot.setDefaultUnit(kony.flex.DP);
        var flxAction = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "40dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "49dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_heb42ba6a2f049779f75d268611edf6c,
            "right": "30dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "width": "40%",
            "zIndex": 1
        }, {}, {});
        flxAction.setDefaultUnit(kony.flex.DP);
        var lblActionText = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblActionText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhite",
            "text": "Contact Supervisor",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxAction.add(lblActionText);
        flxActionRoot.add(flxAction);
        var lblFooter2 = new kony.ui.Label({
            "height": "5dp",
            "id": "lblFooter2",
            "isVisible": true,
            "left": "0",
            "skin": "defLabel",
            "top": "160dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblEmailID = new kony.ui.Label({
            "height": "0px",
            "id": "lblEmailID",
            "isVisible": true,
            "left": "0%",
            "skin": "defLabel",
            "top": "0%",
            "width": "0%",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxRoot.add(flxCheckIn, flxJourneyCardHeader, flxTitle, flxLocationTime, flxActionRoot, lblFooter2, lblEmailID);
        var lblShadow = new kony.ui.Label({
            "height": "4dp",
            "id": "lblShadow",
            "isVisible": true,
            "left": "27dp",
            "skin": "lblWhiteSkn",
            "text": "helloWorld",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxContainer.add(flxRoot, lblShadow);
        flxRootJourneyCard.add(flxContainer);
        return flxRootJourneyCard;
    }
})
;
define("flxNotificationRoot", [],function() {
    return function(controller) {
        var flxNotificationRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "104dp",
            "id": "flxNotificationRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxNotificationRoot.setDefaultUnit(kony.flex.DP);
        var flxNotificationIcon = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxNotificationIcon",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "28dp",
            "zIndex": 1
        }, {}, {});
        flxNotificationIcon.setDefaultUnit(kony.flex.DP);
        var lblNotificationSymbol = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "12dp",
            "id": "lblNotificationSymbol",
            "isVisible": true,
            "skin": "sknLblBG575ee7Radius100",
            "width": "12dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxNotificationIcon.add(lblNotificationSymbol);
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "22dp",
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "30dp",
            "isModalContainer": false,
            "right": "35dp",
            "skin": "slFbox",
            "top": "20dp",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblNotificationMsg = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblNotificationMsg",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGC96866FontWhiteSize",
            "text": "Incident Reported",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [2, 0, 2, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblTime",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknLblBGTransFont6d6d6dSize88",
            "text": "Just Now",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTitle.add(lblNotificationMsg, lblTime);
        var lblMsg = new kony.ui.Label({
            "height": "32dp",
            "id": "lblMsg",
            "isVisible": true,
            "left": "30dp",
            "right": "35dp",
            "skin": "sknLblBGTransFont30353fSize88TypeMedium",
            "text": "John Doe send an Emergency Status for his journey",
            "top": "52dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxNotificationRoot.add(flxNotificationIcon, flxTitle, lblMsg);
        return flxNotificationRoot;
    }
})
;
define("flxSegTmpAddPassenger", [],function() {
    return function(controller) {
        var flxSegTmpAddPassenger = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "250dp",
            "id": "flxSegTmpAddPassenger",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxSegTmpAddPassenger.setDefaultUnit(kony.flex.DP);
        var flxAddPassenger = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "250dp",
            "id": "flxAddPassenger",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0d8cb57ce020949",
            "top": "0dp",
            "width": "390px",
            "zIndex": 1
        }, {}, {});
        flxAddPassenger.setDefaultUnit(kony.flex.DP);
        var lblPassenger = new kony.ui.Label({
            "height": "31dp",
            "id": "lblPassenger",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyCopydefLabel0ffdcfdc6e6994c",
            "text": "Passenger",
            "top": "14dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblPassengerName = new kony.ui.Label({
            "height": "16px",
            "id": "lblPassengerName",
            "isVisible": true,
            "left": "0px",
            "skin": "CopylblName",
            "text": "Name",
            "top": 70,
            "width": "300px",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var txtPassengerName = new kony.ui.TextBox2({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "defTextBoxFocus",
            "height": "48px",
            "id": "txtPassengerName",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0px",
            "placeholder": "Enter Your Name",
            "secureTextEntry": false,
            "skin": "CopyCopydefTextBoxNormal1",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": 90,
            "width": "371px",
            "zIndex": 1
        }, {
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "autoCorrect": false,
            "placeholderSkin": "defTextBoxPlaceholder"
        });
        var lblPassengerMobile = new kony.ui.Label({
            "height": "16px",
            "id": "lblPassengerMobile",
            "isVisible": true,
            "left": "0px",
            "skin": "CopylblName",
            "text": "Mobile",
            "top": 150,
            "width": "300px",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var txtPassengerMobile = new kony.ui.TextBox2({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "defTextBoxFocus",
            "height": "48px",
            "id": "txtPassengerMobile",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0px",
            "placeholder": "Mobile Number",
            "secureTextEntry": false,
            "skin": "CopyCopydefTextBoxNormal1",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": 170,
            "width": "371px",
            "zIndex": 1
        }, {
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "autoCorrect": false,
            "placeholderSkin": "defTextBoxPlaceholder"
        });
        var imgAddPassenger = new kony.ui.Image2({
            "height": "31dp",
            "id": "imgAddPassenger",
            "isVisible": true,
            "left": "335dp",
            "onTouchEnd": controller.AS_Image_db6f34de40d84f7d9653aa86d4cb01bb,
            "skin": "slImage",
            "src": "crossimageblue.png",
            "top": "20dp",
            "width": "31dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxAddPassenger.add(lblPassenger, lblPassengerName, txtPassengerName, lblPassengerMobile, txtPassengerMobile, imgAddPassenger);
        flxSegTmpAddPassenger.add(flxAddPassenger);
        return flxSegTmpAddPassenger;
    }
})
;
define("flxEscalationRoot", [],function() {
    return function(controller) {
        var flxEscalationRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxEscalationRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxEscalationRoot.setDefaultUnit(kony.flex.DP);
        var flxNoteRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxNoteRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "33dp",
            "isModalContainer": false,
            "right": "17dp",
            "skin": "slFbox",
            "top": "0dp",
            "zIndex": 1
        }, {}, {});
        flxNoteRoot.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label({
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBGTransFont30353fSize88TypeMedium",
            "text": "Contact Traveler",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var rchTxtDesc = new kony.ui.RichText({
            "height": "86dp",
            "id": "rchTxtDesc",
            "isVisible": true,
            "left": "0dp",
            "linkSkin": "defRichTextLink",
            "skin": "sknRchTextBGTransFont6a6a6a",
            "text": "You will be pushed to contact the Travelere, if you succeed you will be able to close the Escalation case. If you were <b>NOT</b> able to contact the traveler, you will provide status information. This information will be saved on the details profile of the journey.",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxNoteRoot.add(lblTitle, rchTxtDesc);
        var flxLine = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxLine",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, {}, {});
        flxLine.setDefaultUnit(kony.flex.DP);
        var flxBoxContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "20dp",
            "id": "flxBoxContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 5
        }, {}, {});
        flxBoxContainer.setDefaultUnit(kony.flex.DP);
        var lblWhiteShado = new kony.ui.Label({
            "centerX": "50%",
            "height": "20dp",
            "id": "lblWhiteShado",
            "isVisible": true,
            "skin": "sknLblBGWhiteBorederf5f5f5Radius100Font797fecSize75",
            "text": "1",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxBoxContainer.add(lblWhiteShado);
        var flxDasshedLine = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "110dp",
            "id": "flxDasshedLine",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "8dp",
            "isModalContainer": false,
            "skin": "sknFlxBGTransBorder575ee7Dasshed",
            "top": "0dp",
            "width": "2dp",
            "zIndex": 1
        }, {}, {});
        flxDasshedLine.setDefaultUnit(kony.flex.DP);
        var lblDUmmey = new kony.ui.Label({
            "id": "lblDUmmey",
            "isVisible": true,
            "left": "4dp",
            "skin": "defLabel",
            "text": "Label",
            "top": "72dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxDasshedLine.add(lblDUmmey);
        flxLine.add(flxBoxContainer, flxDasshedLine);
        flxEscalationRoot.add(flxNoteRoot, flxLine);
        return flxEscalationRoot;
    }
})
;
define("flxPathRoot", [],function() {
    return function(controller) {
        var flxPathRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxPathRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxPathRoot.setDefaultUnit(kony.flex.DP);
        var lblLine0 = new kony.ui.Label({
            "height": "30dp",
            "id": "lblLine0",
            "isVisible": true,
            "left": "8dp",
            "skin": "sknLblBG575ee7",
            "top": "0dp",
            "width": "1dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxLastKnownLocation = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "16dp",
            "id": "flxLastKnownLocation",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxLastKnownLocation.setDefaultUnit(kony.flex.DP);
        var lblLine1 = new kony.ui.Label({
            "bottom": "0dp",
            "id": "lblLine1",
            "isVisible": true,
            "left": "8dp",
            "skin": "sknLblBG575ee7",
            "top": "0dp",
            "width": "1dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblLastKnownLocation = new kony.ui.Label({
            "bottom": "0dp",
            "centerY": "50%",
            "id": "lblLastKnownLocation",
            "isVisible": true,
            "left": "30dp",
            "skin": "sknLblBGTransFont575ee7Size88",
            "text": "Last Known Location",
            "width": "155dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxLastKnownLocation.add(lblLine1, lblLastKnownLocation);
        var flxPathContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "16dp",
            "id": "flxPathContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxPathContainer.setDefaultUnit(kony.flex.DP);
        var flxPathIcon = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0dp",
            "clipBounds": true,
            "height": "16dp",
            "id": "flxPathIcon",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBG575ee7Border575ee7Radiu100",
            "width": "16dp",
            "zIndex": 5
        }, {}, {});
        flxPathIcon.setDefaultUnit(kony.flex.DP);
        var imgPathIcon = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgPathIcon",
            "isVisible": true,
            "skin": "slImage",
            "src": "location_white.png",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxPathIcon.add(imgPathIcon);
        var lblLocation = new kony.ui.Label({
            "bottom": "0dp",
            "centerY": "50%",
            "height": "16dp",
            "id": "lblLocation",
            "isVisible": true,
            "left": "30dp",
            "skin": "sknLblBGTransFont30353fSize100TypeMedium",
            "text": "221 Presidential Street",
            "width": "250dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "bottom": "0dp",
            "height": "20dp",
            "id": "lblTime",
            "isVisible": true,
            "right": "19dp",
            "skin": "sknLblBGTransFont6d6d6dSize88",
            "text": "14:10",
            "width": "35dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_RIGHT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgClock = new kony.ui.Image2({
            "bottom": "0dp",
            "height": "16dp",
            "id": "imgClock",
            "isVisible": true,
            "right": "59dp",
            "skin": "slImage",
            "src": "clock_2.png",
            "width": "16dp",
            "zIndex": 5
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDate = new kony.ui.Label({
            "bottom": "0dp",
            "id": "lblDate",
            "isVisible": true,
            "right": "80dp",
            "skin": "sknLblBGTransFont6d6d6dSize88",
            "text": "24 Jun",
            "width": "50dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_RIGHT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgVechile = new kony.ui.Image2({
            "bottom": "0dp",
            "height": "16dp",
            "id": "imgVechile",
            "isVisible": true,
            "right": "135dp",
            "skin": "slImage",
            "src": "vechile.png",
            "width": "16dp",
            "zIndex": 5
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxPathContainer.add(flxPathIcon, lblLocation, lblTime, imgClock, lblDate, imgVechile);
        flxPathRoot.add(lblLine0, flxLastKnownLocation, flxPathContainer);
        return flxPathRoot;
    }
})
;
define("flxRootProcessStatusDW", [],function() {
    return function(controller) {
        var flxRootProcessStatusDW = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "52dp",
            "id": "flxRootProcessStatusDW",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        flxRootProcessStatusDW.setDefaultUnit(kony.flex.DP);
        var flxTracker = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "100%",
            "id": "flxTracker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "40dp",
            "zIndex": 1
        }, {}, {});
        flxTracker.setDefaultUnit(kony.flex.DP);
        var lblUp = new kony.ui.Label({
            "centerX": "50%",
            "height": "50%",
            "id": "lblUp",
            "isVisible": true,
            "skin": "sknCMPProcessStatusBGTransFont575ee7Size",
            "top": "0dp",
            "width": "1dp",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblIndex = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "32dp",
            "id": "lblIndex",
            "isVisible": true,
            "skin": "sknCMPProcessStatusLblBGWhiteFont575ee7Size113Border",
            "text": "1",
            "width": "32dp",
            "zIndex": 5
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDown = new kony.ui.Label({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "50%",
            "id": "lblDown",
            "isVisible": true,
            "skin": "sknCMPProcessStatusBGTransFont575ee7Size",
            "width": "1dp",
            "zIndex": 1,
            "blur": {
                "enabled": false,
                "value": 0
            }
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTracker.add(lblUp, lblIndex, lblDown);
        var lblProcess = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblProcess",
            "isVisible": true,
            "left": "6dp",
            "skin": "sknCMPProcessStatusLblBGTransFon575ee7tSize113",
            "text": "Traveler Details",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxRootProcessStatusDW.add(flxTracker, lblProcess);
        return flxRootProcessStatusDW;
    }
})
;
define("Flex0ab488ced76e94b", [],function() {
    return function(controller) {
        var Flex0ab488ced76e94b = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "Flex0ab488ced76e94b",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0je516648bf1343",
            "top": "0dp",
            "width": "100%"
        }, {}, {
            "hoverSkin": "listHoverSkn"
        });
        Flex0ab488ced76e94b.setDefaultUnit(kony.flex.DP);
        var lblTrackingPoint = new kony.ui.Label({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblTrackingPoint",
            "isVisible": true,
            "left": "5%",
            "skin": "CopydefLabel0b05ca5d8e47b4d",
            "text": "tracking Point",
            "top": "0dp",
            "width": "60%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgSelection = new kony.ui.Image2({
            "centerY": "50%",
            "height": "20dp",
            "id": "imgSelection",
            "isVisible": true,
            "left": "20%",
            "skin": "slImage",
            "src": "defaultdeselect_2.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Flex0ab488ced76e94b.add(lblTrackingPoint, imgSelection);
        return Flex0ab488ced76e94b;
    }
})
;
define("CopyflxMapTemplate0cad7fd75f04947", [],function() {
    return function(controller) {
        var CopyflxMapTemplate0cad7fd75f04947 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "CopyflxMapTemplate0cad7fd75f04947",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "372px"
        }, {}, {});
        CopyflxMapTemplate0cad7fd75f04947.setDefaultUnit(kony.flex.DP);
        var flxRootJourneyCard = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRootJourneyCard",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372dp"
        }, {}, {});
        flxRootJourneyCard.setDefaultUnit(kony.flex.DP);
        var flxContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "30dp",
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372px",
            "zIndex": 1
        }, {}, {});
        flxContainer.setDefaultUnit(kony.flex.DP);
        var flxRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxRoot.setDefaultUnit(kony.flex.DP);
        var lblJourneyId = new kony.ui.Label({
            "height": "20dp",
            "id": "lblJourneyId",
            "isVisible": true,
            "left": "51dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxJourneyCardHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxJourneyCardHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "6dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxJourneyCardHeader.setDefaultUnit(kony.flex.DP);
        var lblDriverName = new kony.ui.Label({
            "id": "lblDriverName",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "text": "Peter Oliver",
            "top": "8dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxMenu = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "20dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "24dp",
            "zIndex": 1
        }, {}, {});
        flxMenu.setDefaultUnit(kony.flex.DP);
        flxMenu.add();
        var lblJourneyStatus = new kony.ui.Label({
            "height": "24dp",
            "id": "lblJourneyStatus",
            "isVisible": true,
            "right": "54dp",
            "text": "Normal",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [2, 0, 2, 0],
            "paddingInPixel": false
        }, {});
        flxJourneyCardHeader.add(lblDriverName, flxMenu, lblJourneyStatus);
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblLastKonwnLocationTitle = new kony.ui.Label({
            "id": "lblLastKonwnLocationTitle",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "Last Known Location",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblETA = new kony.ui.Label({
            "id": "lblETA",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "ETA",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTitle.add(lblLastKonwnLocationTitle, lblETA);
        var flxLocationTime = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxLocationTime",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxLocationTime.setDefaultUnit(kony.flex.DP);
        var lblLastKnownLocation = new kony.ui.Label({
            "id": "lblLastKnownLocation",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "10 Georgetown Street",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "28 Jun, 16:10 PM",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxLocationTime.add(lblLastKnownLocation, lblTime);
        var flxActionRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "20dp",
            "clipBounds": true,
            "height": "44dp",
            "id": "flxActionRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxActionRoot.setDefaultUnit(kony.flex.DP);
        var flxAction = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "49dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_j466c6d64f884425bfa485d361c7ee3e,
            "right": "30dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "zIndex": 1
        }, {}, {});
        flxAction.setDefaultUnit(kony.flex.DP);
        var lblActionText = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblActionText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhite",
            "text": "View Details",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxAction.add(lblActionText);
        flxActionRoot.add(flxAction);
        var Label0h31fc0f2c2c547 = new kony.ui.Label({
            "height": "20dp",
            "id": "Label0h31fc0f2c2c547",
            "isVisible": true,
            "left": "51dp",
            "skin": "defLabel",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxRoot.add(lblJourneyId, flxJourneyCardHeader, flxTitle, flxLocationTime, flxActionRoot, Label0h31fc0f2c2c547);
        flxContainer.add(flxRoot);
        flxRootJourneyCard.add(flxContainer);
        CopyflxMapTemplate0cad7fd75f04947.add(flxRootJourneyCard);
        return CopyflxMapTemplate0cad7fd75f04947;
    }
})
;
define("CopyflxMapTemplate0a0ff65a9bba142", [],function() {
    return function(controller) {
        var CopyflxMapTemplate0a0ff65a9bba142 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "CopyflxMapTemplate0a0ff65a9bba142",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "372px"
        }, {}, {});
        CopyflxMapTemplate0a0ff65a9bba142.setDefaultUnit(kony.flex.DP);
        var flxRootJourneyCard = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRootJourneyCard",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372dp"
        }, {}, {});
        flxRootJourneyCard.setDefaultUnit(kony.flex.DP);
        var flxContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "30dp",
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372px",
            "zIndex": 1
        }, {}, {});
        flxContainer.setDefaultUnit(kony.flex.DP);
        var flxRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxRoot.setDefaultUnit(kony.flex.DP);
        var lblJourneyId = new kony.ui.Label({
            "height": "20dp",
            "id": "lblJourneyId",
            "isVisible": true,
            "left": "51dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxJourneyCardHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxJourneyCardHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "6dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxJourneyCardHeader.setDefaultUnit(kony.flex.DP);
        var lblDriverName = new kony.ui.Label({
            "id": "lblDriverName",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "text": "Peter Oliver",
            "top": "8dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxMenu = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "20dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "24dp",
            "zIndex": 1
        }, {}, {});
        flxMenu.setDefaultUnit(kony.flex.DP);
        flxMenu.add();
        var lblJourneyStatus = new kony.ui.Label({
            "height": "24px",
            "id": "lblJourneyStatus",
            "isVisible": true,
            "right": "54dp",
            "skin": "sknLblJourneyStatusNormal",
            "text": "Normal",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxJourneyCardHeader.add(lblDriverName, flxMenu, lblJourneyStatus);
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblLastKonwnLocationTitle = new kony.ui.Label({
            "id": "lblLastKonwnLocationTitle",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "Last Known Location",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblETA = new kony.ui.Label({
            "id": "lblETA",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "ETA",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTitle.add(lblLastKonwnLocationTitle, lblETA);
        var flxLocationTime = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxLocationTime",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxLocationTime.setDefaultUnit(kony.flex.DP);
        var lblLastKnownLocation = new kony.ui.Label({
            "id": "lblLastKnownLocation",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "10 Georgetown Street",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "28 Jun, 16:10 PM",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxLocationTime.add(lblLastKnownLocation, lblTime);
        var flxActionRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "20dp",
            "clipBounds": true,
            "height": "44dp",
            "id": "flxActionRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxActionRoot.setDefaultUnit(kony.flex.DP);
        var flxAction = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "49dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_ed5768941bbb4118b05e134e372a9acc,
            "right": "30dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "zIndex": 1
        }, {}, {});
        flxAction.setDefaultUnit(kony.flex.DP);
        var lblActionText = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblActionText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhite",
            "text": "View Details",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxAction.add(lblActionText);
        flxActionRoot.add(flxAction);
        var Label0h31fc0f2c2c547 = new kony.ui.Label({
            "height": "20dp",
            "id": "Label0h31fc0f2c2c547",
            "isVisible": true,
            "left": "51dp",
            "skin": "defLabel",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxRoot.add(lblJourneyId, flxJourneyCardHeader, flxTitle, flxLocationTime, flxActionRoot, Label0h31fc0f2c2c547);
        flxContainer.add(flxRoot);
        flxRootJourneyCard.add(flxContainer);
        CopyflxMapTemplate0a0ff65a9bba142.add(flxRootJourneyCard);
        return CopyflxMapTemplate0a0ff65a9bba142;
    }
})
;
define("flxMapTemplate", [],function() {
    return function(controller) {
        var flxMapTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxMapTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "372px"
        }, {}, {});
        flxMapTemplate.setDefaultUnit(kony.flex.DP);
        var flxRootJourneyCard1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRootJourneyCard1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372dp"
        }, {}, {});
        flxRootJourneyCard1.setDefaultUnit(kony.flex.DP);
        var flxContainer1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContainer1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "right": "30dp",
            "skin": "sknFlxBGFAFAFA",
            "top": "0dp",
            "width": "372px",
            "zIndex": 1
        }, {}, {});
        flxContainer1.setDefaultUnit(kony.flex.DP);
        var flxRoot1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRoot1",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBGWhiteBoxShadow",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxRoot1.setDefaultUnit(kony.flex.DP);
        var lblJourneyId = new kony.ui.Label({
            "height": "20dp",
            "id": "lblJourneyId",
            "isVisible": true,
            "left": "51dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "top": "10dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxJourneyCardHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxJourneyCardHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "6dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxJourneyCardHeader.setDefaultUnit(kony.flex.DP);
        var lblDriverName = new kony.ui.Label({
            "id": "lblDriverName",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize113",
            "text": "Peter Oliver",
            "top": "8dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxMenu = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24dp",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "20dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "24dp",
            "zIndex": 1
        }, {}, {});
        flxMenu.setDefaultUnit(kony.flex.DP);
        flxMenu.add();
        var lblJourneyStatus = new kony.ui.Label({
            "height": "24px",
            "id": "lblJourneyStatus",
            "isVisible": true,
            "right": "54dp",
            "skin": "sknLblJourneyStatusNormal",
            "text": "Normal",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxJourneyCardHeader.add(lblDriverName, flxMenu, lblJourneyStatus);
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblLastKonwnLocationTitle = new kony.ui.Label({
            "id": "lblLastKonwnLocationTitle",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "Last Known Location",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblETA = new kony.ui.Label({
            "id": "lblETA",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize88",
            "text": "ETA",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTitle.add(lblLastKonwnLocationTitle, lblETA);
        var flxLocationTime = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxLocationTime",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "0dp",
            "skin": "slFbox",
            "top": "5dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxLocationTime.setDefaultUnit(kony.flex.DP);
        var lblLastKnownLocation = new kony.ui.Label({
            "id": "lblLastKnownLocation",
            "isVisible": true,
            "left": "49dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "10 Georgetown Street",
            "top": "0dp",
            "width": "146dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "30dp",
            "skin": "sknLblBgTransFont3d3d3dSize100",
            "text": "28 Jun, 16:10 PM",
            "top": "0dp",
            "width": "122dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxLocationTime.add(lblLastKnownLocation, lblTime);
        var flxActionRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "20dp",
            "clipBounds": true,
            "height": "44dp",
            "id": "flxActionRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxActionRoot.setDefaultUnit(kony.flex.DP);
        var flxAction = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "44dp",
            "id": "flxAction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "49dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_fe7bfeb808e94c21811e1c43b5bcf910,
            "right": "30dp",
            "skin": "sknFlxBG575ee7Border42",
            "top": "0dp",
            "zIndex": 1
        }, {}, {});
        flxAction.setDefaultUnit(kony.flex.DP);
        var lblActionText = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblActionText",
            "isVisible": true,
            "skin": "sknLblBGTransFontWhite",
            "text": "View Details",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxAction.add(lblActionText);
        flxActionRoot.add(flxAction);
        var Label0h31fc0f2c2c547 = new kony.ui.Label({
            "height": "20dp",
            "id": "Label0h31fc0f2c2c547",
            "isVisible": true,
            "left": "51dp",
            "skin": "defLabel",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxRoot1.add(lblJourneyId, flxJourneyCardHeader, flxTitle, flxLocationTime, flxActionRoot, Label0h31fc0f2c2c547);
        flxContainer1.add(flxRoot1);
        flxRootJourneyCard1.add(flxContainer1);
        flxMapTemplate.add(flxRootJourneyCard1);
        return flxMapTemplate;
    }
})
;
define("userCopyflxMain0f0004db7fa7f48Controller", {
    //Type your controller code here 
});
define("CopyflxMain0f0004db7fa7f48ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("CopyflxMain0f0004db7fa7f48Controller", ["userCopyflxMain0f0004db7fa7f48Controller", "CopyflxMain0f0004db7fa7f48ControllerActions"], function() {
    var controller = require("userCopyflxMain0f0004db7fa7f48Controller");
    var controllerActions = ["CopyflxMain0f0004db7fa7f48ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxParentController", {
    //Type your controller code here 
});
define("flxParentControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxParentController", ["userflxParentController", "flxParentControllerActions"], function() {
    var controller = require("userflxParentController");
    var controllerActions = ["flxParentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxRootJourneyCardController", {
    //Type your controller code here 
    onActionButtonClick: function(eventobject, context) {
        // kony.print("context ::"+JSON.stringify(context));
        nextCheckPointSeqNumber = context["widgetInfo"]["selectedRowItems"][0]["nextCheckPointSeqNumber"];
        selectedJourneyId = context["widgetInfo"]["selectedRowItems"][0]["journey_id"];
        selectedJourneyStatus = context["widgetInfo"]["selectedRowItems"][0]["journeyStatus"]["text"];
        selectedCheckPointRowId = context["widgetInfo"]["selectedRowItems"][0]["nextCheckpoint_row_id_pk"];
        selectedIncindet_Id = context["widgetInfo"]["selectedRowItems"][0]["incidentId"];
        expected_Nextcheckin_timestamp_UTC = context["widgetInfo"]["selectedRowItems"][0]["expected_Nextcheckin_timestamp_UTC"];
        checkin_interval_row_id = context["widgetInfo"]["selectedRowItems"][0]["checkin_interval_row_id_fk"];
        this.executeOnParent("onClickOfFlxAction");
    },
});
define("flxRootJourneyCardControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxCheckIn **/
    AS_FlexContainer_d0f504e5e048407486c97ecdf231eb96: function AS_FlexContainer_d0f504e5e048407486c97ecdf231eb96(eventobject, context) {
        var self = this;
        this.executeOnParent("enableNotifyButton");
    },
    /** onClick defined for flxAction **/
    AS_FlexContainer_heb42ba6a2f049779f75d268611edf6c: function AS_FlexContainer_heb42ba6a2f049779f75d268611edf6c(eventobject, context) {
        var self = this;
        this.onActionButtonClick(eventobject, context);
    }
});
define("flxRootJourneyCardController", ["userflxRootJourneyCardController", "flxRootJourneyCardControllerActions"], function() {
    var controller = require("userflxRootJourneyCardController");
    var controllerActions = ["flxRootJourneyCardControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxNotificationRootController", {
    //Type your controller code here 
});
define("flxNotificationRootControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxNotificationRootController", ["userflxNotificationRootController", "flxNotificationRootControllerActions"], function() {
    var controller = require("userflxNotificationRootController");
    var controllerActions = ["flxNotificationRootControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSegTmpAddPassengerController", {
    removeAddedPassenger: function(eventObj) {
        var index = eventObj.rowContext.rowIndex;
        this.executeOnParent("deleteSelectedRow", index);
    }
});
define("flxSegTmpAddPassengerControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchEnd defined for imgAddPassenger **/
    AS_Image_db6f34de40d84f7d9653aa86d4cb01bb: function AS_Image_db6f34de40d84f7d9653aa86d4cb01bb(eventobject, x, y, context) {
        var self = this;
        this.removeAddedPassenger(eventobject, context);
    }
});
define("flxSegTmpAddPassengerController", ["userflxSegTmpAddPassengerController", "flxSegTmpAddPassengerControllerActions"], function() {
    var controller = require("userflxSegTmpAddPassengerController");
    var controllerActions = ["flxSegTmpAddPassengerControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxEscalationRootController", {
    //Type your controller code here 
});
define("flxEscalationRootControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxEscalationRootController", ["userflxEscalationRootController", "flxEscalationRootControllerActions"], function() {
    var controller = require("userflxEscalationRootController");
    var controllerActions = ["flxEscalationRootControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxPathRootController", {
    //Type your controller code here 
});
define("flxPathRootControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxPathRootController", ["userflxPathRootController", "flxPathRootControllerActions"], function() {
    var controller = require("userflxPathRootController");
    var controllerActions = ["flxPathRootControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxRootProcessStatusDWController", {
    //Type your controller code here 
});
define("flxRootProcessStatusDWControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxRootProcessStatusDWController", ["userflxRootProcessStatusDWController", "flxRootProcessStatusDWControllerActions"], function() {
    var controller = require("userflxRootProcessStatusDWController");
    var controllerActions = ["flxRootProcessStatusDWControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userFlex0ab488ced76e94bController", {
    //Type your controller code here 
});
define("Flex0ab488ced76e94bControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Flex0ab488ced76e94bController", ["userFlex0ab488ced76e94bController", "Flex0ab488ced76e94bControllerActions"], function() {
    var controller = require("userFlex0ab488ced76e94bController");
    var controllerActions = ["Flex0ab488ced76e94bControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userCopyflxMapTemplate0cad7fd75f04947Controller", {
    //Type your controller code here 
});
define("CopyflxMapTemplate0cad7fd75f04947ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxAction **/
    AS_FlexContainer_j466c6d64f884425bfa485d361c7ee3e: function AS_FlexContainer_j466c6d64f884425bfa485d361c7ee3e(eventobject, context) {
        var self = this;
        this.onActionButtonClick(eventobject, context);
    }
});
define("CopyflxMapTemplate0cad7fd75f04947Controller", ["userCopyflxMapTemplate0cad7fd75f04947Controller", "CopyflxMapTemplate0cad7fd75f04947ControllerActions"], function() {
    var controller = require("userCopyflxMapTemplate0cad7fd75f04947Controller");
    var controllerActions = ["CopyflxMapTemplate0cad7fd75f04947ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userCopyflxMapTemplate0a0ff65a9bba142Controller", {
    //Type your controller code here 
});
define("CopyflxMapTemplate0a0ff65a9bba142ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxAction **/
    AS_FlexContainer_ed5768941bbb4118b05e134e372a9acc: function AS_FlexContainer_ed5768941bbb4118b05e134e372a9acc(eventobject, context) {
        var self = this;
        this.onActionButtonClick(eventobject, context);
    }
});
define("CopyflxMapTemplate0a0ff65a9bba142Controller", ["userCopyflxMapTemplate0a0ff65a9bba142Controller", "CopyflxMapTemplate0a0ff65a9bba142ControllerActions"], function() {
    var controller = require("userCopyflxMapTemplate0a0ff65a9bba142Controller");
    var controllerActions = ["CopyflxMapTemplate0a0ff65a9bba142ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxMapTemplateController", {
    //Type your controller code here 
});
define("flxMapTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxAction **/
    AS_FlexContainer_fe7bfeb808e94c21811e1c43b5bcf910: function AS_FlexContainer_fe7bfeb808e94c21811e1c43b5bcf910(eventobject, context) {
        var self = this;
        this.onActionButtonClick(eventobject, context);
    }
});
define("flxMapTemplateController", ["userflxMapTemplateController", "flxMapTemplateControllerActions"], function() {
    var controller = require("userflxMapTemplateController");
    var controllerActions = ["flxMapTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define('JourneyObjSvc/ad_group_master_tbl/MF_Config',[], function() {
    var mappings = {
        "admin_flag": "admin_flag",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "group_id_pk": "group_id_pk",
        "group_name": "group_name",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "admin_flag": "number",
        "createdby": "string",
        "createddatetime": "date",
        "group_id_pk": "number",
        "group_name": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["group_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "ad_group_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/ad_group_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        admin_flag: function(val, state) {
            state['admin_flag'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        group_id_pk: function(val, state) {
            state['group_id_pk'] = val;
        },
        group_name: function(val, state) {
            state['group_name'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function ad_group_master_tbl(defaultValues) {
        var privateState = {};
        privateState.admin_flag = defaultValues ? (defaultValues["admin_flag"] ? defaultValues["admin_flag"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.group_id_pk = defaultValues ? (defaultValues["group_id_pk"] ? defaultValues["group_id_pk"] : null) : null;
        privateState.group_name = defaultValues ? (defaultValues["group_name"] ? defaultValues["group_name"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "admin_flag": {
                get: function() {
                    return privateState.admin_flag
                },
                set: function(val) {
                    setterFunctions['admin_flag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "group_id_pk": {
                get: function() {
                    return privateState.group_id_pk
                },
                set: function(val) {
                    throw Error("group_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "group_name": {
                get: function() {
                    return privateState.group_name
                },
                set: function(val) {
                    setterFunctions['group_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(ad_group_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(ad_group_master_tbl);
    var registerValidatorBackup = ad_group_master_tbl.registerValidator;
    ad_group_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (ad_group_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "ad_group_master_tbl_user_tbl",
        targetObject: "user_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "group_id_pk",
            targetField: "group_id_fk"
        }, ]
    }, ];
    ad_group_master_tbl.relations = relations;
    ad_group_master_tbl.prototype.isValid = function() {
        return ad_group_master_tbl.isValid(this);
    };
    ad_group_master_tbl.prototype.objModelName = "ad_group_master_tbl";
    return ad_group_master_tbl;
});

define('JourneyObjSvc/checkin_interval_master_tbl/MF_Config',[], function() {
    var mappings = {
        "checkin_interval_minutes": "checkin_interval_minutes",
        "checkin_interval_row_id_pk": "checkin_interval_row_id_pk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "checkin_interval_minutes": "number",
        "checkin_interval_row_id_pk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["checkin_interval_row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "checkin_interval_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/checkin_interval_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        checkin_interval_minutes: function(val, state) {
            state['checkin_interval_minutes'] = val;
        },
        checkin_interval_row_id_pk: function(val, state) {
            state['checkin_interval_row_id_pk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function checkin_interval_master_tbl(defaultValues) {
        var privateState = {};
        privateState.checkin_interval_minutes = defaultValues ? (defaultValues["checkin_interval_minutes"] ? defaultValues["checkin_interval_minutes"] : null) : null;
        privateState.checkin_interval_row_id_pk = defaultValues ? (defaultValues["checkin_interval_row_id_pk"] ? defaultValues["checkin_interval_row_id_pk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "checkin_interval_minutes": {
                get: function() {
                    return privateState.checkin_interval_minutes
                },
                set: function(val) {
                    setterFunctions['checkin_interval_minutes'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkin_interval_row_id_pk": {
                get: function() {
                    return privateState.checkin_interval_row_id_pk
                },
                set: function(val) {
                    throw Error("checkin_interval_row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(checkin_interval_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(checkin_interval_master_tbl);
    var registerValidatorBackup = checkin_interval_master_tbl.registerValidator;
    checkin_interval_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (checkin_interval_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "checkin_interval_master_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "checkin_interval_row_id_pk",
            targetField: "checkin_interval_row_id_fk"
        }, ]
    }, ];
    checkin_interval_master_tbl.relations = relations;
    checkin_interval_master_tbl.prototype.isValid = function() {
        return checkin_interval_master_tbl.isValid(this);
    };
    checkin_interval_master_tbl.prototype.objModelName = "checkin_interval_master_tbl";
    return checkin_interval_master_tbl;
});

define('JourneyObjSvc/checkin_type_master_tbl/MF_Config',[], function() {
    var mappings = {
        "checkin_type_desc": "checkin_type_desc",
        "checkin_type_id_pk": "checkin_type_id_pk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "checkin_type_desc": "string",
        "checkin_type_id_pk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["checkin_type_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "checkin_type_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/checkin_type_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        checkin_type_desc: function(val, state) {
            state['checkin_type_desc'] = val;
        },
        checkin_type_id_pk: function(val, state) {
            state['checkin_type_id_pk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function checkin_type_master_tbl(defaultValues) {
        var privateState = {};
        privateState.checkin_type_desc = defaultValues ? (defaultValues["checkin_type_desc"] ? defaultValues["checkin_type_desc"] : null) : null;
        privateState.checkin_type_id_pk = defaultValues ? (defaultValues["checkin_type_id_pk"] ? defaultValues["checkin_type_id_pk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "checkin_type_desc": {
                get: function() {
                    return privateState.checkin_type_desc
                },
                set: function(val) {
                    setterFunctions['checkin_type_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkin_type_id_pk": {
                get: function() {
                    return privateState.checkin_type_id_pk
                },
                set: function(val) {
                    throw Error("checkin_type_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(checkin_type_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(checkin_type_master_tbl);
    var registerValidatorBackup = checkin_type_master_tbl.registerValidator;
    checkin_type_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (checkin_type_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "checkin_type_master_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "checkin_type_id_pk",
            targetField: "checkin_type_id_fk"
        }, ]
    }, ];
    checkin_type_master_tbl.relations = relations;
    checkin_type_master_tbl.prototype.isValid = function() {
        return checkin_type_master_tbl.isValid(this);
    };
    checkin_type_master_tbl.prototype.objModelName = "checkin_type_master_tbl";
    return checkin_type_master_tbl;
});

define('JourneyObjSvc/checklist_questions_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "is_mandatory_to_answer": "is_mandatory_to_answer",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "question_id_pk": "question_id_pk",
        "question_text": "question_text",
        "question_type_id_fk": "question_type_id_fk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "is_mandatory_to_answer": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "question_id_pk": "number",
        "question_text": "string",
        "question_type_id_fk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["question_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "checklist_questions_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/checklist_questions_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        is_mandatory_to_answer: function(val, state) {
            state['is_mandatory_to_answer'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        question_id_pk: function(val, state) {
            state['question_id_pk'] = val;
        },
        question_text: function(val, state) {
            state['question_text'] = val;
        },
        question_type_id_fk: function(val, state) {
            state['question_type_id_fk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function checklist_questions_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.is_mandatory_to_answer = defaultValues ? (defaultValues["is_mandatory_to_answer"] ? defaultValues["is_mandatory_to_answer"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.question_id_pk = defaultValues ? (defaultValues["question_id_pk"] ? defaultValues["question_id_pk"] : null) : null;
        privateState.question_text = defaultValues ? (defaultValues["question_text"] ? defaultValues["question_text"] : null) : null;
        privateState.question_type_id_fk = defaultValues ? (defaultValues["question_type_id_fk"] ? defaultValues["question_type_id_fk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_mandatory_to_answer": {
                get: function() {
                    return privateState.is_mandatory_to_answer
                },
                set: function(val) {
                    setterFunctions['is_mandatory_to_answer'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_id_pk": {
                get: function() {
                    return privateState.question_id_pk
                },
                set: function(val) {
                    throw Error("question_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "question_text": {
                get: function() {
                    return privateState.question_text
                },
                set: function(val) {
                    setterFunctions['question_text'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_type_id_fk": {
                get: function() {
                    return privateState.question_type_id_fk
                },
                set: function(val) {
                    setterFunctions['question_type_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(checklist_questions_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(checklist_questions_master_tbl);
    var registerValidatorBackup = checklist_questions_master_tbl.registerValidator;
    checklist_questions_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (checklist_questions_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "checklist_questions_master_tbl_question_localisation_mapping_tbl",
        targetObject: "question_localisation_mapping_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "question_id_pk",
            targetField: "question_id_fk"
        }, ]
    }, {
        name: "checklist_questions_master_tbl_question_options_tbl",
        targetObject: "question_options_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "question_id_pk",
            targetField: "question_id_fk"
        }, ]
    }, {
        name: "checklist_questions_master_tbl_user_answers_tbl",
        targetObject: "user_answers_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "question_type_id_fk",
            targetField: "question_id_fk"
        }, ]
    }, ];
    checklist_questions_master_tbl.relations = relations;
    checklist_questions_master_tbl.prototype.isValid = function() {
        return checklist_questions_master_tbl.isValid(this);
    };
    checklist_questions_master_tbl.prototype.objModelName = "checklist_questions_master_tbl";
    return checklist_questions_master_tbl;
});

define('JourneyObjSvc/checkpoints_status_master_tbl/MF_Config',[], function() {
    var mappings = {
        "checkpoint_status_desc": "checkpoint_status_desc",
        "checkpoint_status_id_pk": "checkpoint_status_id_pk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "checkpoint_status_desc": "string",
        "checkpoint_status_id_pk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["checkpoint_status_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "checkpoints_status_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/checkpoints_status_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        checkpoint_status_desc: function(val, state) {
            state['checkpoint_status_desc'] = val;
        },
        checkpoint_status_id_pk: function(val, state) {
            state['checkpoint_status_id_pk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function checkpoints_status_master_tbl(defaultValues) {
        var privateState = {};
        privateState.checkpoint_status_desc = defaultValues ? (defaultValues["checkpoint_status_desc"] ? defaultValues["checkpoint_status_desc"] : null) : null;
        privateState.checkpoint_status_id_pk = defaultValues ? (defaultValues["checkpoint_status_id_pk"] ? defaultValues["checkpoint_status_id_pk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "checkpoint_status_desc": {
                get: function() {
                    return privateState.checkpoint_status_desc
                },
                set: function(val) {
                    setterFunctions['checkpoint_status_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkpoint_status_id_pk": {
                get: function() {
                    return privateState.checkpoint_status_id_pk
                },
                set: function(val) {
                    throw Error("checkpoint_status_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(checkpoints_status_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(checkpoints_status_master_tbl);
    var registerValidatorBackup = checkpoints_status_master_tbl.registerValidator;
    checkpoints_status_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (checkpoints_status_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "checkpoints_status_master_tbl_checkpoints_tbl",
        targetObject: "checkpoints_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "checkpoint_status_id_pk",
            targetField: "checkpoint_status_id_fk"
        }, ]
    }, ];
    checkpoints_status_master_tbl.relations = relations;
    checkpoints_status_master_tbl.prototype.isValid = function() {
        return checkpoints_status_master_tbl.isValid(this);
    };
    checkpoints_status_master_tbl.prototype.objModelName = "checkpoints_status_master_tbl";
    return checkpoints_status_master_tbl;
});

define('JourneyObjSvc/checkpoints_tbl/MF_Config',[], function() {
    var mappings = {
        "actual_checkin_timestamp": "actual_checkin_timestamp",
        "checkpoint_reported_by_fk": "checkpoint_reported_by_fk",
        "checkpoint_row_id_pk": "checkpoint_row_id_pk",
        "checkpoint_status_id_fk": "checkpoint_status_id_fk",
        "check_point_seq_num": "check_point_seq_num",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "expected_checkin_timestamp": "expected_checkin_timestamp",
        "journey_id_fk": "journey_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "actual_checkin_timestamp": "date",
        "checkpoint_reported_by_fk": "string",
        "checkpoint_row_id_pk": "number",
        "checkpoint_status_id_fk": "number",
        "check_point_seq_num": "number",
        "createdby": "string",
        "createddatetime": "date",
        "expected_checkin_timestamp": "date",
        "journey_id_fk": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["checkpoint_row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "checkpoints_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/checkpoints_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        actual_checkin_timestamp: function(val, state) {
            state['actual_checkin_timestamp'] = val;
        },
        checkpoint_reported_by_fk: function(val, state) {
            state['checkpoint_reported_by_fk'] = val;
        },
        checkpoint_row_id_pk: function(val, state) {
            state['checkpoint_row_id_pk'] = val;
        },
        checkpoint_status_id_fk: function(val, state) {
            state['checkpoint_status_id_fk'] = val;
        },
        check_point_seq_num: function(val, state) {
            state['check_point_seq_num'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        expected_checkin_timestamp: function(val, state) {
            state['expected_checkin_timestamp'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function checkpoints_tbl(defaultValues) {
        var privateState = {};
        privateState.actual_checkin_timestamp = defaultValues ? (defaultValues["actual_checkin_timestamp"] ? defaultValues["actual_checkin_timestamp"] : null) : null;
        privateState.checkpoint_reported_by_fk = defaultValues ? (defaultValues["checkpoint_reported_by_fk"] ? defaultValues["checkpoint_reported_by_fk"] : null) : null;
        privateState.checkpoint_row_id_pk = defaultValues ? (defaultValues["checkpoint_row_id_pk"] ? defaultValues["checkpoint_row_id_pk"] : null) : null;
        privateState.checkpoint_status_id_fk = defaultValues ? (defaultValues["checkpoint_status_id_fk"] ? defaultValues["checkpoint_status_id_fk"] : null) : null;
        privateState.check_point_seq_num = defaultValues ? (defaultValues["check_point_seq_num"] ? defaultValues["check_point_seq_num"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.expected_checkin_timestamp = defaultValues ? (defaultValues["expected_checkin_timestamp"] ? defaultValues["expected_checkin_timestamp"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "actual_checkin_timestamp": {
                get: function() {
                    return privateState.actual_checkin_timestamp
                },
                set: function(val) {
                    setterFunctions['actual_checkin_timestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkpoint_reported_by_fk": {
                get: function() {
                    return privateState.checkpoint_reported_by_fk
                },
                set: function(val) {
                    setterFunctions['checkpoint_reported_by_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkpoint_row_id_pk": {
                get: function() {
                    return privateState.checkpoint_row_id_pk
                },
                set: function(val) {
                    throw Error("checkpoint_row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "checkpoint_status_id_fk": {
                get: function() {
                    return privateState.checkpoint_status_id_fk
                },
                set: function(val) {
                    setterFunctions['checkpoint_status_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "check_point_seq_num": {
                get: function() {
                    return privateState.check_point_seq_num
                },
                set: function(val) {
                    setterFunctions['check_point_seq_num'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "expected_checkin_timestamp": {
                get: function() {
                    return privateState.expected_checkin_timestamp
                },
                set: function(val) {
                    setterFunctions['expected_checkin_timestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(checkpoints_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(checkpoints_tbl);
    var registerValidatorBackup = checkpoints_tbl.registerValidator;
    checkpoints_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (checkpoints_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    checkpoints_tbl.relations = relations;
    checkpoints_tbl.prototype.isValid = function() {
        return checkpoints_tbl.isValid(this);
    };
    checkpoints_tbl.prototype.objModelName = "checkpoints_tbl";
    return checkpoints_tbl;
});

define('JourneyObjSvc/country_master_tbl/MF_Config',[], function() {
    var mappings = {
        "country_id_pk": "country_id_pk",
        "country_name": "country_name",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "country_id_pk": "number",
        "country_name": "string",
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["country_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "country_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/country_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        country_id_pk: function(val, state) {
            state['country_id_pk'] = val;
        },
        country_name: function(val, state) {
            state['country_name'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function country_master_tbl(defaultValues) {
        var privateState = {};
        privateState.country_id_pk = defaultValues ? (defaultValues["country_id_pk"] ? defaultValues["country_id_pk"] : null) : null;
        privateState.country_name = defaultValues ? (defaultValues["country_name"] ? defaultValues["country_name"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "country_id_pk": {
                get: function() {
                    return privateState.country_id_pk
                },
                set: function(val) {
                    throw Error("country_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "country_name": {
                get: function() {
                    return privateState.country_name
                },
                set: function(val) {
                    setterFunctions['country_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(country_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(country_master_tbl);
    var registerValidatorBackup = country_master_tbl.registerValidator;
    country_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (country_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "country_master_tbl_guides_manuals_tbl",
        targetObject: "guides_manuals_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "country_id_pk",
            targetField: "country_id_fk"
        }, ]
    }, {
        name: "country_master_tbl_question_localisation_mapping_tbl",
        targetObject: "question_localisation_mapping_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "country_id_pk",
            targetField: "country_id_fk"
        }, ]
    }, {
        name: "country_master_tbl_region_master_tbl",
        targetObject: "region_master_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "country_id_pk",
            targetField: "country_id_fk"
        }, ]
    }, ];
    country_master_tbl.relations = relations;
    country_master_tbl.prototype.isValid = function() {
        return country_master_tbl.isValid(this);
    };
    country_master_tbl.prototype.objModelName = "country_master_tbl";
    return country_master_tbl;
});

define('JourneyObjSvc/guides_manuals_tbl/MF_Config',[], function() {
    var mappings = {
        "country_id_fk": "country_id_fk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "guides_manuals_row_id_pk": "guides_manuals_row_id_pk",
        "guide_manual_title": "guide_manual_title",
        "guide_manual_url": "guide_manual_url",
        "language_id_fk": "language_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "region_id_fk": "region_id_fk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "country_id_fk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "guides_manuals_row_id_pk": "number",
        "guide_manual_title": "string",
        "guide_manual_url": "string",
        "language_id_fk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "region_id_fk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["guides_manuals_row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "guides_manuals_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/guides_manuals_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        country_id_fk: function(val, state) {
            state['country_id_fk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        guides_manuals_row_id_pk: function(val, state) {
            state['guides_manuals_row_id_pk'] = val;
        },
        guide_manual_title: function(val, state) {
            state['guide_manual_title'] = val;
        },
        guide_manual_url: function(val, state) {
            state['guide_manual_url'] = val;
        },
        language_id_fk: function(val, state) {
            state['language_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        region_id_fk: function(val, state) {
            state['region_id_fk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function guides_manuals_tbl(defaultValues) {
        var privateState = {};
        privateState.country_id_fk = defaultValues ? (defaultValues["country_id_fk"] ? defaultValues["country_id_fk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.guides_manuals_row_id_pk = defaultValues ? (defaultValues["guides_manuals_row_id_pk"] ? defaultValues["guides_manuals_row_id_pk"] : null) : null;
        privateState.guide_manual_title = defaultValues ? (defaultValues["guide_manual_title"] ? defaultValues["guide_manual_title"] : null) : null;
        privateState.guide_manual_url = defaultValues ? (defaultValues["guide_manual_url"] ? defaultValues["guide_manual_url"] : null) : null;
        privateState.language_id_fk = defaultValues ? (defaultValues["language_id_fk"] ? defaultValues["language_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.region_id_fk = defaultValues ? (defaultValues["region_id_fk"] ? defaultValues["region_id_fk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "country_id_fk": {
                get: function() {
                    return privateState.country_id_fk
                },
                set: function(val) {
                    setterFunctions['country_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "guides_manuals_row_id_pk": {
                get: function() {
                    return privateState.guides_manuals_row_id_pk
                },
                set: function(val) {
                    throw Error("guides_manuals_row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "guide_manual_title": {
                get: function() {
                    return privateState.guide_manual_title
                },
                set: function(val) {
                    setterFunctions['guide_manual_title'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "guide_manual_url": {
                get: function() {
                    return privateState.guide_manual_url
                },
                set: function(val) {
                    setterFunctions['guide_manual_url'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "language_id_fk": {
                get: function() {
                    return privateState.language_id_fk
                },
                set: function(val) {
                    setterFunctions['language_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "region_id_fk": {
                get: function() {
                    return privateState.region_id_fk
                },
                set: function(val) {
                    setterFunctions['region_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(guides_manuals_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(guides_manuals_tbl);
    var registerValidatorBackup = guides_manuals_tbl.registerValidator;
    guides_manuals_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (guides_manuals_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    guides_manuals_tbl.relations = relations;
    guides_manuals_tbl.prototype.isValid = function() {
        return guides_manuals_tbl.isValid(this);
    };
    guides_manuals_tbl.prototype.objModelName = "guides_manuals_tbl";
    return guides_manuals_tbl;
});

define('JourneyObjSvc/incident_notification_tbl/MF_Config',[], function() {
    var mappings = {
        "admin_emp_id_responded_fk": "admin_emp_id_responded_fk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "incident_id_pk": "incident_id_pk",
        "incident_other_text": "incident_other_text",
        "incident_response_id_fk": "incident_response_id_fk",
        "incident_response_text": "incident_response_text",
        "incident_status_id_fk": "incident_status_id_fk",
        "incident_type_id_fk": "incident_type_id_fk",
        "journey_id_fk": "journey_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "admin_emp_id_responded_fk": "string",
        "createdby": "string",
        "createddatetime": "date",
        "incident_id_pk": "number",
        "incident_other_text": "string",
        "incident_response_id_fk": "number",
        "incident_response_text": "string",
        "incident_status_id_fk": "number",
        "incident_type_id_fk": "number",
        "journey_id_fk": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["incident_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "incident_notification_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/incident_notification_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        admin_emp_id_responded_fk: function(val, state) {
            state['admin_emp_id_responded_fk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        incident_id_pk: function(val, state) {
            state['incident_id_pk'] = val;
        },
        incident_other_text: function(val, state) {
            state['incident_other_text'] = val;
        },
        incident_response_id_fk: function(val, state) {
            state['incident_response_id_fk'] = val;
        },
        incident_response_text: function(val, state) {
            state['incident_response_text'] = val;
        },
        incident_status_id_fk: function(val, state) {
            state['incident_status_id_fk'] = val;
        },
        incident_type_id_fk: function(val, state) {
            state['incident_type_id_fk'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function incident_notification_tbl(defaultValues) {
        var privateState = {};
        privateState.admin_emp_id_responded_fk = defaultValues ? (defaultValues["admin_emp_id_responded_fk"] ? defaultValues["admin_emp_id_responded_fk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.incident_id_pk = defaultValues ? (defaultValues["incident_id_pk"] ? defaultValues["incident_id_pk"] : null) : null;
        privateState.incident_other_text = defaultValues ? (defaultValues["incident_other_text"] ? defaultValues["incident_other_text"] : null) : null;
        privateState.incident_response_id_fk = defaultValues ? (defaultValues["incident_response_id_fk"] ? defaultValues["incident_response_id_fk"] : null) : null;
        privateState.incident_response_text = defaultValues ? (defaultValues["incident_response_text"] ? defaultValues["incident_response_text"] : null) : null;
        privateState.incident_status_id_fk = defaultValues ? (defaultValues["incident_status_id_fk"] ? defaultValues["incident_status_id_fk"] : null) : null;
        privateState.incident_type_id_fk = defaultValues ? (defaultValues["incident_type_id_fk"] ? defaultValues["incident_type_id_fk"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "admin_emp_id_responded_fk": {
                get: function() {
                    return privateState.admin_emp_id_responded_fk
                },
                set: function(val) {
                    setterFunctions['admin_emp_id_responded_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_id_pk": {
                get: function() {
                    return privateState.incident_id_pk
                },
                set: function(val) {
                    throw Error("incident_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "incident_other_text": {
                get: function() {
                    return privateState.incident_other_text
                },
                set: function(val) {
                    setterFunctions['incident_other_text'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_response_id_fk": {
                get: function() {
                    return privateState.incident_response_id_fk
                },
                set: function(val) {
                    setterFunctions['incident_response_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_response_text": {
                get: function() {
                    return privateState.incident_response_text
                },
                set: function(val) {
                    setterFunctions['incident_response_text'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_status_id_fk": {
                get: function() {
                    return privateState.incident_status_id_fk
                },
                set: function(val) {
                    setterFunctions['incident_status_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_type_id_fk": {
                get: function() {
                    return privateState.incident_type_id_fk
                },
                set: function(val) {
                    setterFunctions['incident_type_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(incident_notification_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(incident_notification_tbl);
    var registerValidatorBackup = incident_notification_tbl.registerValidator;
    incident_notification_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (incident_notification_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    incident_notification_tbl.relations = relations;
    incident_notification_tbl.prototype.isValid = function() {
        return incident_notification_tbl.isValid(this);
    };
    incident_notification_tbl.prototype.objModelName = "incident_notification_tbl";
    return incident_notification_tbl;
});

define('JourneyObjSvc/incident_response_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "incident_response_desc": "incident_response_desc",
        "incident_response_id_pk": "incident_response_id_pk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "incident_response_desc": "string",
        "incident_response_id_pk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["incident_response_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "incident_response_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/incident_response_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        incident_response_desc: function(val, state) {
            state['incident_response_desc'] = val;
        },
        incident_response_id_pk: function(val, state) {
            state['incident_response_id_pk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function incident_response_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.incident_response_desc = defaultValues ? (defaultValues["incident_response_desc"] ? defaultValues["incident_response_desc"] : null) : null;
        privateState.incident_response_id_pk = defaultValues ? (defaultValues["incident_response_id_pk"] ? defaultValues["incident_response_id_pk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_response_desc": {
                get: function() {
                    return privateState.incident_response_desc
                },
                set: function(val) {
                    setterFunctions['incident_response_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_response_id_pk": {
                get: function() {
                    return privateState.incident_response_id_pk
                },
                set: function(val) {
                    throw Error("incident_response_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(incident_response_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(incident_response_master_tbl);
    var registerValidatorBackup = incident_response_master_tbl.registerValidator;
    incident_response_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (incident_response_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "incident_response_master_tbl_incident_notification_tbl",
        targetObject: "incident_notification_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "incident_response_id_pk",
            targetField: "incident_response_id_fk"
        }, ]
    }, ];
    incident_response_master_tbl.relations = relations;
    incident_response_master_tbl.prototype.isValid = function() {
        return incident_response_master_tbl.isValid(this);
    };
    incident_response_master_tbl.prototype.objModelName = "incident_response_master_tbl";
    return incident_response_master_tbl;
});

define('JourneyObjSvc/incident_status_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "incident_status_desc": "incident_status_desc",
        "incident_status_id_pk": "incident_status_id_pk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "incident_status_desc": "string",
        "incident_status_id_pk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["incident_status_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "incident_status_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/incident_status_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        incident_status_desc: function(val, state) {
            state['incident_status_desc'] = val;
        },
        incident_status_id_pk: function(val, state) {
            state['incident_status_id_pk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function incident_status_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.incident_status_desc = defaultValues ? (defaultValues["incident_status_desc"] ? defaultValues["incident_status_desc"] : null) : null;
        privateState.incident_status_id_pk = defaultValues ? (defaultValues["incident_status_id_pk"] ? defaultValues["incident_status_id_pk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_status_desc": {
                get: function() {
                    return privateState.incident_status_desc
                },
                set: function(val) {
                    setterFunctions['incident_status_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_status_id_pk": {
                get: function() {
                    return privateState.incident_status_id_pk
                },
                set: function(val) {
                    throw Error("incident_status_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(incident_status_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(incident_status_master_tbl);
    var registerValidatorBackup = incident_status_master_tbl.registerValidator;
    incident_status_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (incident_status_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "incident_status_master_tbl_incident_notification_tbl",
        targetObject: "incident_notification_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "incident_status_id_pk",
            targetField: "incident_status_id_fk"
        }, ]
    }, ];
    incident_status_master_tbl.relations = relations;
    incident_status_master_tbl.prototype.isValid = function() {
        return incident_status_master_tbl.isValid(this);
    };
    incident_status_master_tbl.prototype.objModelName = "incident_status_master_tbl";
    return incident_status_master_tbl;
});

define('JourneyObjSvc/incident_type_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "incident_type_desc": "incident_type_desc",
        "incident_type_id_pk": "incident_type_id_pk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "incident_type_desc": "string",
        "incident_type_id_pk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["incident_type_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "incident_type_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/incident_type_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        incident_type_desc: function(val, state) {
            state['incident_type_desc'] = val;
        },
        incident_type_id_pk: function(val, state) {
            state['incident_type_id_pk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function incident_type_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.incident_type_desc = defaultValues ? (defaultValues["incident_type_desc"] ? defaultValues["incident_type_desc"] : null) : null;
        privateState.incident_type_id_pk = defaultValues ? (defaultValues["incident_type_id_pk"] ? defaultValues["incident_type_id_pk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_type_desc": {
                get: function() {
                    return privateState.incident_type_desc
                },
                set: function(val) {
                    setterFunctions['incident_type_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "incident_type_id_pk": {
                get: function() {
                    return privateState.incident_type_id_pk
                },
                set: function(val) {
                    throw Error("incident_type_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(incident_type_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(incident_type_master_tbl);
    var registerValidatorBackup = incident_type_master_tbl.registerValidator;
    incident_type_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (incident_type_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "incident_type_master_tbl_incident_notification_tbl",
        targetObject: "incident_notification_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "incident_type_id_pk",
            targetField: "incident_type_id_fk"
        }, ]
    }, ];
    incident_type_master_tbl.relations = relations;
    incident_type_master_tbl.prototype.isValid = function() {
        return incident_type_master_tbl.isValid(this);
    };
    incident_type_master_tbl.prototype.objModelName = "incident_type_master_tbl";
    return incident_type_master_tbl;
});

define('JourneyObjSvc/journeystatus_codes_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journeystatus_code_pk": "journeystatus_code_pk",
        "journeystatus_desc": "journeystatus_desc",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journeystatus_code_pk": "number",
        "journeystatus_desc": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["journeystatus_code_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journeystatus_codes_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journeystatus_codes_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journeystatus_code_pk: function(val, state) {
            state['journeystatus_code_pk'] = val;
        },
        journeystatus_desc: function(val, state) {
            state['journeystatus_desc'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function journeystatus_codes_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journeystatus_code_pk = defaultValues ? (defaultValues["journeystatus_code_pk"] ? defaultValues["journeystatus_code_pk"] : null) : null;
        privateState.journeystatus_desc = defaultValues ? (defaultValues["journeystatus_desc"] ? defaultValues["journeystatus_desc"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journeystatus_code_pk": {
                get: function() {
                    return privateState.journeystatus_code_pk
                },
                set: function(val) {
                    throw Error("journeystatus_code_pk cannot be changed.");
                },
                enumerable: true,
            },
            "journeystatus_desc": {
                get: function() {
                    return privateState.journeystatus_desc
                },
                set: function(val) {
                    setterFunctions['journeystatus_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journeystatus_codes_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journeystatus_codes_master_tbl);
    var registerValidatorBackup = journeystatus_codes_master_tbl.registerValidator;
    journeystatus_codes_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journeystatus_codes_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "journeystatus_codes_master_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journeystatus_code_pk",
            targetField: "journeystatus_code_fk"
        }, ]
    }, ];
    journeystatus_codes_master_tbl.relations = relations;
    journeystatus_codes_master_tbl.prototype.isValid = function() {
        return journeystatus_codes_master_tbl.isValid(this);
    };
    journeystatus_codes_master_tbl.prototype.objModelName = "journeystatus_codes_master_tbl";
    return journeystatus_codes_master_tbl;
});

define('JourneyObjSvc/journey_notif_map_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journey_id_fk": "journey_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "notification_id_fk": "notification_id_fk",
        "row_id_pk": "row_id_pk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journey_id_fk": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "notification_id_fk": "number",
        "row_id_pk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journey_notif_map_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journey_notif_map_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        notification_id_fk: function(val, state) {
            state['notification_id_fk'] = val;
        },
        row_id_pk: function(val, state) {
            state['row_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function journey_notif_map_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.notification_id_fk = defaultValues ? (defaultValues["notification_id_fk"] ? defaultValues["notification_id_fk"] : null) : null;
        privateState.row_id_pk = defaultValues ? (defaultValues["row_id_pk"] ? defaultValues["row_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "notification_id_fk": {
                get: function() {
                    return privateState.notification_id_fk
                },
                set: function(val) {
                    setterFunctions['notification_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "row_id_pk": {
                get: function() {
                    return privateState.row_id_pk
                },
                set: function(val) {
                    throw Error("row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journey_notif_map_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journey_notif_map_tbl);
    var registerValidatorBackup = journey_notif_map_tbl.registerValidator;
    journey_notif_map_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journey_notif_map_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    journey_notif_map_tbl.relations = relations;
    journey_notif_map_tbl.prototype.isValid = function() {
        return journey_notif_map_tbl.isValid(this);
    };
    journey_notif_map_tbl.prototype.objModelName = "journey_notif_map_tbl";
    return journey_notif_map_tbl;
});

define('JourneyObjSvc/journey_passengers_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journey_id_fk": "journey_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "passenger_company": "passenger_company",
        "passenger_mobile": "passenger_mobile",
        "passenger_name": "passenger_name",
        "row_id_pk": "row_id_pk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journey_id_fk": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "passenger_company": "string",
        "passenger_mobile": "string",
        "passenger_name": "string",
        "row_id_pk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journey_passengers_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journey_passengers_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        passenger_company: function(val, state) {
            state['passenger_company'] = val;
        },
        passenger_mobile: function(val, state) {
            state['passenger_mobile'] = val;
        },
        passenger_name: function(val, state) {
            state['passenger_name'] = val;
        },
        row_id_pk: function(val, state) {
            state['row_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function journey_passengers_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.passenger_company = defaultValues ? (defaultValues["passenger_company"] ? defaultValues["passenger_company"] : null) : null;
        privateState.passenger_mobile = defaultValues ? (defaultValues["passenger_mobile"] ? defaultValues["passenger_mobile"] : null) : null;
        privateState.passenger_name = defaultValues ? (defaultValues["passenger_name"] ? defaultValues["passenger_name"] : null) : null;
        privateState.row_id_pk = defaultValues ? (defaultValues["row_id_pk"] ? defaultValues["row_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "passenger_company": {
                get: function() {
                    return privateState.passenger_company
                },
                set: function(val) {
                    setterFunctions['passenger_company'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "passenger_mobile": {
                get: function() {
                    return privateState.passenger_mobile
                },
                set: function(val) {
                    setterFunctions['passenger_mobile'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "passenger_name": {
                get: function() {
                    return privateState.passenger_name
                },
                set: function(val) {
                    setterFunctions['passenger_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "row_id_pk": {
                get: function() {
                    return privateState.row_id_pk
                },
                set: function(val) {
                    throw Error("row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journey_passengers_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journey_passengers_tbl);
    var registerValidatorBackup = journey_passengers_tbl.registerValidator;
    journey_passengers_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journey_passengers_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    journey_passengers_tbl.relations = relations;
    journey_passengers_tbl.prototype.isValid = function() {
        return journey_passengers_tbl.isValid(this);
    };
    journey_passengers_tbl.prototype.objModelName = "journey_passengers_tbl";
    return journey_passengers_tbl;
});

define('JourneyObjSvc/journey_reasons_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journey_reason": "journey_reason",
        "journey_reason_id_pk": "journey_reason_id_pk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journey_reason": "string",
        "journey_reason_id_pk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["journey_reason_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journey_reasons_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journey_reasons_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journey_reason: function(val, state) {
            state['journey_reason'] = val;
        },
        journey_reason_id_pk: function(val, state) {
            state['journey_reason_id_pk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function journey_reasons_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journey_reason = defaultValues ? (defaultValues["journey_reason"] ? defaultValues["journey_reason"] : null) : null;
        privateState.journey_reason_id_pk = defaultValues ? (defaultValues["journey_reason_id_pk"] ? defaultValues["journey_reason_id_pk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_reason": {
                get: function() {
                    return privateState.journey_reason
                },
                set: function(val) {
                    setterFunctions['journey_reason'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_reason_id_pk": {
                get: function() {
                    return privateState.journey_reason_id_pk
                },
                set: function(val) {
                    throw Error("journey_reason_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journey_reasons_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journey_reasons_master_tbl);
    var registerValidatorBackup = journey_reasons_master_tbl.registerValidator;
    journey_reasons_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journey_reasons_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "journey_reasons_master_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_reason_id_pk",
            targetField: "journey_reason_id_fk"
        }, ]
    }, ];
    journey_reasons_master_tbl.relations = relations;
    journey_reasons_master_tbl.prototype.isValid = function() {
        return journey_reasons_master_tbl.isValid(this);
    };
    journey_reasons_master_tbl.prototype.objModelName = "journey_reasons_master_tbl";
    return journey_reasons_master_tbl;
});

define('JourneyObjSvc/journey_signature_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journey_id_fk": "journey_id_fk",
        "journey_user_signature_base64": "journey_user_signature_base64",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "signature_row_id_pk": "signature_row_id_pk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journey_id_fk": "string",
        "journey_user_signature_base64": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "signature_row_id_pk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["signature_row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journey_signature_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journey_signature_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        journey_user_signature_base64: function(val, state) {
            state['journey_user_signature_base64'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        signature_row_id_pk: function(val, state) {
            state['signature_row_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function journey_signature_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.journey_user_signature_base64 = defaultValues ? (defaultValues["journey_user_signature_base64"] ? defaultValues["journey_user_signature_base64"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.signature_row_id_pk = defaultValues ? (defaultValues["signature_row_id_pk"] ? defaultValues["signature_row_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_user_signature_base64": {
                get: function() {
                    return privateState.journey_user_signature_base64
                },
                set: function(val) {
                    setterFunctions['journey_user_signature_base64'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "signature_row_id_pk": {
                get: function() {
                    return privateState.signature_row_id_pk
                },
                set: function(val) {
                    throw Error("signature_row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journey_signature_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journey_signature_tbl);
    var registerValidatorBackup = journey_signature_tbl.registerValidator;
    journey_signature_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journey_signature_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    journey_signature_tbl.relations = relations;
    journey_signature_tbl.prototype.isValid = function() {
        return journey_signature_tbl.isValid(this);
    };
    journey_signature_tbl.prototype.objModelName = "journey_signature_tbl";
    return journey_signature_tbl;
});

define('JourneyObjSvc/journey_tbl/MF_Config',[], function() {
    var mappings = {
        "checkin_interval_row_id_fk": "checkin_interval_row_id_fk",
        "checkin_type_id_fk": "checkin_type_id_fk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journeystatus_code_fk": "journeystatus_code_fk",
        "journey_actual_arrival_datetime": "journey_actual_arrival_datetime",
        "journey_actual_departure_datetime": "journey_actual_departure_datetime",
        "journey_arrivalpoint": "journey_arrivalpoint",
        "journey_arrivalpoint_lat": "journey_arrivalpoint_lat",
        "journey_arrivalpoint_lon": "journey_arrivalpoint_lon",
        "journey_created_by_fk": "journey_created_by_fk",
        "journey_departurepoint_lat": "journey_departurepoint_lat",
        "journey_departurepoint_lon": "journey_departurepoint_lon",
        "journey_departure_point": "journey_departure_point",
        "journey_expected_arrival_datetime": "journey_expected_arrival_datetime",
        "journey_expected_departure_datetime": "journey_expected_departure_datetime",
        "journey_id_pk": "journey_id_pk",
        "journey_is_checkpoint_enabled": "journey_is_checkpoint_enabled",
        "journey_last_updated_by": "journey_last_updated_by",
        "journey_onward_journey_id": "journey_onward_journey_id",
        "journey_radio": "journey_radio",
        "journey_reason_id_fk": "journey_reason_id_fk",
        "journey_satellite": "journey_satellite",
        "journey_selected_vehicle_id_fk": "journey_selected_vehicle_id_fk",
        "journey_supervisor_emp_id": "journey_supervisor_emp_id",
        "journey_supervisor_name": "journey_supervisor_name",
        "journey_supervisor_phone": "journey_supervisor_phone",
        "journey_trackingpoint_lat": "journey_trackingpoint_lat",
        "journey_trackingpoint_lon": "journey_trackingpoint_lon",
        "journey_trackingpoint_name": "journey_trackingpoint_name",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
        "user_emp_id_fk": "user_emp_id_fk",
    };
    Object.freeze(mappings);
    var typings = {
        "checkin_interval_row_id_fk": "number",
        "checkin_type_id_fk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "journeystatus_code_fk": "number",
        "journey_actual_arrival_datetime": "date",
        "journey_actual_departure_datetime": "date",
        "journey_arrivalpoint": "string",
        "journey_arrivalpoint_lat": "string",
        "journey_arrivalpoint_lon": "string",
        "journey_created_by_fk": "string",
        "journey_departurepoint_lat": "string",
        "journey_departurepoint_lon": "string",
        "journey_departure_point": "string",
        "journey_expected_arrival_datetime": "date",
        "journey_expected_departure_datetime": "date",
        "journey_id_pk": "string",
        "journey_is_checkpoint_enabled": "number",
        "journey_last_updated_by": "string",
        "journey_onward_journey_id": "string",
        "journey_radio": "string",
        "journey_reason_id_fk": "number",
        "journey_satellite": "string",
        "journey_selected_vehicle_id_fk": "number",
        "journey_supervisor_emp_id": "string",
        "journey_supervisor_name": "string",
        "journey_supervisor_phone": "string",
        "journey_trackingpoint_lat": "string",
        "journey_trackingpoint_lon": "string",
        "journey_trackingpoint_name": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
        "user_emp_id_fk": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["journey_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "journey_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/journey_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        checkin_interval_row_id_fk: function(val, state) {
            state['checkin_interval_row_id_fk'] = val;
        },
        checkin_type_id_fk: function(val, state) {
            state['checkin_type_id_fk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journeystatus_code_fk: function(val, state) {
            state['journeystatus_code_fk'] = val;
        },
        journey_actual_arrival_datetime: function(val, state) {
            state['journey_actual_arrival_datetime'] = val;
        },
        journey_actual_departure_datetime: function(val, state) {
            state['journey_actual_departure_datetime'] = val;
        },
        journey_arrivalpoint: function(val, state) {
            state['journey_arrivalpoint'] = val;
        },
        journey_arrivalpoint_lat: function(val, state) {
            state['journey_arrivalpoint_lat'] = val;
        },
        journey_arrivalpoint_lon: function(val, state) {
            state['journey_arrivalpoint_lon'] = val;
        },
        journey_created_by_fk: function(val, state) {
            state['journey_created_by_fk'] = val;
        },
        journey_departurepoint_lat: function(val, state) {
            state['journey_departurepoint_lat'] = val;
        },
        journey_departurepoint_lon: function(val, state) {
            state['journey_departurepoint_lon'] = val;
        },
        journey_departure_point: function(val, state) {
            state['journey_departure_point'] = val;
        },
        journey_expected_arrival_datetime: function(val, state) {
            state['journey_expected_arrival_datetime'] = val;
        },
        journey_expected_departure_datetime: function(val, state) {
            state['journey_expected_departure_datetime'] = val;
        },
        journey_id_pk: function(val, state) {
            state['journey_id_pk'] = val;
        },
        journey_is_checkpoint_enabled: function(val, state) {
            state['journey_is_checkpoint_enabled'] = val;
        },
        journey_last_updated_by: function(val, state) {
            state['journey_last_updated_by'] = val;
        },
        journey_onward_journey_id: function(val, state) {
            state['journey_onward_journey_id'] = val;
        },
        journey_radio: function(val, state) {
            state['journey_radio'] = val;
        },
        journey_reason_id_fk: function(val, state) {
            state['journey_reason_id_fk'] = val;
        },
        journey_satellite: function(val, state) {
            state['journey_satellite'] = val;
        },
        journey_selected_vehicle_id_fk: function(val, state) {
            state['journey_selected_vehicle_id_fk'] = val;
        },
        journey_supervisor_emp_id: function(val, state) {
            state['journey_supervisor_emp_id'] = val;
        },
        journey_supervisor_name: function(val, state) {
            state['journey_supervisor_name'] = val;
        },
        journey_supervisor_phone: function(val, state) {
            state['journey_supervisor_phone'] = val;
        },
        journey_trackingpoint_lat: function(val, state) {
            state['journey_trackingpoint_lat'] = val;
        },
        journey_trackingpoint_lon: function(val, state) {
            state['journey_trackingpoint_lon'] = val;
        },
        journey_trackingpoint_name: function(val, state) {
            state['journey_trackingpoint_name'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
        user_emp_id_fk: function(val, state) {
            state['user_emp_id_fk'] = val;
        },
    };
    //Create the Model Class
    function journey_tbl(defaultValues) {
        var privateState = {};
        privateState.checkin_interval_row_id_fk = defaultValues ? (defaultValues["checkin_interval_row_id_fk"] ? defaultValues["checkin_interval_row_id_fk"] : null) : null;
        privateState.checkin_type_id_fk = defaultValues ? (defaultValues["checkin_type_id_fk"] ? defaultValues["checkin_type_id_fk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journeystatus_code_fk = defaultValues ? (defaultValues["journeystatus_code_fk"] ? defaultValues["journeystatus_code_fk"] : null) : null;
        privateState.journey_actual_arrival_datetime = defaultValues ? (defaultValues["journey_actual_arrival_datetime"] ? defaultValues["journey_actual_arrival_datetime"] : null) : null;
        privateState.journey_actual_departure_datetime = defaultValues ? (defaultValues["journey_actual_departure_datetime"] ? defaultValues["journey_actual_departure_datetime"] : null) : null;
        privateState.journey_arrivalpoint = defaultValues ? (defaultValues["journey_arrivalpoint"] ? defaultValues["journey_arrivalpoint"] : null) : null;
        privateState.journey_arrivalpoint_lat = defaultValues ? (defaultValues["journey_arrivalpoint_lat"] ? defaultValues["journey_arrivalpoint_lat"] : null) : null;
        privateState.journey_arrivalpoint_lon = defaultValues ? (defaultValues["journey_arrivalpoint_lon"] ? defaultValues["journey_arrivalpoint_lon"] : null) : null;
        privateState.journey_created_by_fk = defaultValues ? (defaultValues["journey_created_by_fk"] ? defaultValues["journey_created_by_fk"] : null) : null;
        privateState.journey_departurepoint_lat = defaultValues ? (defaultValues["journey_departurepoint_lat"] ? defaultValues["journey_departurepoint_lat"] : null) : null;
        privateState.journey_departurepoint_lon = defaultValues ? (defaultValues["journey_departurepoint_lon"] ? defaultValues["journey_departurepoint_lon"] : null) : null;
        privateState.journey_departure_point = defaultValues ? (defaultValues["journey_departure_point"] ? defaultValues["journey_departure_point"] : null) : null;
        privateState.journey_expected_arrival_datetime = defaultValues ? (defaultValues["journey_expected_arrival_datetime"] ? defaultValues["journey_expected_arrival_datetime"] : null) : null;
        privateState.journey_expected_departure_datetime = defaultValues ? (defaultValues["journey_expected_departure_datetime"] ? defaultValues["journey_expected_departure_datetime"] : null) : null;
        privateState.journey_id_pk = defaultValues ? (defaultValues["journey_id_pk"] ? defaultValues["journey_id_pk"] : null) : null;
        privateState.journey_is_checkpoint_enabled = defaultValues ? (defaultValues["journey_is_checkpoint_enabled"] ? defaultValues["journey_is_checkpoint_enabled"] : null) : null;
        privateState.journey_last_updated_by = defaultValues ? (defaultValues["journey_last_updated_by"] ? defaultValues["journey_last_updated_by"] : null) : null;
        privateState.journey_onward_journey_id = defaultValues ? (defaultValues["journey_onward_journey_id"] ? defaultValues["journey_onward_journey_id"] : null) : null;
        privateState.journey_radio = defaultValues ? (defaultValues["journey_radio"] ? defaultValues["journey_radio"] : null) : null;
        privateState.journey_reason_id_fk = defaultValues ? (defaultValues["journey_reason_id_fk"] ? defaultValues["journey_reason_id_fk"] : null) : null;
        privateState.journey_satellite = defaultValues ? (defaultValues["journey_satellite"] ? defaultValues["journey_satellite"] : null) : null;
        privateState.journey_selected_vehicle_id_fk = defaultValues ? (defaultValues["journey_selected_vehicle_id_fk"] ? defaultValues["journey_selected_vehicle_id_fk"] : null) : null;
        privateState.journey_supervisor_emp_id = defaultValues ? (defaultValues["journey_supervisor_emp_id"] ? defaultValues["journey_supervisor_emp_id"] : null) : null;
        privateState.journey_supervisor_name = defaultValues ? (defaultValues["journey_supervisor_name"] ? defaultValues["journey_supervisor_name"] : null) : null;
        privateState.journey_supervisor_phone = defaultValues ? (defaultValues["journey_supervisor_phone"] ? defaultValues["journey_supervisor_phone"] : null) : null;
        privateState.journey_trackingpoint_lat = defaultValues ? (defaultValues["journey_trackingpoint_lat"] ? defaultValues["journey_trackingpoint_lat"] : null) : null;
        privateState.journey_trackingpoint_lon = defaultValues ? (defaultValues["journey_trackingpoint_lon"] ? defaultValues["journey_trackingpoint_lon"] : null) : null;
        privateState.journey_trackingpoint_name = defaultValues ? (defaultValues["journey_trackingpoint_name"] ? defaultValues["journey_trackingpoint_name"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        privateState.user_emp_id_fk = defaultValues ? (defaultValues["user_emp_id_fk"] ? defaultValues["user_emp_id_fk"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "checkin_interval_row_id_fk": {
                get: function() {
                    return privateState.checkin_interval_row_id_fk
                },
                set: function(val) {
                    setterFunctions['checkin_interval_row_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "checkin_type_id_fk": {
                get: function() {
                    return privateState.checkin_type_id_fk
                },
                set: function(val) {
                    setterFunctions['checkin_type_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journeystatus_code_fk": {
                get: function() {
                    return privateState.journeystatus_code_fk
                },
                set: function(val) {
                    setterFunctions['journeystatus_code_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_actual_arrival_datetime": {
                get: function() {
                    return privateState.journey_actual_arrival_datetime
                },
                set: function(val) {
                    setterFunctions['journey_actual_arrival_datetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_actual_departure_datetime": {
                get: function() {
                    return privateState.journey_actual_departure_datetime
                },
                set: function(val) {
                    setterFunctions['journey_actual_departure_datetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_arrivalpoint": {
                get: function() {
                    return privateState.journey_arrivalpoint
                },
                set: function(val) {
                    setterFunctions['journey_arrivalpoint'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_arrivalpoint_lat": {
                get: function() {
                    return privateState.journey_arrivalpoint_lat
                },
                set: function(val) {
                    setterFunctions['journey_arrivalpoint_lat'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_arrivalpoint_lon": {
                get: function() {
                    return privateState.journey_arrivalpoint_lon
                },
                set: function(val) {
                    setterFunctions['journey_arrivalpoint_lon'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_created_by_fk": {
                get: function() {
                    return privateState.journey_created_by_fk
                },
                set: function(val) {
                    setterFunctions['journey_created_by_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_departurepoint_lat": {
                get: function() {
                    return privateState.journey_departurepoint_lat
                },
                set: function(val) {
                    setterFunctions['journey_departurepoint_lat'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_departurepoint_lon": {
                get: function() {
                    return privateState.journey_departurepoint_lon
                },
                set: function(val) {
                    setterFunctions['journey_departurepoint_lon'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_departure_point": {
                get: function() {
                    return privateState.journey_departure_point
                },
                set: function(val) {
                    setterFunctions['journey_departure_point'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_expected_arrival_datetime": {
                get: function() {
                    return privateState.journey_expected_arrival_datetime
                },
                set: function(val) {
                    setterFunctions['journey_expected_arrival_datetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_expected_departure_datetime": {
                get: function() {
                    return privateState.journey_expected_departure_datetime
                },
                set: function(val) {
                    setterFunctions['journey_expected_departure_datetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_pk": {
                get: function() {
                    return privateState.journey_id_pk
                },
                set: function(val) {
                    throw Error("journey_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "journey_is_checkpoint_enabled": {
                get: function() {
                    return privateState.journey_is_checkpoint_enabled
                },
                set: function(val) {
                    setterFunctions['journey_is_checkpoint_enabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_last_updated_by": {
                get: function() {
                    return privateState.journey_last_updated_by
                },
                set: function(val) {
                    setterFunctions['journey_last_updated_by'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_onward_journey_id": {
                get: function() {
                    return privateState.journey_onward_journey_id
                },
                set: function(val) {
                    setterFunctions['journey_onward_journey_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_radio": {
                get: function() {
                    return privateState.journey_radio
                },
                set: function(val) {
                    setterFunctions['journey_radio'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_reason_id_fk": {
                get: function() {
                    return privateState.journey_reason_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_reason_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_satellite": {
                get: function() {
                    return privateState.journey_satellite
                },
                set: function(val) {
                    setterFunctions['journey_satellite'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_selected_vehicle_id_fk": {
                get: function() {
                    return privateState.journey_selected_vehicle_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_selected_vehicle_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_supervisor_emp_id": {
                get: function() {
                    return privateState.journey_supervisor_emp_id
                },
                set: function(val) {
                    setterFunctions['journey_supervisor_emp_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_supervisor_name": {
                get: function() {
                    return privateState.journey_supervisor_name
                },
                set: function(val) {
                    setterFunctions['journey_supervisor_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_supervisor_phone": {
                get: function() {
                    return privateState.journey_supervisor_phone
                },
                set: function(val) {
                    setterFunctions['journey_supervisor_phone'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_trackingpoint_lat": {
                get: function() {
                    return privateState.journey_trackingpoint_lat
                },
                set: function(val) {
                    setterFunctions['journey_trackingpoint_lat'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_trackingpoint_lon": {
                get: function() {
                    return privateState.journey_trackingpoint_lon
                },
                set: function(val) {
                    setterFunctions['journey_trackingpoint_lon'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_trackingpoint_name": {
                get: function() {
                    return privateState.journey_trackingpoint_name
                },
                set: function(val) {
                    setterFunctions['journey_trackingpoint_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_emp_id_fk": {
                get: function() {
                    return privateState.user_emp_id_fk
                },
                set: function(val) {
                    setterFunctions['user_emp_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(journey_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(journey_tbl);
    var registerValidatorBackup = journey_tbl.registerValidator;
    journey_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (journey_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "journey_tbl_checkpoints_tbl",
        targetObject: "checkpoints_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, {
        name: "journey_tbl_incident_notification_tbl",
        targetObject: "incident_notification_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, {
        name: "journey_tbl_journey_notif_map_tbl",
        targetObject: "journey_notif_map_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, {
        name: "journey_tbl_journey_passengers_tbl",
        targetObject: "journey_passengers_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, {
        name: "journey_tbl_journey_signature_tbl",
        targetObject: "journey_signature_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, {
        name: "journey_tbl_user_answers_tbl",
        targetObject: "user_answers_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "journey_id_pk",
            targetField: "journey_id_fk"
        }, ]
    }, ];
    journey_tbl.relations = relations;
    journey_tbl.prototype.isValid = function() {
        return journey_tbl.isValid(this);
    };
    journey_tbl.prototype.objModelName = "journey_tbl";
    return journey_tbl;
});

define('JourneyObjSvc/language_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "language_id_pk": "language_id_pk",
        "language_name": "language_name",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "language_id_pk": "number",
        "language_name": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["language_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "language_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/language_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        language_id_pk: function(val, state) {
            state['language_id_pk'] = val;
        },
        language_name: function(val, state) {
            state['language_name'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function language_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.language_id_pk = defaultValues ? (defaultValues["language_id_pk"] ? defaultValues["language_id_pk"] : null) : null;
        privateState.language_name = defaultValues ? (defaultValues["language_name"] ? defaultValues["language_name"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "language_id_pk": {
                get: function() {
                    return privateState.language_id_pk
                },
                set: function(val) {
                    throw Error("language_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "language_name": {
                get: function() {
                    return privateState.language_name
                },
                set: function(val) {
                    setterFunctions['language_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(language_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(language_master_tbl);
    var registerValidatorBackup = language_master_tbl.registerValidator;
    language_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (language_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "language_master_tbl_guides_manuals_tbl",
        targetObject: "guides_manuals_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "language_id_pk",
            targetField: "language_id_fk"
        }, ]
    }, {
        name: "language_master_tbl_question_localisation_mapping_tbl",
        targetObject: "question_localisation_mapping_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "language_id_pk",
            targetField: "language_id_fk"
        }, ]
    }, ];
    language_master_tbl.relations = relations;
    language_master_tbl.prototype.isValid = function() {
        return language_master_tbl.isValid(this);
    };
    language_master_tbl.prototype.objModelName = "language_master_tbl";
    return language_master_tbl;
});

define('JourneyObjSvc/notifications_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "notification_id_pk": "notification_id_pk",
        "notification_message": "notification_message",
        "notification_sent_by_fk": "notification_sent_by_fk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "notification_id_pk": "number",
        "notification_message": "string",
        "notification_sent_by_fk": "string",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["notification_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "notifications_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/notifications_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        notification_id_pk: function(val, state) {
            state['notification_id_pk'] = val;
        },
        notification_message: function(val, state) {
            state['notification_message'] = val;
        },
        notification_sent_by_fk: function(val, state) {
            state['notification_sent_by_fk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function notifications_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.notification_id_pk = defaultValues ? (defaultValues["notification_id_pk"] ? defaultValues["notification_id_pk"] : null) : null;
        privateState.notification_message = defaultValues ? (defaultValues["notification_message"] ? defaultValues["notification_message"] : null) : null;
        privateState.notification_sent_by_fk = defaultValues ? (defaultValues["notification_sent_by_fk"] ? defaultValues["notification_sent_by_fk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "notification_id_pk": {
                get: function() {
                    return privateState.notification_id_pk
                },
                set: function(val) {
                    throw Error("notification_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "notification_message": {
                get: function() {
                    return privateState.notification_message
                },
                set: function(val) {
                    setterFunctions['notification_message'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "notification_sent_by_fk": {
                get: function() {
                    return privateState.notification_sent_by_fk
                },
                set: function(val) {
                    setterFunctions['notification_sent_by_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(notifications_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(notifications_tbl);
    var registerValidatorBackup = notifications_tbl.registerValidator;
    notifications_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (notifications_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "notifications_tbl_journey_notif_map_tbl",
        targetObject: "journey_notif_map_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "notification_id_pk",
            targetField: "notification_id_fk"
        }, ]
    }, ];
    notifications_tbl.relations = relations;
    notifications_tbl.prototype.isValid = function() {
        return notifications_tbl.isValid(this);
    };
    notifications_tbl.prototype.objModelName = "notifications_tbl";
    return notifications_tbl;
});

define('JourneyObjSvc/question_localisation_mapping_tbl/MF_Config',[], function() {
    var mappings = {
        "country_id_fk": "country_id_fk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "language_id_fk": "language_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "question_id_fk": "question_id_fk",
        "question_localisation_row_id": "question_localisation_row_id",
        "region_id_fk": "region_id_fk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "country_id_fk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "language_id_fk": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "question_id_fk": "number",
        "question_localisation_row_id": "number",
        "region_id_fk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["question_localisation_row_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "question_localisation_mapping_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/question_localisation_mapping_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        country_id_fk: function(val, state) {
            state['country_id_fk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        language_id_fk: function(val, state) {
            state['language_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        question_id_fk: function(val, state) {
            state['question_id_fk'] = val;
        },
        question_localisation_row_id: function(val, state) {
            state['question_localisation_row_id'] = val;
        },
        region_id_fk: function(val, state) {
            state['region_id_fk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function question_localisation_mapping_tbl(defaultValues) {
        var privateState = {};
        privateState.country_id_fk = defaultValues ? (defaultValues["country_id_fk"] ? defaultValues["country_id_fk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.language_id_fk = defaultValues ? (defaultValues["language_id_fk"] ? defaultValues["language_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.question_id_fk = defaultValues ? (defaultValues["question_id_fk"] ? defaultValues["question_id_fk"] : null) : null;
        privateState.question_localisation_row_id = defaultValues ? (defaultValues["question_localisation_row_id"] ? defaultValues["question_localisation_row_id"] : null) : null;
        privateState.region_id_fk = defaultValues ? (defaultValues["region_id_fk"] ? defaultValues["region_id_fk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "country_id_fk": {
                get: function() {
                    return privateState.country_id_fk
                },
                set: function(val) {
                    setterFunctions['country_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "language_id_fk": {
                get: function() {
                    return privateState.language_id_fk
                },
                set: function(val) {
                    setterFunctions['language_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_id_fk": {
                get: function() {
                    return privateState.question_id_fk
                },
                set: function(val) {
                    setterFunctions['question_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_localisation_row_id": {
                get: function() {
                    return privateState.question_localisation_row_id
                },
                set: function(val) {
                    throw Error("question_localisation_row_id cannot be changed.");
                },
                enumerable: true,
            },
            "region_id_fk": {
                get: function() {
                    return privateState.region_id_fk
                },
                set: function(val) {
                    setterFunctions['region_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(question_localisation_mapping_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(question_localisation_mapping_tbl);
    var registerValidatorBackup = question_localisation_mapping_tbl.registerValidator;
    question_localisation_mapping_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (question_localisation_mapping_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    question_localisation_mapping_tbl.relations = relations;
    question_localisation_mapping_tbl.prototype.isValid = function() {
        return question_localisation_mapping_tbl.isValid(this);
    };
    question_localisation_mapping_tbl.prototype.objModelName = "question_localisation_mapping_tbl";
    return question_localisation_mapping_tbl;
});

define('JourneyObjSvc/question_options_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "is_option_to_be_selected_mandatory": "is_option_to_be_selected_mandatory",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "question_id_fk": "question_id_fk",
        "question_options_row_id_pk": "question_options_row_id_pk",
        "question_option_to_choose": "question_option_to_choose",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "is_option_to_be_selected_mandatory": "number",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "question_id_fk": "number",
        "question_options_row_id_pk": "number",
        "question_option_to_choose": "string",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["question_options_row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "question_options_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/question_options_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        is_option_to_be_selected_mandatory: function(val, state) {
            state['is_option_to_be_selected_mandatory'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        question_id_fk: function(val, state) {
            state['question_id_fk'] = val;
        },
        question_options_row_id_pk: function(val, state) {
            state['question_options_row_id_pk'] = val;
        },
        question_option_to_choose: function(val, state) {
            state['question_option_to_choose'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function question_options_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.is_option_to_be_selected_mandatory = defaultValues ? (defaultValues["is_option_to_be_selected_mandatory"] ? defaultValues["is_option_to_be_selected_mandatory"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.question_id_fk = defaultValues ? (defaultValues["question_id_fk"] ? defaultValues["question_id_fk"] : null) : null;
        privateState.question_options_row_id_pk = defaultValues ? (defaultValues["question_options_row_id_pk"] ? defaultValues["question_options_row_id_pk"] : null) : null;
        privateState.question_option_to_choose = defaultValues ? (defaultValues["question_option_to_choose"] ? defaultValues["question_option_to_choose"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_option_to_be_selected_mandatory": {
                get: function() {
                    return privateState.is_option_to_be_selected_mandatory
                },
                set: function(val) {
                    setterFunctions['is_option_to_be_selected_mandatory'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_id_fk": {
                get: function() {
                    return privateState.question_id_fk
                },
                set: function(val) {
                    setterFunctions['question_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_options_row_id_pk": {
                get: function() {
                    return privateState.question_options_row_id_pk
                },
                set: function(val) {
                    throw Error("question_options_row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "question_option_to_choose": {
                get: function() {
                    return privateState.question_option_to_choose
                },
                set: function(val) {
                    setterFunctions['question_option_to_choose'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(question_options_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(question_options_tbl);
    var registerValidatorBackup = question_options_tbl.registerValidator;
    question_options_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (question_options_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "question_options_tbl_user_answers_tbl",
        targetObject: "user_answers_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "question_options_row_id_pk",
            targetField: "question_id_fk"
        }, ]
    }, ];
    question_options_tbl.relations = relations;
    question_options_tbl.prototype.isValid = function() {
        return question_options_tbl.isValid(this);
    };
    question_options_tbl.prototype.objModelName = "question_options_tbl";
    return question_options_tbl;
});

define('JourneyObjSvc/question_type_master_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "question_type_desc": "question_type_desc",
        "question_type_id_pk": "question_type_id_pk",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "question_type_desc": "string",
        "question_type_id_pk": "number",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["question_type_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "question_type_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/question_type_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        question_type_desc: function(val, state) {
            state['question_type_desc'] = val;
        },
        question_type_id_pk: function(val, state) {
            state['question_type_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function question_type_master_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.question_type_desc = defaultValues ? (defaultValues["question_type_desc"] ? defaultValues["question_type_desc"] : null) : null;
        privateState.question_type_id_pk = defaultValues ? (defaultValues["question_type_id_pk"] ? defaultValues["question_type_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_type_desc": {
                get: function() {
                    return privateState.question_type_desc
                },
                set: function(val) {
                    setterFunctions['question_type_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_type_id_pk": {
                get: function() {
                    return privateState.question_type_id_pk
                },
                set: function(val) {
                    throw Error("question_type_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(question_type_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(question_type_master_tbl);
    var registerValidatorBackup = question_type_master_tbl.registerValidator;
    question_type_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (question_type_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "question_type_master_tbl_checklist_questions_master_tbl",
        targetObject: "checklist_questions_master_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "question_type_id_pk",
            targetField: "question_type_id_fk"
        }, ]
    }, ];
    question_type_master_tbl.relations = relations;
    question_type_master_tbl.prototype.isValid = function() {
        return question_type_master_tbl.isValid(this);
    };
    question_type_master_tbl.prototype.objModelName = "question_type_master_tbl";
    return question_type_master_tbl;
});

define('JourneyObjSvc/region_master_tbl/MF_Config',[], function() {
    var mappings = {
        "country_id_fk": "country_id_fk",
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "region_id_pk": "region_id_pk",
        "region_name": "region_name",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "country_id_fk": "number",
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "region_id_pk": "number",
        "region_name": "string",
        "softdeleteflag": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["region_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "region_master_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/region_master_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        country_id_fk: function(val, state) {
            state['country_id_fk'] = val;
        },
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        region_id_pk: function(val, state) {
            state['region_id_pk'] = val;
        },
        region_name: function(val, state) {
            state['region_name'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
    };
    //Create the Model Class
    function region_master_tbl(defaultValues) {
        var privateState = {};
        privateState.country_id_fk = defaultValues ? (defaultValues["country_id_fk"] ? defaultValues["country_id_fk"] : null) : null;
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.region_id_pk = defaultValues ? (defaultValues["region_id_pk"] ? defaultValues["region_id_pk"] : null) : null;
        privateState.region_name = defaultValues ? (defaultValues["region_name"] ? defaultValues["region_name"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "country_id_fk": {
                get: function() {
                    return privateState.country_id_fk
                },
                set: function(val) {
                    setterFunctions['country_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "region_id_pk": {
                get: function() {
                    return privateState.region_id_pk
                },
                set: function(val) {
                    throw Error("region_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "region_name": {
                get: function() {
                    return privateState.region_name
                },
                set: function(val) {
                    setterFunctions['region_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(region_master_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(region_master_tbl);
    var registerValidatorBackup = region_master_tbl.registerValidator;
    region_master_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (region_master_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "region_master_tbl_guides_manuals_tbl",
        targetObject: "guides_manuals_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "region_id_pk",
            targetField: "region_id_fk"
        }, ]
    }, {
        name: "region_master_tbl_question_localisation_mapping_tbl",
        targetObject: "question_localisation_mapping_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "region_id_pk",
            targetField: "region_id_fk"
        }, ]
    }, ];
    region_master_tbl.relations = relations;
    region_master_tbl.prototype.isValid = function() {
        return region_master_tbl.isValid(this);
    };
    region_master_tbl.prototype.objModelName = "region_master_tbl";
    return region_master_tbl;
});

define('JourneyObjSvc/user_answers_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "journey_id_fk": "journey_id_fk",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "question_id_fk": "question_id_fk",
        "question_options_row_id_pk": "question_options_row_id_pk",
        "softdeleteflag": "softdeleteflag",
        "user_answer_plain_text": "user_answer_plain_text",
        "user_answer_row_id": "user_answer_row_id",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "journey_id_fk": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "question_id_fk": "number",
        "question_options_row_id_pk": "number",
        "softdeleteflag": "number",
        "user_answer_plain_text": "string",
        "user_answer_row_id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["user_answer_row_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "user_answers_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/user_answers_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        journey_id_fk: function(val, state) {
            state['journey_id_fk'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        question_id_fk: function(val, state) {
            state['question_id_fk'] = val;
        },
        question_options_row_id_pk: function(val, state) {
            state['question_options_row_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
        user_answer_plain_text: function(val, state) {
            state['user_answer_plain_text'] = val;
        },
        user_answer_row_id: function(val, state) {
            state['user_answer_row_id'] = val;
        },
    };
    //Create the Model Class
    function user_answers_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.journey_id_fk = defaultValues ? (defaultValues["journey_id_fk"] ? defaultValues["journey_id_fk"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.question_id_fk = defaultValues ? (defaultValues["question_id_fk"] ? defaultValues["question_id_fk"] : null) : null;
        privateState.question_options_row_id_pk = defaultValues ? (defaultValues["question_options_row_id_pk"] ? defaultValues["question_options_row_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        privateState.user_answer_plain_text = defaultValues ? (defaultValues["user_answer_plain_text"] ? defaultValues["user_answer_plain_text"] : null) : null;
        privateState.user_answer_row_id = defaultValues ? (defaultValues["user_answer_row_id"] ? defaultValues["user_answer_row_id"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "journey_id_fk": {
                get: function() {
                    return privateState.journey_id_fk
                },
                set: function(val) {
                    setterFunctions['journey_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_id_fk": {
                get: function() {
                    return privateState.question_id_fk
                },
                set: function(val) {
                    setterFunctions['question_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "question_options_row_id_pk": {
                get: function() {
                    return privateState.question_options_row_id_pk
                },
                set: function(val) {
                    setterFunctions['question_options_row_id_pk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_answer_plain_text": {
                get: function() {
                    return privateState.user_answer_plain_text
                },
                set: function(val) {
                    setterFunctions['user_answer_plain_text'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_answer_row_id": {
                get: function() {
                    return privateState.user_answer_row_id
                },
                set: function(val) {
                    throw Error("user_answer_row_id cannot be changed.");
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(user_answers_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(user_answers_tbl);
    var registerValidatorBackup = user_answers_tbl.registerValidator;
    user_answers_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (user_answers_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    user_answers_tbl.relations = relations;
    user_answers_tbl.prototype.isValid = function() {
        return user_answers_tbl.isValid(this);
    };
    user_answers_tbl.prototype.objModelName = "user_answers_tbl";
    return user_answers_tbl;
});

define('JourneyObjSvc/user_tbl/MF_Config',[], function() {
    var mappings = {
        "country_id_fk": "country_id_fk",
        "createddatetime": "createddatetime",
        "group_id_fk": "group_id_fk",
        "language_id_fk": "language_id_fk",
        "lastupdateddatetime": "lastupdateddatetime",
        "region_id_fk": "region_id_fk",
        "softdeleteflag": "softdeleteflag",
        "user_email_id": "user_email_id",
        "user_emp_id_pk": "user_emp_id_pk",
        "user_firstname": "user_firstname",
        "user_lastname": "user_lastname",
        "user_phone1": "user_phone1",
    };
    Object.freeze(mappings);
    var typings = {
        "country_id_fk": "number",
        "createddatetime": "date",
        "group_id_fk": "number",
        "language_id_fk": "number",
        "lastupdateddatetime": "date",
        "region_id_fk": "number",
        "softdeleteflag": "number",
        "user_email_id": "string",
        "user_emp_id_pk": "string",
        "user_firstname": "string",
        "user_lastname": "string",
        "user_phone1": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["user_emp_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "user_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/user_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        country_id_fk: function(val, state) {
            state['country_id_fk'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        group_id_fk: function(val, state) {
            state['group_id_fk'] = val;
        },
        language_id_fk: function(val, state) {
            state['language_id_fk'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        region_id_fk: function(val, state) {
            state['region_id_fk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
        user_email_id: function(val, state) {
            state['user_email_id'] = val;
        },
        user_emp_id_pk: function(val, state) {
            state['user_emp_id_pk'] = val;
        },
        user_firstname: function(val, state) {
            state['user_firstname'] = val;
        },
        user_lastname: function(val, state) {
            state['user_lastname'] = val;
        },
        user_phone1: function(val, state) {
            state['user_phone1'] = val;
        },
    };
    //Create the Model Class
    function user_tbl(defaultValues) {
        var privateState = {};
        privateState.country_id_fk = defaultValues ? (defaultValues["country_id_fk"] ? defaultValues["country_id_fk"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.group_id_fk = defaultValues ? (defaultValues["group_id_fk"] ? defaultValues["group_id_fk"] : null) : null;
        privateState.language_id_fk = defaultValues ? (defaultValues["language_id_fk"] ? defaultValues["language_id_fk"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.region_id_fk = defaultValues ? (defaultValues["region_id_fk"] ? defaultValues["region_id_fk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        privateState.user_email_id = defaultValues ? (defaultValues["user_email_id"] ? defaultValues["user_email_id"] : null) : null;
        privateState.user_emp_id_pk = defaultValues ? (defaultValues["user_emp_id_pk"] ? defaultValues["user_emp_id_pk"] : null) : null;
        privateState.user_firstname = defaultValues ? (defaultValues["user_firstname"] ? defaultValues["user_firstname"] : null) : null;
        privateState.user_lastname = defaultValues ? (defaultValues["user_lastname"] ? defaultValues["user_lastname"] : null) : null;
        privateState.user_phone1 = defaultValues ? (defaultValues["user_phone1"] ? defaultValues["user_phone1"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "country_id_fk": {
                get: function() {
                    return privateState.country_id_fk
                },
                set: function(val) {
                    setterFunctions['country_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "group_id_fk": {
                get: function() {
                    return privateState.group_id_fk
                },
                set: function(val) {
                    setterFunctions['group_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "language_id_fk": {
                get: function() {
                    return privateState.language_id_fk
                },
                set: function(val) {
                    setterFunctions['language_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "region_id_fk": {
                get: function() {
                    return privateState.region_id_fk
                },
                set: function(val) {
                    setterFunctions['region_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_email_id": {
                get: function() {
                    return privateState.user_email_id
                },
                set: function(val) {
                    setterFunctions['user_email_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_emp_id_pk": {
                get: function() {
                    return privateState.user_emp_id_pk
                },
                set: function(val) {
                    throw Error("user_emp_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "user_firstname": {
                get: function() {
                    return privateState.user_firstname
                },
                set: function(val) {
                    setterFunctions['user_firstname'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_lastname": {
                get: function() {
                    return privateState.user_lastname
                },
                set: function(val) {
                    setterFunctions['user_lastname'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_phone1": {
                get: function() {
                    return privateState.user_phone1
                },
                set: function(val) {
                    setterFunctions['user_phone1'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(user_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(user_tbl);
    var registerValidatorBackup = user_tbl.registerValidator;
    user_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (user_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "user_tbl_checkpoints_tbl",
        targetObject: "checkpoints_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "checkpoint_reported_by_fk"
        }, ]
    }, {
        name: "user_tbl_incident_notification_tbl",
        targetObject: "incident_notification_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "admin_emp_id_responded_fk"
        }, ]
    }, {
        name: "user_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "user_emp_id_fk"
        }, ]
    }, {
        name: "user_tbl_journey_tbl_1",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "journey_created_by_fk"
        }, ]
    }, {
        name: "user_tbl_journey_tbl_2",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "journey_last_updated_by"
        }, ]
    }, {
        name: "user_tbl_notifications_tbl",
        targetObject: "notifications_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "notification_sent_by_fk"
        }, ]
    }, {
        name: "user_tbl_vehicle_tbl",
        targetObject: "vehicle_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "user_emp_id_pk",
            targetField: "user_emp_id_fk"
        }, ]
    }, ];
    user_tbl.relations = relations;
    user_tbl.prototype.isValid = function() {
        return user_tbl.isValid(this);
    };
    user_tbl.prototype.objModelName = "user_tbl";
    return user_tbl;
});

define('JourneyObjSvc/vehicle_images_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "image_base64": "image_base64",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "row_id_pk": "row_id_pk",
        "softdeleteflag": "softdeleteflag",
        "vehicle_id_fk": "vehicle_id_fk",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "image_base64": "string",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "row_id_pk": "number",
        "softdeleteflag": "number",
        "vehicle_id_fk": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["row_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "vehicle_images_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/vehicle_images_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        image_base64: function(val, state) {
            state['image_base64'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        row_id_pk: function(val, state) {
            state['row_id_pk'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
        vehicle_id_fk: function(val, state) {
            state['vehicle_id_fk'] = val;
        },
    };
    //Create the Model Class
    function vehicle_images_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.image_base64 = defaultValues ? (defaultValues["image_base64"] ? defaultValues["image_base64"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.row_id_pk = defaultValues ? (defaultValues["row_id_pk"] ? defaultValues["row_id_pk"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        privateState.vehicle_id_fk = defaultValues ? (defaultValues["vehicle_id_fk"] ? defaultValues["vehicle_id_fk"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "image_base64": {
                get: function() {
                    return privateState.image_base64
                },
                set: function(val) {
                    setterFunctions['image_base64'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "row_id_pk": {
                get: function() {
                    return privateState.row_id_pk
                },
                set: function(val) {
                    throw Error("row_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vehicle_id_fk": {
                get: function() {
                    return privateState.vehicle_id_fk
                },
                set: function(val) {
                    setterFunctions['vehicle_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(vehicle_images_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(vehicle_images_tbl);
    var registerValidatorBackup = vehicle_images_tbl.registerValidator;
    vehicle_images_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (vehicle_images_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    vehicle_images_tbl.relations = relations;
    vehicle_images_tbl.prototype.isValid = function() {
        return vehicle_images_tbl.isValid(this);
    };
    vehicle_images_tbl.prototype.objModelName = "vehicle_images_tbl";
    return vehicle_images_tbl;
});

define('JourneyObjSvc/vehicle_tbl/MF_Config',[], function() {
    var mappings = {
        "createdby": "createdby",
        "createddatetime": "createddatetime",
        "lastupdatedby": "lastupdatedby",
        "lastupdateddatetime": "lastupdateddatetime",
        "softdeleteflag": "softdeleteflag",
        "user_emp_id_fk": "user_emp_id_fk",
        "vehicle_color": "vehicle_color",
        "vehicle_id_pk": "vehicle_id_pk",
        "vehicle_make": "vehicle_make",
        "vehicle_model": "vehicle_model",
        "vehicle_reg_num": "vehicle_reg_num",
    };
    Object.freeze(mappings);
    var typings = {
        "createdby": "string",
        "createddatetime": "date",
        "lastupdatedby": "string",
        "lastupdateddatetime": "date",
        "softdeleteflag": "number",
        "user_emp_id_fk": "string",
        "vehicle_color": "string",
        "vehicle_id_pk": "number",
        "vehicle_make": "string",
        "vehicle_model": "string",
        "vehicle_reg_num": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["vehicle_id_pk", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "JourneyObjSvc",
        tableName: "vehicle_tbl"
    };
    Object.freeze(config);
    return config;
})
;
define('JourneyObjSvc/vehicle_tbl/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var setterFunctions = {
        createdby: function(val, state) {
            state['createdby'] = val;
        },
        createddatetime: function(val, state) {
            state['createddatetime'] = val;
        },
        lastupdatedby: function(val, state) {
            state['lastupdatedby'] = val;
        },
        lastupdateddatetime: function(val, state) {
            state['lastupdateddatetime'] = val;
        },
        softdeleteflag: function(val, state) {
            state['softdeleteflag'] = val;
        },
        user_emp_id_fk: function(val, state) {
            state['user_emp_id_fk'] = val;
        },
        vehicle_color: function(val, state) {
            state['vehicle_color'] = val;
        },
        vehicle_id_pk: function(val, state) {
            state['vehicle_id_pk'] = val;
        },
        vehicle_make: function(val, state) {
            state['vehicle_make'] = val;
        },
        vehicle_model: function(val, state) {
            state['vehicle_model'] = val;
        },
        vehicle_reg_num: function(val, state) {
            state['vehicle_reg_num'] = val;
        },
    };
    //Create the Model Class
    function vehicle_tbl(defaultValues) {
        var privateState = {};
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? defaultValues["createdby"] : null) : null;
        privateState.createddatetime = defaultValues ? (defaultValues["createddatetime"] ? defaultValues["createddatetime"] : null) : null;
        privateState.lastupdatedby = defaultValues ? (defaultValues["lastupdatedby"] ? defaultValues["lastupdatedby"] : null) : null;
        privateState.lastupdateddatetime = defaultValues ? (defaultValues["lastupdateddatetime"] ? defaultValues["lastupdateddatetime"] : null) : null;
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? defaultValues["softdeleteflag"] : null) : null;
        privateState.user_emp_id_fk = defaultValues ? (defaultValues["user_emp_id_fk"] ? defaultValues["user_emp_id_fk"] : null) : null;
        privateState.vehicle_color = defaultValues ? (defaultValues["vehicle_color"] ? defaultValues["vehicle_color"] : null) : null;
        privateState.vehicle_id_pk = defaultValues ? (defaultValues["vehicle_id_pk"] ? defaultValues["vehicle_id_pk"] : null) : null;
        privateState.vehicle_make = defaultValues ? (defaultValues["vehicle_make"] ? defaultValues["vehicle_make"] : null) : null;
        privateState.vehicle_model = defaultValues ? (defaultValues["vehicle_model"] ? defaultValues["vehicle_model"] : null) : null;
        privateState.vehicle_reg_num = defaultValues ? (defaultValues["vehicle_reg_num"] ? defaultValues["vehicle_reg_num"] : null) : null;
        //Using parent contructor to create other properties req. to kony sdk	
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdby": {
                get: function() {
                    return privateState.createdby
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createddatetime": {
                get: function() {
                    return privateState.createddatetime
                },
                set: function(val) {
                    setterFunctions['createddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatedby": {
                get: function() {
                    return privateState.lastupdatedby
                },
                set: function(val) {
                    setterFunctions['lastupdatedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdateddatetime": {
                get: function() {
                    return privateState.lastupdateddatetime
                },
                set: function(val) {
                    setterFunctions['lastupdateddatetime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    return privateState.softdeleteflag
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "user_emp_id_fk": {
                get: function() {
                    return privateState.user_emp_id_fk
                },
                set: function(val) {
                    setterFunctions['user_emp_id_fk'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vehicle_color": {
                get: function() {
                    return privateState.vehicle_color
                },
                set: function(val) {
                    setterFunctions['vehicle_color'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vehicle_id_pk": {
                get: function() {
                    return privateState.vehicle_id_pk
                },
                set: function(val) {
                    throw Error("vehicle_id_pk cannot be changed.");
                },
                enumerable: true,
            },
            "vehicle_make": {
                get: function() {
                    return privateState.vehicle_make
                },
                set: function(val) {
                    setterFunctions['vehicle_make'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vehicle_model": {
                get: function() {
                    return privateState.vehicle_model
                },
                set: function(val) {
                    setterFunctions['vehicle_model'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vehicle_reg_num": {
                get: function() {
                    return privateState.vehicle_reg_num
                },
                set: function(val) {
                    setterFunctions['vehicle_reg_num'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(vehicle_tbl);
    //Create new class level validator object
    BaseModel.Validator.call(vehicle_tbl);
    var registerValidatorBackup = vehicle_tbl.registerValidator;
    vehicle_tbl.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (vehicle_tbl.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [{
        name: "vehicle_tbl_journey_tbl",
        targetObject: "journey_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "vehicle_id_pk",
            targetField: "journey_selected_vehicle_id_fk"
        }, ]
    }, {
        name: "vehicle_tbl_vehicle_images_tbl",
        targetObject: "vehicle_images_tbl",
        type: "OneToMany",
        cascade: "false",
        relationFields: [{
            sourceField: "vehicle_id_pk",
            targetField: "vehicle_id_fk"
        }, ]
    }, ];
    vehicle_tbl.relations = relations;
    vehicle_tbl.prototype.isValid = function() {
        return vehicle_tbl.isValid(this);
    };
    vehicle_tbl.prototype.objModelName = "vehicle_tbl";
    return vehicle_tbl;
});

define('RepoManagerConfig',[], function() {
    var repoMapping = {
        journey_tbl: {
            model: "JourneyObjSvc/journey_tbl/Model",
            config: "JourneyObjSvc/journey_tbl/MF_Config",
            repository: "",
        },
        region_master_tbl: {
            model: "JourneyObjSvc/region_master_tbl/Model",
            config: "JourneyObjSvc/region_master_tbl/MF_Config",
            repository: "",
        },
        question_localisation_mapping_tbl: {
            model: "JourneyObjSvc/question_localisation_mapping_tbl/Model",
            config: "JourneyObjSvc/question_localisation_mapping_tbl/MF_Config",
            repository: "",
        },
        country_master_tbl: {
            model: "JourneyObjSvc/country_master_tbl/Model",
            config: "JourneyObjSvc/country_master_tbl/MF_Config",
            repository: "",
        },
        user_tbl: {
            model: "JourneyObjSvc/user_tbl/Model",
            config: "JourneyObjSvc/user_tbl/MF_Config",
            repository: "",
        },
        ad_group_master_tbl: {
            model: "JourneyObjSvc/ad_group_master_tbl/Model",
            config: "JourneyObjSvc/ad_group_master_tbl/MF_Config",
            repository: "",
        },
        checkpoints_tbl: {
            model: "JourneyObjSvc/checkpoints_tbl/Model",
            config: "JourneyObjSvc/checkpoints_tbl/MF_Config",
            repository: "",
        },
        question_type_master_tbl: {
            model: "JourneyObjSvc/question_type_master_tbl/Model",
            config: "JourneyObjSvc/question_type_master_tbl/MF_Config",
            repository: "",
        },
        journey_notif_map_tbl: {
            model: "JourneyObjSvc/journey_notif_map_tbl/Model",
            config: "JourneyObjSvc/journey_notif_map_tbl/MF_Config",
            repository: "",
        },
        question_options_tbl: {
            model: "JourneyObjSvc/question_options_tbl/Model",
            config: "JourneyObjSvc/question_options_tbl/MF_Config",
            repository: "",
        },
        language_master_tbl: {
            model: "JourneyObjSvc/language_master_tbl/Model",
            config: "JourneyObjSvc/language_master_tbl/MF_Config",
            repository: "",
        },
        checkin_type_master_tbl: {
            model: "JourneyObjSvc/checkin_type_master_tbl/Model",
            config: "JourneyObjSvc/checkin_type_master_tbl/MF_Config",
            repository: "",
        },
        incident_type_master_tbl: {
            model: "JourneyObjSvc/incident_type_master_tbl/Model",
            config: "JourneyObjSvc/incident_type_master_tbl/MF_Config",
            repository: "",
        },
        journey_signature_tbl: {
            model: "JourneyObjSvc/journey_signature_tbl/Model",
            config: "JourneyObjSvc/journey_signature_tbl/MF_Config",
            repository: "",
        },
        guides_manuals_tbl: {
            model: "JourneyObjSvc/guides_manuals_tbl/Model",
            config: "JourneyObjSvc/guides_manuals_tbl/MF_Config",
            repository: "",
        },
        incident_status_master_tbl: {
            model: "JourneyObjSvc/incident_status_master_tbl/Model",
            config: "JourneyObjSvc/incident_status_master_tbl/MF_Config",
            repository: "",
        },
        journey_passengers_tbl: {
            model: "JourneyObjSvc/journey_passengers_tbl/Model",
            config: "JourneyObjSvc/journey_passengers_tbl/MF_Config",
            repository: "",
        },
        vehicle_images_tbl: {
            model: "JourneyObjSvc/vehicle_images_tbl/Model",
            config: "JourneyObjSvc/vehicle_images_tbl/MF_Config",
            repository: "",
        },
        checkpoints_status_master_tbl: {
            model: "JourneyObjSvc/checkpoints_status_master_tbl/Model",
            config: "JourneyObjSvc/checkpoints_status_master_tbl/MF_Config",
            repository: "",
        },
        notifications_tbl: {
            model: "JourneyObjSvc/notifications_tbl/Model",
            config: "JourneyObjSvc/notifications_tbl/MF_Config",
            repository: "",
        },
        incident_response_master_tbl: {
            model: "JourneyObjSvc/incident_response_master_tbl/Model",
            config: "JourneyObjSvc/incident_response_master_tbl/MF_Config",
            repository: "",
        },
        journey_reasons_master_tbl: {
            model: "JourneyObjSvc/journey_reasons_master_tbl/Model",
            config: "JourneyObjSvc/journey_reasons_master_tbl/MF_Config",
            repository: "",
        },
        incident_notification_tbl: {
            model: "JourneyObjSvc/incident_notification_tbl/Model",
            config: "JourneyObjSvc/incident_notification_tbl/MF_Config",
            repository: "",
        },
        user_answers_tbl: {
            model: "JourneyObjSvc/user_answers_tbl/Model",
            config: "JourneyObjSvc/user_answers_tbl/MF_Config",
            repository: "",
        },
        checklist_questions_master_tbl: {
            model: "JourneyObjSvc/checklist_questions_master_tbl/Model",
            config: "JourneyObjSvc/checklist_questions_master_tbl/MF_Config",
            repository: "",
        },
        vehicle_tbl: {
            model: "JourneyObjSvc/vehicle_tbl/Model",
            config: "JourneyObjSvc/vehicle_tbl/MF_Config",
            repository: "",
        },
        checkin_interval_master_tbl: {
            model: "JourneyObjSvc/checkin_interval_master_tbl/Model",
            config: "JourneyObjSvc/checkin_interval_master_tbl/MF_Config",
            repository: "",
        },
        journeystatus_codes_master_tbl: {
            model: "JourneyObjSvc/journeystatus_codes_master_tbl/Model",
            config: "JourneyObjSvc/journeystatus_codes_master_tbl/MF_Config",
            repository: "",
        },
    };
    return repoMapping;
})
;
require(['applicationController','com/konymp/alertpopup/alertpopupController','com/konymp/alertpopup/alertpopup','com/konymp/alertpopup/alertpopupConfig','com/konymp/animatedtextfield/KonyLogger','com/konymp/animatedtextfield/animatedtextfieldController','com/konymp/animatedtextfield/animatedtextfield','com/konymp/animatedtextfield/animatedtextfieldConfig','com/konymp/HeaderEntry/HeaderEntryController','com/konymp/HeaderEntry/HeaderEntry','com/konymp/HeaderEntry/HeaderEntryConfig','com/konymp/HeaderEntry1/HeaderEntry1Controller','com/konymp/HeaderEntry1/HeaderEntry1','com/konymp/HeaderEntry1/HeaderEntry1Config','com/konymp/HeaderEntry2/HeaderEntry2Controller','com/konymp/HeaderEntry2/HeaderEntry2','com/konymp/HeaderEntry2/HeaderEntry2Config','com/konymp/JourneyTracking/JourneyTrackingController','com/konymp/JourneyTracking/JourneyTracking','com/konymp/JourneyTracking/JourneyTrackingConfig','com/konymp/progressBarIndicator/progressBarIndicatorController','com/konymp/progressBarIndicator/progressBarIndicator','com/konymp/progressBarIndicator/progressBarIndicatorConfig','com/konymp/vuegooglemaps/analytics','com/konymp/vuegooglemaps/ControllerImplementation','com/konymp/vuegooglemaps/KonyLogger','com/konymp/vuegooglemaps/vuegooglemapsController','com/konymp/vuegooglemaps/vuegooglemaps','com/konymp/vuegooglemaps/vuegooglemapsConfig','com/konyqfs/placeDetails/placeDetailsController','com/konyqfs/placeDetails/placeDetails','com/konyqfs/placeDetails/placeDetailsConfig','com/konysa/animatedtext/animatedtextController','com/konysa/animatedtext/animatedtext','com/konysa/animatedtext/animatedtextConfig','com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinController','com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckin','com/konysa/customAlertWithContactcheckin/customAlertWithContactcheckinConfig','com/konysa/customAlertWithImage/customAlertWithImageController','com/konysa/customAlertWithImage/customAlertWithImage','com/konysa/customAlertWithImage/customAlertWithImageConfig','com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinController','com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckin','com/konysa/customAlertWithoutContactCheckin/customAlertWithoutContactCheckinConfig','com/konysa/emergencydetails/emergencydetailsController','com/konysa/emergencydetails/emergencydetails','com/konysa/emergencydetails/emergencydetailsConfig','com/konysa/escalationpolicy/escalationpolicyController','com/konysa/escalationpolicy/escalationpolicy','com/konysa/escalationpolicy/escalationpolicyConfig','com/konysa/ETAReporting/ETAReportingController','com/konysa/ETAReporting/ETAReporting','com/konysa/ETAReporting/ETAReportingConfig','com/konysa/journeymap/journeymapController','com/konysa/journeymap/journeymap','com/konysa/journeymap/journeymapConfig','com/konysa/jrmgmtheader/jrmgmtheaderController','com/konysa/jrmgmtheader/jrmgmtheader','com/konysa/jrmgmtheader/jrmgmtheaderConfig','com/konysa/masktext/masktextController','com/konysa/masktext/masktext','com/konysa/masktext/masktextConfig','com/konysa/pathinfo/pathinfoController','com/konysa/pathinfo/pathinfo','com/konysa/pathinfo/pathinfoConfig','com/konysa/processstatus/processstatusController','com/konysa/processstatus/processstatus','com/konysa/processstatus/processstatusConfig','com/konysa/searchnfilter/searchnfilterController','com/konysa/searchnfilter/searchnfilter','com/konysa/searchnfilter/searchnfilterConfig','com/konysa/tabpane/tabpaneController','com/konysa/tabpane/tabpane','com/konysa/tabpane/tabpaneConfig','com/konysa/terminateJourney/terminateJourneyController','com/konysa/terminateJourney/terminateJourney','com/konysa/terminateJourney/terminateJourneyConfig','com/konymp/Passenger/PassengerController','com/konymp/Passenger/Passenger','com/konymp/Passenger/PassengerConfig','com/konysa/journeydetail/journeydetailController','com/konysa/journeydetail/journeydetail','com/konysa/journeydetail/journeydetailConfig','com/konysa/journeyTracker/journeyTrackerController','com/konysa/journeyTracker/journeyTracker','com/konysa/journeyTracker/journeyTrackerConfig','com/konysa/normallogin/normalloginController','com/konysa/normallogin/normallogin','com/konysa/normallogin/normalloginConfig','CopyflxMain0f0004db7fa7f48','flxParent','flxSampleRowTemplate','flxSectionHeaderTemplate','flxRootJourneyCard','flxNotificationRoot','flxSegTmpAddPassenger','flxEscalationRoot','flxPathRoot','flxRootProcessStatusDW','Flex0ab488ced76e94b','CopyflxMapTemplate0cad7fd75f04947','CopyflxMapTemplate0a0ff65a9bba142','flxMapTemplate','CopyflxMain0f0004db7fa7f48Controller','flxParentController','flxSampleRowTemplateController','flxSectionHeaderTemplateController','flxRootJourneyCardController','flxNotificationRootController','flxSegTmpAddPassengerController','flxEscalationRootController','flxPathRootController','flxRootProcessStatusDWController','Flex0ab488ced76e94bController','CopyflxMapTemplate0cad7fd75f04947Controller','CopyflxMapTemplate0a0ff65a9bba142Controller','flxMapTemplateController','JourneyObjSvc/ad_group_master_tbl/MF_Config','JourneyObjSvc/ad_group_master_tbl/Model','JourneyObjSvc/checkin_interval_master_tbl/MF_Config','JourneyObjSvc/checkin_interval_master_tbl/Model','JourneyObjSvc/checkin_type_master_tbl/MF_Config','JourneyObjSvc/checkin_type_master_tbl/Model','JourneyObjSvc/checklist_questions_master_tbl/MF_Config','JourneyObjSvc/checklist_questions_master_tbl/Model','JourneyObjSvc/checkpoints_status_master_tbl/MF_Config','JourneyObjSvc/checkpoints_status_master_tbl/Model','JourneyObjSvc/checkpoints_tbl/MF_Config','JourneyObjSvc/checkpoints_tbl/Model','JourneyObjSvc/country_master_tbl/MF_Config','JourneyObjSvc/country_master_tbl/Model','JourneyObjSvc/guides_manuals_tbl/MF_Config','JourneyObjSvc/guides_manuals_tbl/Model','JourneyObjSvc/incident_notification_tbl/MF_Config','JourneyObjSvc/incident_notification_tbl/Model','JourneyObjSvc/incident_response_master_tbl/MF_Config','JourneyObjSvc/incident_response_master_tbl/Model','JourneyObjSvc/incident_status_master_tbl/MF_Config','JourneyObjSvc/incident_status_master_tbl/Model','JourneyObjSvc/incident_type_master_tbl/MF_Config','JourneyObjSvc/incident_type_master_tbl/Model','JourneyObjSvc/journeystatus_codes_master_tbl/MF_Config','JourneyObjSvc/journeystatus_codes_master_tbl/Model','JourneyObjSvc/journey_notif_map_tbl/MF_Config','JourneyObjSvc/journey_notif_map_tbl/Model','JourneyObjSvc/journey_passengers_tbl/MF_Config','JourneyObjSvc/journey_passengers_tbl/Model','JourneyObjSvc/journey_reasons_master_tbl/MF_Config','JourneyObjSvc/journey_reasons_master_tbl/Model','JourneyObjSvc/journey_signature_tbl/MF_Config','JourneyObjSvc/journey_signature_tbl/Model','JourneyObjSvc/journey_tbl/MF_Config','JourneyObjSvc/journey_tbl/Model','JourneyObjSvc/language_master_tbl/MF_Config','JourneyObjSvc/language_master_tbl/Model','JourneyObjSvc/notifications_tbl/MF_Config','JourneyObjSvc/notifications_tbl/Model','JourneyObjSvc/question_localisation_mapping_tbl/MF_Config','JourneyObjSvc/question_localisation_mapping_tbl/Model','JourneyObjSvc/question_options_tbl/MF_Config','JourneyObjSvc/question_options_tbl/Model','JourneyObjSvc/question_type_master_tbl/MF_Config','JourneyObjSvc/question_type_master_tbl/Model','JourneyObjSvc/region_master_tbl/MF_Config','JourneyObjSvc/region_master_tbl/Model','JourneyObjSvc/user_answers_tbl/MF_Config','JourneyObjSvc/user_answers_tbl/Model','JourneyObjSvc/user_tbl/MF_Config','JourneyObjSvc/user_tbl/Model','JourneyObjSvc/vehicle_images_tbl/MF_Config','JourneyObjSvc/vehicle_images_tbl/Model','JourneyObjSvc/vehicle_tbl/MF_Config','JourneyObjSvc/vehicle_tbl/Model','RepoManagerConfig'], function(){});

define("sparequirefileslist", function(){});

