var CACHE_VERSION = '1564990580325';
var filesToCache, cacheName,
    contextName = '/',
    path = 'desktopweb',
    cacheid = '1564989867884',
    appid = location.pathname.split('/')[1],
    fcmsenderid = '425993078537';

if(cacheid) {
    path = cacheid + '/' + path;
    contextName = '/'+location.pathname.split('/')[1]+'/';
    appid = location.pathname.split('/')[2];
}
cacheName = appid + '-v' + CACHE_VERSION;
filesToCache = [
    './',
    path + '/konydesktop.css',
    path + '/appjs/app.js',
    path + '/appjs/kvmodules.js',
    path + '/jslib/konyframework.js'
];

self.addEventListener('install', function(e) {
    //console.log('[ServiceWorker] Install');
    e.waitUntil(
        caches.open(cacheName).then(function(cache) {
            //console.log('[ServiceWorker] Caching app shell');
            return cache.addAll(filesToCache);
        }));
    self.skipWaiting();
});

self.addEventListener('activate', function(e) {
    //console.log('[ServiceWorker] Activate');
    e.waitUntil(
        caches.keys().then(function(keyList) {
            return Promise.all(keyList.map(function(key) {
                if(key !== cacheName) {
                    if(key.split('-')[0] === appid) { // delete only if same app
                        //console.log('[ServiceWorker] Removing old cache', key);
                        return caches.delete(key);
                    }
                }
            }));
        }));
    return self.clients.claim();
});

self.addEventListener('fetch', function(event) {
    //console.log('[ServiceWorker] Fetch', event.request.url);
    var requestUrl = event.request.url;
    var selfLocation = self.location.origin;
    if(requestUrl.startsWith(selfLocation+contextName+appid)) {
        if(requestUrl.indexOf('nocache') == -1){
            event.respondWith(
                caches.match(event.request).then(function(response) {
                    if(response) {
                        return response;
                    } else {
                        return fetchAndCache(event, caches);
                    }
                })
            );
        } else {
            return fetch(event.request).then(function(response) {
                return response;
            });
        }
    }
});

var fetchAndCache = function(event, caches) {
    return fetch(event.request).then(function(response) {
        if(response.ok && response.status === 200) {
            return caches.open(cacheName).then(function(cache) {
                return cache.put(event.request, response.clone()).then(function() {
                    return response;
                }).catch(function() {
                    return response;
                });
            }).catch(function() {
                return response;
            });
        } else {
            return response;
        }
    });
}

if(fcmsenderid) {
    importScripts('https://www.gstatic.com/firebasejs/5.5.3/firebase-app.js');
    importScripts('https://www.gstatic.com/firebasejs/5.5.3/firebase-messaging.js');

    firebase.initializeApp({
      'messagingSenderId': fcmsenderid
    });

    const messaging = firebase.messaging();
    messaging.setBackgroundMessageHandler(function(payload) {
      console.log('[firebase-messaging-sw.js] Received background message ', payload);
      // Customize notification here
      return self.registration.showNotification(notificationTitle,
        notificationOptions);
    });
}