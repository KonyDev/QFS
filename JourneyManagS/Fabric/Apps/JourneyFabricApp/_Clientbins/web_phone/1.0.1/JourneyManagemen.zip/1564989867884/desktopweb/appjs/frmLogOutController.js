define("userfrmLogOutController", {
    //Type your controller code here 
    onNavigate: function() {},
    onLoginSuccess: function(result) {
        try {
            var navObj = new kony.mvc.Navigation("frmJourneyList");
            navObj.navigate();
        } catch (excp) {
            debugger;
        }
    }
});
define("frmLogOutControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxSignIn **/
    AS_FlexContainer_b52564c5d6ec4837aa217fc40a37ced0: function AS_FlexContainer_b52564c5d6ec4837aa217fc40a37ced0(eventobject) {
        var self = this;
        var x = new kony.mvc.Navigation("fmLogin");
        x.navigate();
    }
});
define("frmLogOutController", ["userfrmLogOutController", "frmLogOutControllerActions"], function() {
    var controller = require("userfrmLogOutController");
    var controllerActions = ["frmLogOutControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
