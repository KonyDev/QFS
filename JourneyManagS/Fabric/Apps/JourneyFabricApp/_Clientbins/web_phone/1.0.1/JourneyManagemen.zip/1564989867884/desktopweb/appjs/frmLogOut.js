define("frmLogOut", function() {
    return function(controller) {
        function addWidgetsfrmLogOut() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "sknFlxBGFAFAFA",
                "top": "524dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxLogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "43%",
                "clipBounds": true,
                "height": "360dp",
                "id": "flxLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "minWidth": "360dp",
                "isModalContainer": false,
                "skin": "sknFlxBGWhiteBoxShadow",
                "width": "29%",
                "zIndex": 1
            }, {}, {});
            flxLogin.setDefaultUnit(kony.flex.DP);
            var lblLoginSubTitle = new kony.ui.Label({
                "id": "lblLoginSubTitle",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknCMPLoginLblTitleBgTransFont030303",
                "text": "LogOut  Success",
                "textStyle": {},
                "top": "150dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSignIn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "42dp",
                "id": "flxSignIn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b52564c5d6ec4837aa217fc40a37ced0,
                "skin": "FlexBG575ee7BorderRadius4",
                "top": "40dp",
                "width": "90%",
                "zIndex": 1
            }, {}, {
                "hoverSkin": "FlexBG575ee7BorderRadius4"
            });
            flxSignIn.setDefaultUnit(kony.flex.DP);
            var lblSignIn = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSignIn",
                "isVisible": true,
                "left": "50dp",
                "skin": "sknCMPLoginLblBGTransFontWhite",
                "text": "LOGIN",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSignIn.add(lblSignIn);
            flxLogin.add(lblLoginSubTitle, flxSignIn);
            flxRoot.add(flxLogin);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmLogOut,
            "enabledForIdleTimeout": false,
            "id": "frmLogOut",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});