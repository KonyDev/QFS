define("fmLogin", function() {
    return function(controller) {
        function addWidgetsfmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var brwLogin = new kony.ui.Browser({
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "htmlString": "Browser",
                "id": "brwLogin",
                "isVisible": true,
                "left": "0dp",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            var Image0f6008219da5b4e = new kony.ui.Image2({
                "height": "100%",
                "id": "Image0f6008219da5b4e",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "fmg_login.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.add(brwLogin, Image0f6008219da5b4e);
        };
        return [{
            "addWidgets": addWidgetsfmLogin,
            "enabledForIdleTimeout": false,
            "id": "fmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_d90793274adb449491d7440acce37165,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});