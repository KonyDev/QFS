define("frmRoute", function() {
    return function(controller) {
        function addWidgetsfrmRoute() {
            this.setDefaultUnit(kony.flex.DP);
            var flxParent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1319px",
                "id": "flxParent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1440px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxParent.setDefaultUnit(kony.flex.DP);
            var LeftFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1319px",
                "id": "LeftFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0bcd49123877f4a",
                "top": "0px",
                "width": "330px",
                "zIndex": 1
            }, {}, {});
            LeftFlex.setDefaultUnit(kony.flex.DP);
            var flxCreationList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "240px",
                "id": "flxCreationList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "32px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99px",
                "width": "197px",
                "zIndex": 1
            }, {}, {});
            flxCreationList.setDefaultUnit(kony.flex.DP);
            flxCreationList.add();
            var FlxTravelerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTravelerDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTravelerDetails.setDefaultUnit(kony.flex.DP);
            var btnTravelerDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTravelerDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "1",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravelerDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblTravelerDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Traveller Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTravelerDetails.add(btnTravelerDetails, lblTravelerDetails);
            var FlxRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "149dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblRouteDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblRouteDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Route Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRouteDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30px",
                "id": "btnRouteDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal1",
                "text": "2",
                "top": "0px",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRouteDetails.add(lblRouteDetails, btnRouteDetails);
            var FlxTrackingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTrackingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "199dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTrackingDetails.setDefaultUnit(kony.flex.DP);
            var btnTrackingDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTrackingDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "3",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingDetails = new kony.ui.Label({
                "height": "25px",
                "id": "lblTrackingDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Tracking Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrackingDetails.add(btnTrackingDetails, lblTrackingDetails);
            var FlxVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxVehicleDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "249dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxVehicleDetails.setDefaultUnit(kony.flex.DP);
            var btnVehicleDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnVehicleDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "4",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblVehicleDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Vehicle Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicleDetails.add(btnVehicleDetails, lblVehicleDetails);
            var FlxReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxReview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "299dp",
                "width": "220px",
                "zIndex": 2
            }, {}, {});
            FlxReview.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "5",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Review & Verification",
                "top": "6px",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxReview.add(btnReview, lblReview);
            var lblVerticalLine = new kony.ui.Label({
                "height": "189px",
                "id": "lblVerticalLine",
                "isVisible": true,
                "left": "42px",
                "skin": "CopyCopydefLabel0jcee779a5e3f48",
                "top": "125px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "33px",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i2ef37a3c12946fea813be5f7bafb4fb,
                "skin": "slFbox",
                "top": "33px",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "height": "21px",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "32px",
                "minWidth": "156px",
                "skin": "CopyCopydefLabel0f52d96ab22d343",
                "text": "Back to Dashboard",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "21px",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "murali_1.png",
                "top": "0px",
                "width": "20px",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            LeftFlex.add(flxCreationList, FlxTravelerDetails, FlxRouteDetails, FlxTrackingDetails, FlxVehicleDetails, FlxReview, lblVerticalLine, flxDashboard);
            var RightFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1319px",
                "id": "RightFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "330px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "780px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            RightFlex.setDefaultUnit(kony.flex.DP);
            var lblRouteDetailsHeader = new kony.ui.Label({
                "height": "32px",
                "id": "lblRouteDetailsHeader",
                "isVisible": true,
                "left": "195px",
                "skin": "konyqfsSknLblRouteDetailsHeader",
                "text": "Route Details",
                "top": "50px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var FlxEditRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "322px",
                "id": "FlxEditRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "195px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0ifab49c9e81f43",
                "top": "101px",
                "width": "390px",
                "zIndex": 1
            }, {}, {});
            FlxEditRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblDepatureDetailsHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblDepatureDetailsHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Departure Details",
                "top": "30px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDepature = new kony.ui.Image2({
                "height": "16px",
                "id": "imgDepature",
                "isVisible": true,
                "left": "30px",
                "right": "30px",
                "skin": "slImage",
                "src": "departurepoint_2.png",
                "top": "71px",
                "width": "16px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDepartureFrom = new kony.ui.Label({
                "height": "21px",
                "id": "lblDepartureFrom",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "From",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDepartureFromValue = new kony.ui.Label({
                "id": "lblDepartureFromValue",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "123 Backer Street",
                "top": "91px",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTo = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalTo",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "To",
                "top": "208px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalToValue = new kony.ui.Label({
                "id": "lblArrivalToValue",
                "isVisible": true,
                "left": "60px",
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "221 Birmingham Street",
                "top": "228px",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStartTime = new kony.ui.Label({
                "height": "21px",
                "id": "lblStartTime",
                "isVisible": true,
                "right": "76px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "Start",
                "top": "71px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStartTimeValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblStartTimeValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "25Sep  10:10AM",
                "top": "91px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTime = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalTime",
                "isVisible": true,
                "right": "76px",
                "skin": "CopyCopydefLabel0e5a3c4834f2a4c",
                "text": "Arrival",
                "top": "208px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalTimeValue = new kony.ui.Label({
                "height": "16px",
                "id": "lblArrivalTimeValue",
                "isVisible": true,
                "right": 30,
                "skin": "CopyCopydefLabel0fdf3f95c1ab742",
                "text": "25Sep  4:10PM",
                "top": "228px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgArrival = new kony.ui.Image2({
                "height": "16px",
                "id": "imgArrival",
                "isVisible": true,
                "left": "30px",
                "right": "30px",
                "skin": "slImage",
                "src": "arrival.png",
                "top": "208px",
                "width": "16px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditDepartureDetails = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnEditDepartureDetails",
                "isVisible": true,
                "left": "240px",
                "onClick": controller.AS_Button_g37f3a218e2b42f3a1404018df13b7bc,
                "skin": "CopyCopydefBtnNormal2",
                "text": "EDIT",
                "top": "270px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrivalDetails = new kony.ui.Label({
                "height": "21px",
                "id": "lblArrivalDetails",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Arrival Details",
                "top": "167px",
                "width": "190px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxEditRouteDetails.add(lblDepatureDetailsHeader, imgDepature, lblDepartureFrom, lblDepartureFromValue, lblArrivalTo, lblArrivalToValue, lblStartTime, lblStartTimeValue, lblArrivalTime, lblArrivalTimeValue, imgArrival, btnEditDepartureDetails, lblArrivalDetails);
            var FlxCheckinDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "380px",
                "id": "FlxCheckinDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "195px",
                "isModalContainer": false,
                "skin": "CopyslFbox0cdf27c4481e445",
                "top": "450px",
                "width": "390px",
                "zIndex": 1
            }, {}, {});
            FlxCheckinDetails.setDefaultUnit(kony.flex.DP);
            var lblCheckInDetailsHeader = new kony.ui.Label({
                "height": "21px",
                "id": "lblCheckInDetailsHeader",
                "isVisible": true,
                "left": "30px",
                "skin": "CopyCopydefLabel0bed182c481144b",
                "text": "Checkin Details",
                "top": "30px",
                "width": "128px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLocationCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxLocationCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "71dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxLocationCheckin.setDefaultUnit(kony.flex.DP);
            var lblLocationCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblLocationCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Location Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLocationCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnLocationCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLocationCheckin = new kony.ui.Image2({
                "height": "24px",
                "id": "imgLocationCheckin",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "15dp",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLocationCheckin.add(lblLocationCheckin, btnLocationCheckin, imgLocationCheckin);
            var flxTimeBasedCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxTimeBasedCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a8bc298f40d34acf95a78524586c9a4e,
                "skin": "slFbox",
                "top": "137dp",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxTimeBasedCheckin.setDefaultUnit(kony.flex.DP);
            var lblTimeBasedCheckin = new kony.ui.Label({
                "height": "56px",
                "id": "lblTimeBasedCheckin",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "Time based Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTimeBasedCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnTimeBasedCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgTimeBasedCheckin = new kony.ui.Image2({
                "height": "24px",
                "id": "imgTimeBasedCheckin",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTimeBasedCheckin.add(lblTimeBasedCheckin, btnTimeBasedCheckin, imgTimeBasedCheckin);
            var flxNoCheckin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "56dp",
                "id": "flxNoCheckin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f1b029b25de444b2a646b4434fa8f0de,
                "skin": "slFbox",
                "top": "200px",
                "width": "207px",
                "zIndex": 1
            }, {}, {});
            flxNoCheckin.setDefaultUnit(kony.flex.DP);
            var lblNoCheckins = new kony.ui.Label({
                "height": "56px",
                "id": "lblNoCheckins",
                "isVisible": true,
                "left": "30px",
                "skin": "CopydefLabel0d9b6e36cc99848",
                "text": "No Checkins",
                "top": "0dp",
                "width": "183px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNoCheckin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "24px",
                "id": "btnNoCheckin",
                "isVisible": false,
                "left": "0px",
                "skin": "CopydefBtnNormal0f009bf8215e440",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgNoCheckins = new kony.ui.Image2({
                "height": "24px",
                "id": "imgNoCheckins",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "defaultdeselect.png",
                "top": "15px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoCheckin.add(lblNoCheckins, btnNoCheckin, imgNoCheckins);
            var lblCheckinTime = new kony.ui.Label({
                "height": "16px",
                "id": "lblCheckinTime",
                "isVisible": false,
                "left": "30px",
                "skin": "CopydefLabel0ib840098134844",
                "text": "Checkin Time Frame",
                "top": "215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var listboxTimeFrame = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "48px",
                "id": "listboxTimeFrame",
                "isVisible": false,
                "left": "30px",
                "onSelection": controller.AS_ListBox_debd245647b549529f0c1fe1361137cd,
                "skin": "CopydefListBoxNormal0b7f0f262408e43",
                "top": "241px",
                "width": "330px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lblHorizontalLine = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLine",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "260px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHorizontalLineOne = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLineOne",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "129px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHorizontalLineTwo = new kony.ui.Label({
                "height": "1px",
                "id": "lblHorizontalLineTwo",
                "isVisible": true,
                "left": "54px",
                "skin": "CopydefLabel0c7795534b4a846",
                "top": "194px",
                "width": "184px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxCheckinDetails.add(lblCheckInDetailsHeader, flxLocationCheckin, flxTimeBasedCheckin, flxNoCheckin, lblCheckinTime, listboxTimeFrame, lblHorizontalLine, lblHorizontalLineOne, lblHorizontalLineTwo);
            var flxDepartureArrivalFields = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "840px",
                "id": "flxDepartureArrivalFields",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "195px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "80px",
                "width": "390px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDepartureArrivalFields.setDefaultUnit(kony.flex.DP);
            var DepartureDetails = new com.konyqfs.placeDetails({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50%",
                "id": "DepartureDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "flxParentSkn",
                "top": "100%",
                "width": "100%",
                "overrides": {
                    "placeDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "retainFlowHorizontalAlignment": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            DepartureDetails.startYear = 1980;
            DepartureDetails.endYear = 2025;
            DepartureDetails.onDone = controller.AS_UWI_c77425f6e5074a2ea61abab4c1276be5;
            var ArrivalDetails = new com.konyqfs.placeDetails({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50%",
                "id": "ArrivalDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "flxParentSkn",
                "top": "100%",
                "width": "100%",
                "overrides": {
                    "lblHeader": {
                        "text": "Arrival Details"
                    },
                    "lblInnerFieldTitle": {
                        "text": "Choose Arrival Point"
                    },
                    "lblInnerFieldTitle2": {
                        "text": "Set a Arrival Date"
                    },
                    "lblInnerFieldTitle3": {
                        "text": "Set a Arrival Time"
                    },
                    "placeDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "retainFlowHorizontalAlignment": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            ArrivalDetails.startYear = 1980;
            ArrivalDetails.endYear = 2025;
            ArrivalDetails.onDone = controller.AS_UWI_i5e8da0e95b245a39adea9484bc68dfb;
            flxDepartureArrivalFields.add(DepartureDetails, ArrivalDetails);
            var btnNext = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnNext",
                "isVisible": true,
                "left": "454px",
                "onClick": controller.AS_Button_aaf8dfd6f80c4e38a2b5b285fbda2b63,
                "skin": "CopyCopydefBtnNormal2",
                "text": "Next Step",
                "top": "878px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSave = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnSave",
                "isVisible": false,
                "left": "454px",
                "onClick": controller.AS_Button_c0ba5f11817045ffbb66dc4c6104f810,
                "skin": "CopyCopydefBtnNormal2",
                "text": "Save",
                "top": "878px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rchTextNext = new kony.ui.RichText({
                "height": "17px",
                "id": "rchTextNext",
                "isVisible": true,
                "linkSkin": "defRichTextLink",
                "right": "195px",
                "skin": "CopydefRichTextNormal0db697b0963a140",
                "text": "Next step:<b>Tracking Details</B>",
                "top": "936px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            RightFlex.add(lblRouteDetailsHeader, FlxEditRouteDetails, FlxCheckinDetails, flxDepartureArrivalFields, btnNext, btnSave, rchTextNext);
            flxParent.add(LeftFlex, RightFlex);
            this.add(flxParent);
        };
        return [{
            "addWidgets": addWidgetsfrmRoute,
            "enabledForIdleTimeout": false,
            "id": "frmRoute",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_fcebe2a1937a49ddb14e26540f9dd6c6,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});