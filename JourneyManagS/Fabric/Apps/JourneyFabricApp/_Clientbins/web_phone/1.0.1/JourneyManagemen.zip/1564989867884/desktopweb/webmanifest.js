{
    "theme_color": "#FFFFFF",
    "orientation": "potrait",
    "background_color": "#9E9E9E",
    "display": "standalone",
    "name": "Journey Management Admin",
    "short_name": "Journey Managment",
    "start_url": "/apps/JourneyManagemen/",
    "icons": [{
        "type": "image/png",
        "sizes": "192x192",
        "src": "images/launcher-192.png"
    }, {
        "type": "image/png",
        "sizes": "512x512",
        "src": "images/launcher-512.png"
    }]
}