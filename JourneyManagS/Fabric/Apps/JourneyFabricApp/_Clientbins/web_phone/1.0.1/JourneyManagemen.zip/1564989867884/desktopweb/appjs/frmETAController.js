define("userfrmETAController", {
    //Type your controller code here 
});
define("frmETAControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmETAController", ["userfrmETAController", "frmETAControllerActions"], function() {
    var controller = require("userfrmETAController");
    var controllerActions = ["frmETAControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
