define("frmTravellerDetails", function() {
    return function(controller) {
        function addWidgetsfrmTravellerDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var ParentFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1100px",
                "id": "ParentFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox0c8dcf582789243",
                "top": "0px",
                "width": "1440px",
                "zIndex": 1
            }, {}, {});
            ParentFlex.setDefaultUnit(kony.flex.DP);
            var RightFlex = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "1100px",
                "horizontalScrollIndicator": true,
                "id": "RightFlex",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "330px",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknFlxAddPassenger0af02c7965a894c",
                "top": "0px",
                "verticalScrollIndicator": true,
                "width": "780px",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            RightFlex.setDefaultUnit(kony.flex.DP);
            var lblTravellerDetailsDashboard = new kony.ui.Label({
                "height": "31px",
                "id": "lblTravellerDetailsDashboard",
                "isVisible": true,
                "left": "195px",
                "skin": "CopyCopydefLabel0ffdcfdc6e6994c",
                "text": "Traveller Details",
                "top": "90px",
                "width": "391px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblName = new kony.ui.Label({
                "height": "16px",
                "id": "lblName",
                "isVisible": true,
                "left": "195px",
                "skin": "CopylblName",
                "text": "Driver Name",
                "top": "30px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Your Name",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5px",
                "width": "391px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblMobile = new kony.ui.Label({
                "height": "16px",
                "id": "lblMobile",
                "isVisible": true,
                "left": "195px",
                "skin": "CopylblName",
                "text": "Mobile Phone Number",
                "top": "30px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldMobile = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldMobile",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "999-999-9999",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5px",
                "width": "391px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblRoomNo = new kony.ui.Label({
                "height": "16px",
                "id": "lblRoomNo",
                "isVisible": true,
                "left": "195px",
                "skin": "CopylblName",
                "text": "Satelite Phone",
                "top": "30px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldRoomNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldRoomNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Satellite Phone Number",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5px",
                "width": "391px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblSiterepName = new kony.ui.Label({
                "height": "16px",
                "id": "lblSiterepName",
                "isVisible": true,
                "left": "195px",
                "skin": "CopylblName",
                "text": "Radio",
                "top": "30px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldSiterepName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldSiterepName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter Radio Number",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5px",
                "width": "391px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblUserID = new kony.ui.Label({
                "height": "16px",
                "id": "lblUserID",
                "isVisible": true,
                "left": "195px",
                "skin": "CopylblName",
                "text": "User ID",
                "top": "30px",
                "width": "300px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldUserID = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "48px",
                "id": "TextFieldUserID",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "195px",
                "placeholder": "Enter User ID",
                "secureTextEntry": false,
                "skin": "CopyCopydefTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5px",
                "width": "391px",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxSegData = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "250dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "195dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "30dp",
                "verticalScrollIndicator": true,
                "width": "390dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSegData.setDefaultUnit(kony.flex.DP);
            var segAddPassenger = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgAddPassenger": "",
                    "lblPassenger": "",
                    "lblPassengerMobile": "",
                    "lblPassengerName": "",
                    "txtPassengerMobile": {
                        "placeholder": "",
                        "text": ""
                    },
                    "txtPassengerName": {
                        "placeholder": "",
                        "text": ""
                    }
                }],
                "groupCells": false,
                "id": "segAddPassenger",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSegTmpAddPassenger",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAddPassenger": "flxAddPassenger",
                    "flxSegTmpAddPassenger": "flxSegTmpAddPassenger",
                    "imgAddPassenger": "imgAddPassenger",
                    "lblPassenger": "lblPassenger",
                    "lblPassengerMobile": "lblPassengerMobile",
                    "lblPassengerName": "lblPassengerName",
                    "txtPassengerMobile": "txtPassengerMobile",
                    "txtPassengerName": "txtPassengerName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegData.add(segAddPassenger);
            var flxAddPassenger = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "48px",
                "id": "flxAddPassenger",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "203px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_bc0723b4bcb44c1cbc847dab00c11294,
                "skin": "CopyslFbox0aacbda37a36146",
                "top": "30px",
                "width": "195px",
                "zIndex": 1
            }, {}, {});
            flxAddPassenger.setDefaultUnit(kony.flex.DP);
            var imgPlusIcon = new kony.ui.Image2({
                "height": "48px",
                "id": "imgPlusIcon",
                "isVisible": true,
                "left": "12px",
                "skin": "slImage",
                "src": "plus.png",
                "top": "0px",
                "width": "24px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddPassenger = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "48px",
                "id": "btnAddPassenger",
                "isVisible": false,
                "right": "0px",
                "skin": "CopydefBtnNormal0gf08e7ec380348",
                "text": "Add Passenger",
                "top": "0dp",
                "width": "147px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddPassenger = new kony.ui.Label({
                "height": "48px",
                "id": "lblAddPassenger",
                "isVisible": true,
                "right": "0px",
                "skin": "CopydefLabel0i659ac8d0bee42",
                "text": "Add Passenger",
                "top": "0dp",
                "width": "147px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddPassengerVerticalLine = new kony.ui.Label({
                "height": "44px",
                "id": "lblAddPassengerVerticalLine",
                "isVisible": true,
                "left": "46px",
                "skin": "CopydefLabel0bf4e4e48c7c947",
                "top": "1px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddPassenger.add(imgPlusIcon, btnAddPassenger, lblAddPassenger, lblAddPassengerVerticalLine);
            var btnNextStep = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnNextStep",
                "isVisible": true,
                "left": "459px",
                "onClick": controller.AS_Button_c88d67579c73422c904efea0731e2430,
                "skin": "CopyCopydefBtnNormal0a6835a37c10c44",
                "text": "Next",
                "top": "30px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSave = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0gdc41de14b9a43",
                "height": "48px",
                "id": "btnSave",
                "isVisible": false,
                "left": "459px",
                "onClick": controller.AS_Button_i06a243648fd46a094bb0e0e3b2e5c8b,
                "skin": "CopyCopydefBtnNormal0a6835a37c10c44",
                "text": "Save",
                "top": "30px",
                "width": "132px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rchtxtNextStep = new kony.ui.RichText({
                "height": "18px",
                "id": "rchtxtNextStep",
                "isVisible": true,
                "left": "461px",
                "linkSkin": "defRichTextLink",
                "skin": "CopyCopydefRichTextNormal1",
                "text": "Next step:<b>RouteDetails</B>",
                "top": "8px",
                "width": "140px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            RightFlex.add(lblTravellerDetailsDashboard, lblName, TextFieldName, lblMobile, TextFieldMobile, lblRoomNo, TextFieldRoomNo, lblSiterepName, TextFieldSiterepName, lblUserID, TextFieldUserID, flxSegData, flxAddPassenger, btnNextStep, btnSave, rchtxtNextStep);
            var LeftFlex = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1100px",
                "id": "LeftFlex",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopyslFbox0bcd49123877f4a",
                "top": "0px",
                "width": "330px",
                "zIndex": 1
            }, {}, {});
            LeftFlex.setDefaultUnit(kony.flex.DP);
            var flxCreationList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "240px",
                "id": "flxCreationList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "32px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99px",
                "width": "197px",
                "zIndex": 1
            }, {}, {});
            flxCreationList.setDefaultUnit(kony.flex.DP);
            flxCreationList.add();
            var FlxTravelerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTravelerDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "99dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTravelerDetails.setDefaultUnit(kony.flex.DP);
            var btnTravelerDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTravelerDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal1",
                "text": "1",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTravelerDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblTravelerDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Traveller Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTravelerDetails.add(btnTravelerDetails, lblTravelerDetails);
            var FlxRouteDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxRouteDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "149dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxRouteDetails.setDefaultUnit(kony.flex.DP);
            var lblRouteDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblRouteDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Route Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRouteDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30px",
                "id": "btnRouteDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "2",
                "top": "0px",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxRouteDetails.add(lblRouteDetails, btnRouteDetails);
            var FlxTrackingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxTrackingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "199dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxTrackingDetails.setDefaultUnit(kony.flex.DP);
            var btnTrackingDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnTrackingDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "3",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTrackingDetails = new kony.ui.Label({
                "height": "25px",
                "id": "lblTrackingDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Tracking Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxTrackingDetails.add(btnTrackingDetails, lblTrackingDetails);
            var FlxVehicleDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "FlxVehicleDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "249dp",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            FlxVehicleDetails.setDefaultUnit(kony.flex.DP);
            var btnVehicleDetails = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnVehicleDetails",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "4",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVehicleDetails = new kony.ui.Label({
                "height": "23px",
                "id": "lblVehicleDetails",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Vehicle Details",
                "top": "6px",
                "width": "137px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxVehicleDetails.add(btnVehicleDetails, lblVehicleDetails);
            var FlxReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "FlxReview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "29dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "299dp",
                "width": "220px",
                "zIndex": 2
            }, {}, {});
            FlxReview.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "30dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0px",
                "skin": "CopyCopydefBtnNormal",
                "text": "5",
                "top": "0dp",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReview = new kony.ui.Label({
                "id": "lblReview",
                "isVisible": true,
                "left": "40px",
                "skin": "CopyCopydefLabel0b1e7c83f72a64a",
                "text": "Review & Verification",
                "top": "6px",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxReview.add(btnReview, lblReview);
            var lblVerticalLine = new kony.ui.Label({
                "height": "189px",
                "id": "lblVerticalLine",
                "isVisible": true,
                "left": "42px",
                "skin": "CopyCopydefLabel0jcee779a5e3f48",
                "top": "125px",
                "width": "1px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "33px",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a39cba5802c14abb9c3edd9fa26fd2e6,
                "skin": "slFbox",
                "top": "33px",
                "width": "197px",
                "zIndex": 2
            }, {}, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "height": "21px",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "32px",
                "minWidth": "156px",
                "skin": "CopyCopydefLabel0f52d96ab22d343",
                "text": "Back to Dashboard",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20px",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "0px",
                "skin": "slImage",
                "src": "murali_1.png",
                "top": "0px",
                "width": "20px",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            LeftFlex.add(flxCreationList, FlxTravelerDetails, FlxRouteDetails, FlxTrackingDetails, FlxVehicleDetails, FlxReview, lblVerticalLine, flxDashboard);
            ParentFlex.add(RightFlex, LeftFlex);
            this.add(ParentFlex);
        };
        return [{
            "addWidgets": addWidgetsfrmTravellerDetails,
            "enabledForIdleTimeout": false,
            "id": "frmTravellerDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyCopyslForm0d6871d4fb0e546",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});